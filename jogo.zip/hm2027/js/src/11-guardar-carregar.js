  // ============================= 11-guardar-carregar.js =============================
  // Guardar / Carregar jogo
  // Guardar / Carregar jogo (localStorage do navegador)
  // =================================================================
  const SAVE_KEY = "pistaHoqueiSaveGame_v1";
  const SAVE_VERSION = 42;
  const MIN_SUPPORTED_SAVE_VERSION = 6;

  function safeIsoDate(value,fallback){
    const d=value?new Date(value):new Date(fallback||Date.now());
    return isNaN(d.getTime()) ? new Date(fallback||Date.now()).toISOString() : d.toISOString();
  }
  // Fase 4: assinatura determinística do conteúdo para detetar ficheiros truncados ou
  // alterados antes de qualquer migração. Não substitui nem elimina nenhum dado do save.
  function saveIntegrityPayload(value){
    const clone=JSON.parse(JSON.stringify(value));
    delete clone.integrity;
    return JSON.stringify(clone);
  }
  function saveIntegrityHash(text){
    let hash=2166136261;
    for(let i=0;i<text.length;i++){
      hash^=text.charCodeAt(i);
      hash=Math.imul(hash,16777619);
    }
    return (hash>>>0).toString(16).padStart(8,"0");
  }
  function saveIntegritySummary(save){
    const teams=Object.values(save.teams||{});
    return {
      teams:teams.length,
      players:teams.reduce((total,team)=>total+(Array.isArray(team.players)?team.players.length:0),0),
      retiredPlayers:Array.isArray(save.retiredPlayers)?save.retiredPlayers.length:0,
      inactivePlayers:Array.isArray(save.inactivePlayers)?save.inactivePlayers.length:0,
    };
  }
  function attachSaveIntegrity(save){
    save.integrity={algorithm:"fnv1a32",hash:saveIntegrityHash(saveIntegrityPayload(save)),summary:saveIntegritySummary(save)};
    return save;
  }
  function validateRawSaveIntegrity(save){
    if(Number(save&&save.version)<32)return true;
    if(!save.integrity||save.integrity.algorithm!=="fnv1a32"||typeof save.integrity.hash!=="string")
      throw new Error("A gravação não contém a informação de integridade obrigatória.");
    const expected=saveIntegrityHash(saveIntegrityPayload(save));
    if(expected!==save.integrity.hash) throw new Error("A gravação está incompleta ou foi alterada depois de ser criada.");
    const actual=saveIntegritySummary(save),recorded=save.integrity.summary||{};
    ["teams","players","retiredPlayers","inactivePlayers"].forEach(key=>{
      if(Number(recorded[key])!==actual[key]) throw new Error(`A gravação falhou a verificação de integridade (${key}).`);
    });
    return true;
  }
  function fixtureSaveIsValid(value){
    return Array.isArray(value) && value.every(r=>r && Array.isArray(r.matches) && r.matches.every(m=>m&&m.home&&m.away&&m.home!==m.away));
  }
  // Verificação semântica de uma competição (ponto 3.2 da auditoria externa): fixtureSaveIsValid
  // acima só confirma a FORMA da gravação (arrays com home/away distintos), não o CONTEÚDO — uma
  // gravação corrompida podia ter jogos entre clubes que não pertencem à competição, clubes que já
  // nem existem, resultados inválidos, ou um calendário que já não é um round-robin coerente
  // (pares a repetir-se, jogos em casa/fora desequilibrados). Aceita tanto a forma em memória
  // (fixtures = array de jornadas, cada jornada um array de jogos) como a forma gravada/serializada
  // (fixtures = array de {date, matches:[...]}), para poder ser reutilizada em ambos os contextos.
  // Reutiliza validateFixtures (03-calendario.js) para a estrutura round-robin em vez de
  // reimplementar a contagem de pares/casa-fora — essa função já é a fonte de verdade usada na
  // própria geração do calendário (generateValidatedFixtures).
  function validateCompetitionSnapshot(comp, teams){
    const problems=[];
    if(!comp || typeof comp!=="object"){ problems.push("competição em falta"); return problems; }
    const label=comp.id||"?";
    const teamIds=Array.isArray(comp.teamIds)?comp.teamIds:[];
    if(!teamIds.length){ problems.push(`${label}: sem equipas`); return problems; }
    if(new Set(teamIds).size!==teamIds.length) problems.push(`${label}: equipas duplicadas na competição`);
    teamIds.forEach(id=>{ if(!teams||!teams[id]) problems.push(`${label}: equipa inexistente na competição (${id})`); });
    const roundsRaw=Array.isArray(comp.fixtures)?comp.fixtures:[];
    // Competições que o utilizador ainda não escolheu (as três divisões de topo, antes de
    // chooseClub) ficam legitimamente com fixtures:[] até serem geradas por defaultCompetitionSnapshot
    // — não é um calendário corrompido, é um calendário ainda por gerar. Nada mais há a validar.
    if(!roundsRaw.length) return problems;
    const rounds=roundsRaw.map(r=>Array.isArray(r)?r:(r&&Array.isArray(r.matches)?r.matches:null));
    if(rounds.some(r=>r===null)){ problems.push(`${label}: calendário com formato irreconhecível`); return problems; }
    const teamIdSet=new Set(teamIds);
    rounds.forEach((round,idx)=>{
      round.forEach(m=>{
        if(!m||!m.home||!m.away||m.home===m.away){ problems.push(`${label}: jogo inválido na jornada ${idx+1}`); return; }
        if(!teamIdSet.has(m.home)||!teamIdSet.has(m.away)) problems.push(`${label}: jogo com clube fora da competição na jornada ${idx+1} (${m.home} vs ${m.away})`);
        if(teams && (!teams[m.home]||!teams[m.away])) problems.push(`${label}: jogo com clube inexistente na jornada ${idx+1} (${m.home} vs ${m.away})`);
        if(m.played && (!Number.isFinite(Number(m.homeScore))||!Number.isFinite(Number(m.awayScore)))) problems.push(`${label}: resultado inválido na jornada ${idx+1} (${m.home} vs ${m.away})`);
      });
    });
    // A validação round-robin completa (pares exatamente 2x, casa/fora equilibrados, byes
    // corretos) só faz sentido sobre um calendário já confirmado limpo acima — evita relatórios
    // duplicados/confusos quando já há jogos com clubes inválidos.
    if(!problems.length && !validateFixtures(rounds, teamIds)) problems.push(`${label}: calendário não corresponde a um round-robin válido`);
    return problems;
  }
  function inferCompetitionIdForTeamId(teamId,teams){
    const team=(teams||{})[teamId];
    if(team&&team.divisaoAtual==="2div") return `2div-${team.zona==="sul"?"sul":"norte"}-2026-27`;
    if(team&&team.divisaoAtual==="ok-liga-plata") return `ok-liga-plata-${team.zona==="sul"?"sul":"norte"}-2026-27`;
    const def=CLUB_DEFS.find(d=>d.id===teamId);
    return clubDefinitionCompetitionId(def||{});
  }
  function defaultCompetitionSnapshot(id,season){
    const comp=state.competitions[id];
    // As datas do calendário dependem de state.season (assignFixtureDatesFor): para uma gravação com
    // outra época, usa-se a época da própria gravação em vez da da sessão atual.
    const keepSeason=state.season; if(season!=null) state.season=season;
    try{
      const fixtures=generateValidatedFixtures(comp.teamIds); assignFixtureDatesFor({...comp,fixtures});
      return {id,teamIds:comp.teamIds.slice(),currentRound:0,status:"regular",fixtures:serializeCompetitionFixtures(fixtures)};
    } finally { state.season=keepSeason; }
  }
  // OK Liga Plata acrescentada a uma gravação anterior à v42, a meio da época: as jornadas já passadas
  // (por data) nunca seriam jogadas — a agenda só trata o dia exato — e a época nunca fecharia.
  // Simula-as de uma vez, por IA, logo depois do carregamento.
  function catchUpPlataRounds(){
    const hoje=new Date(state.currentDate);
    (state.globalAgenda||[]).filter(e=>/^ok-liga-plata-/.test(e.competitionId)&&e.status==="pendente"&&e.date<hoje&&!sameDay(e.date,hoje))
      .sort((a,b)=>a.date-b.date||a.competitionId.localeCompare(b.competitionId)||a.roundIndex-b.roundIndex).forEach(event=>{
        const comp=state.competitions[event.competitionId]; if(!comp) return;
        if(comp.currentRound!==event.roundIndex) comp.currentRound=event.roundIndex;
        processCompetitionRoundFullyAI(comp); markAgendaEventProcessed(event.id); syncCompetitionStatus(comp);
      });
  }
  function migrateSaveObject(raw){
    if(!raw || typeof raw!=="object") throw new Error("O ficheiro não contém uma gravação válida.");
    const sourceVersion=Number(raw.version||6);
    if(sourceVersion<MIN_SUPPORTED_SAVE_VERSION) throw new Error(`Gravações anteriores à versão ${MIN_SUPPORTED_SAVE_VERSION} não são suportadas.`);
    if(sourceVersion>SAVE_VERSION) throw new Error(`Esta gravação foi criada numa versão mais recente do jogo (v${sourceVersion}).`);
    const save=JSON.parse(JSON.stringify(raw));
    // Os plantéis das seleções vêm gravados só como referências (__selecaoRef): recompõem-se já aqui, antes da
    // migração e da validação (que exigem jogadores completos) — senão qualquer gravação com seleções falha.
    relinkSelecaoSquadsOnLoad(save.teams);
    // OK Liga Plata (v42, 2026-10-21): gravações anteriores não têm os 28 clubes da 2.ª divisão
    // espanhola — entram já aqui, com os plantéis provisórios iniciais (normalizeLoadedTeams
    // trata depois das finanças, identidade tática, academia e treinador de cada um).
    if(save.teams && typeof save.teams==="object"){
      const novos=JSON.parse(PLATA_FRESH_TEAMS_JSON);
      Object.keys(novos).forEach(id=>{ if(!save.teams[id]) save.teams[id]=novos[id]; });
    }
    // Apuramentos da 3.ª Divisão (2026-10-16): são competições criadas a meio da época — numa página
    // nova não existem em state.competitions e eram descartadas ao carregar (resultados perdidos e
    // recriados a partir de tabelas já contaminadas). Ao contrário, ao carregar um save SEM elas,
    // as que existissem na sessão atual ficavam a mais. Sincroniza-as com o save antes de migrar.
    {
      const APUR=["3div-apuramento-campeao-2026-27","3div-apuramento-promocao-2026-27"];
      const noSave=new Map((Array.isArray(save.competitionState)?save.competitionState:[]).filter(c=>c&&APUR.includes(c.id)).map(c=>[c.id,c]));
      APUR.forEach(id=>{
        const c=noSave.get(id);
        if(!c){ delete state.competitions[id]; return; }
        if(!state.competitions[id]) state.competitions[id]={ id, divisionId:"3div", zona:null, epoca:Number(save.season)||state.season, teamIds:Array.isArray(c.teamIds)?c.teamIds.slice():[], fixtures:[], currentRound:0, playoff:null, status:"regular", reputacaoCompeticao:35 };
      });
    }
    save.migratedFromVersion=sourceVersion; save.version=SAVE_VERSION;
    // Saves antigos podem não ter todos os campos usados pelo novo motor de evolução.
    // Apenas preenche ausências; potencial, atributos, utilização e históricos existentes
    // nunca são recalculados nem reduzidos, incluindo jogadores legados acima do potencial.
    const normalizeDevelopmentPlayer=player=>{
      if(!player||typeof player!=="object")return player;
      if(!player.attrs||typeof player.attrs!=="object")player.attrs={};
      if(!Number.isFinite(Number(player.potential)))player.potential=overall(player);
      ensurePlayerStatsStructure(player);
      if(!Array.isArray(player.historico))player.historico=[];
      return player;
    };
    Object.values(save.teams||{}).forEach(team=>(team.players||[]).forEach(normalizeDevelopmentPlayer));
    ["freeAgents","inactivePlayers","youthCandidates"].forEach(key=>(save[key]||[]).forEach(normalizeDevelopmentPlayer));
    save.managerName=String(save.managerName||"");
    if(!save.userTeamId || !(save.teams||{})[save.userTeamId]) throw new Error("A gravação não identifica corretamente o clube do utilizador.");
    save.season=Math.max(1,parseInt(save.season,10)||1);
    save.currentRound=Math.max(0,parseInt(save.currentRound,10)||0);
    save.currentDate=safeIsoDate(save.currentDate,"2026-09-01T00:00:00.000Z");
    save.userCompetitionId=save.userCompetitionId||inferCompetitionIdForTeamId(save.userTeamId,save.teams);
    if(!state.competitions[save.userCompetitionId]) save.userCompetitionId="placard-2026-27";
    save.viewedCompetitionId=state.competitions[save.viewedCompetitionId]?save.viewedCompetitionId:save.userCompetitionId;
    if(!Array.isArray(save.news)) save.news=[];
    // Migração da caixa de e-mail (2026-09-16): gravações antigas não tinham remetente/arquivo —
    // ganham-nos aqui, de forma invisível, com base no "kind" já existente. resolveNewsSender já
    // está disponível nesta fase (definida em 01-nucleo.js, mesma IIFE).
    save.news=save.news.map(n=>({...n,date:safeIsoDate(n.date,save.currentDate),sender:n.sender||resolveNewsSender(n.kind||"geral"),archived:!!n.archived,read:n.read!=null?!!n.read:true}));
    save.__plataCatchUp=!(save.competitionState||[]).some(c=>c&&/^ok-liga-plata-/.test(c.id));
    const existing={};
    (save.competitionState||[]).forEach(c=>{if(c&&state.competitions[c.id]) existing[c.id]=c;});
    (save.otherCompetitions||[]).forEach(c=>{if(c&&state.competitions[c.id]&&!existing[c.id])existing[c.id]=c;});
    if(fixtureSaveIsValid(save.fixtures)) existing[save.userCompetitionId]={...(existing[save.userCompetitionId]||{}),id:save.userCompetitionId,fixtures:save.fixtures,currentRound:save.currentRound,status:save.seasonOver?"concluida":"regular"};
    save.competitionState=Object.keys(state.competitions).map(id=>{
      const fallback=defaultCompetitionSnapshot(id,save.season),old=existing[id]||{};
      return {id,teamIds:Array.isArray(old.teamIds)&&old.teamIds.length?old.teamIds.slice():fallback.teamIds,currentRound:Math.max(0,parseInt(old.currentRound,10)||0),status:["regular","fase-final","concluida"].includes(old.status)?old.status:"regular",fixtures:fixtureSaveIsValid(old.fixtures)?old.fixtures:fallback.fixtures,playoff:(old.playoff&&old.playoff.series)?old.playoff:null};   // 0.4.19: preserva o quadro do playoff na migração
    });
    // Consolidação 3.4: já não se reconstroem aqui os campos legados save.fixtures/
    // save.otherCompetitions a partir de competitionState — nada os volta a ler depois disto
    // (applySaveObjectUnchecked passou a depender só de competitionState). save.currentRound
    // mantém-se, sincronizado com a competição do utilizador, por ser um campo de topo simples
    // e sem custo, não outra cópia do calendário.
    const userComp=save.competitionState.find(c=>c.id===save.userCompetitionId);
    save.currentRound=Math.min(userComp.currentRound,userComp.fixtures.length);
    save.globalAgenda=Array.isArray(save.globalAgenda)?save.globalAgenda.filter(e=>e&&state.competitions[e.competitionId]).map(e=>({...e,date:safeIsoDate(e.date,save.currentDate),processedAt:e.processedAt?safeIsoDate(e.processedAt,save.currentDate):null})):[];
    save.transferMarket=Array.isArray(save.transferMarket)?save.transferMarket:[]; save.transferHistory=Array.isArray(save.transferHistory)?save.transferHistory:[]; save.internalTransferHistory=Array.isArray(save.internalTransferHistory)?save.internalTransferHistory:[]; save.marketDecisionHistory=Array.isArray(save.marketDecisionHistory)?save.marketDecisionHistory:[]; save.clubMovements=Array.isArray(save.clubMovements)?save.clubMovements:[];
    save.lastSeasonSummary=save.lastSeasonSummary||null;
    // Supertaça António Livramento (save v39+): saves anteriores nunca tiveram este campo — ficam
    // com histórico vazio e sem jogo pendente; a próxima transição de época (finalizeNewSeason)
    // gera a edição corrente normalmente, a partir do resumo dessa época (já com
    // tacaVencedorId/tacaFinalistaId a partir daqui em diante).
    save.supertaca = save.supertaca && typeof save.supertaca==="object"
      ? { historico: Array.isArray(save.supertaca.historico)?save.supertaca.historico:[], jogo: save.supertaca.jogo||null }
      : { historico: [], jogo: null };
    // Elite Cup (save v39+, migração aditiva): saves anteriores nunca tiveram este campo — ficam
    // com histórico vazio e sem edição corrente; a próxima transição de época (finalizeNewSeason)
    // ou, se ainda for a 1.ª carreira, o próprio chooseClub, geram a edição normalmente.
    save.eliteCup = save.eliteCup && typeof save.eliteCup==="object"
      ? { historico: Array.isArray(save.eliteCup.historico)?save.eliteCup.historico:[], edicao: save.eliteCup.edicao||null }
      : { historico: [], edicao: null };
    // "preSeasonLeagueStart" (aditivo): novo valor de state.eliteCupPostSequence introduzido
    // quando a janela de mercado da 1.ª carreira passou a abrir ANTES da Elite Cup em vez de
    // depois — ver chooseClub/finalizePreSeasonDefeso em 05-ui-navegacao.js e
    // eliteCupRunPostSequence em 07d-elite-cup.js. "preSeasonDefeso" mantém-se na lista só para
    // saves antigos gravados a meio da Elite Cup antes desta correção.
    save.eliteCupPostSequence = ["preSeasonDefeso","preSeasonLeagueStart","newSeasonTail"].includes(save.eliteCupPostSequence) ? save.eliteCupPostSequence : null;
    // Copa del Rey / Coppa Italia / Supercopa de España / Supercoppa Italiana (save v40+,
    // migração aditiva, mesmo princípio da Supertaça/Elite Cup acima): saves anteriores nunca
    // tiveram estes campos — ficam com histórico vazio e sem edição corrente; a próxima
    // transição de época (ou, na Copa del Rey/Coppa Italia, a própria OK Liga/Serie A1 ao
    // completarem a 1ª volta) gera a edição normalmente.
    save.copaDelRey = save.copaDelRey && typeof save.copaDelRey==="object"
      ? { historico: Array.isArray(save.copaDelRey.historico)?save.copaDelRey.historico:[], edicao: save.copaDelRey.edicao||null }
      : { historico: [], edicao: null };
    save.coppaItalia = save.coppaItalia && typeof save.coppaItalia==="object"
      ? { historico: Array.isArray(save.coppaItalia.historico)?save.coppaItalia.historico:[], edicao: save.coppaItalia.edicao||null }
      : { historico: [], edicao: null };
    // Copa de la Princesa (save v43): saves anteriores não a têm — histórico vazio, sem edição
    // corrente; apura-se sozinha quando as duas zonas da Plata completarem a 1.ª volta.
    save.copaPrincesa = save.copaPrincesa && typeof save.copaPrincesa==="object"
      ? { historico: Array.isArray(save.copaPrincesa.historico)?save.copaPrincesa.historico:[], edicao: save.copaPrincesa.edicao||null }
      : { historico: [], edicao: null };
    save.supercopaEspana = save.supercopaEspana && typeof save.supercopaEspana==="object"
      ? { historico: Array.isArray(save.supercopaEspana.historico)?save.supercopaEspana.historico:[], edicao: save.supercopaEspana.edicao||null }
      : { historico: [], edicao: null };
    save.supercoppaItaliana = save.supercoppaItaliana && typeof save.supercoppaItaliana==="object"
      ? { historico: Array.isArray(save.supercoppaItaliana.historico)?save.supercoppaItaliana.historico:[], jogo: save.supercoppaItaliana.jogo||null }
      : { historico: [], jogo: null };
    save.okLigaRunnerUp = save.okLigaRunnerUp || null;
    save.serieA1RunnerUp = save.serieA1RunnerUp || null;
    // Competições Europeias (save v41+, migração aditiva — mesmo princípio das provas acima):
    // saves anteriores nunca tiveram este campo — ficam sem coeficientes/histórico/edição
    // corrente; a próxima transição de época (ou, na 1ª carreira, o próprio chooseClub) gera tudo
    // de novo a partir do zero (europaInitEdition), e ensureEuropaNuvemClubes() (chamado ao
    // carregar) preenche os clubes da nuvem em falta.
    save.europa = save.europa && typeof save.europa==="object"
      ? { nuvemGerada:!!save.europa.nuvemGerada, coefPais: save.europa.coefPais&&typeof save.europa.coefPais==="object"?save.europa.coefPais:{}, coefClube: save.europa.coefClube&&typeof save.europa.coefClube==="object"?save.europa.coefClube:{}, historico: Array.isArray(save.europa.historico)?save.europa.historico:[], edicao: save.europa.edicao||null }
      : { nuvemGerada:false, coefPais:{}, coefClube:{}, historico:[], edicao:null };
    save.pendingEuropaSlot = save.pendingEuropaSlot || null;
    // Seleções Nacionais (2026-09-26, save v?+, migração aditiva — mesmo princípio das provas
    // acima): saves anteriores a esta correção (2026-09-27) nunca gravavam nada disto — a edição
    // em curso, se houver, fica-se por aqui (o utilizador perde a resolução dessa edição
    // específica, tal como já acontecia com qualquer outro campo aditivo novo), mas
    // selecoesProxima/selecoesRanking/selecoesHistorico só ficam vazios na 1ª carga de um save
    // antigo — a alternância Mundial/Europeu recomeça do zero (sempre Mundial primeiro) a partir
    // daí, nunca fica presa nem gera erro.
    save.selecoesHistorico = Array.isArray(save.selecoesHistorico) ? save.selecoesHistorico : [];
    save.selecoesRanking = save.selecoesRanking && typeof save.selecoesRanking==="object" ? save.selecoesRanking : {};
    save.selecoesProxima = save.selecoesProxima || null;
    save.selecoesUltimaConvocatoria = save.selecoesUltimaConvocatoria && typeof save.selecoesUltimaConvocatoria==="object" ? save.selecoesUltimaConvocatoria : {};
    save.selecoes = save.selecoes && typeof save.selecoes==="object" ? { edicao: save.selecoes.edicao||null, edicaoS19: save.selecoes.edicaoS19||null } : { edicao: null, edicaoS19: null };
    // Seleccionador Nacional — Acumulação de Cargo (2026-10-03): migração aditiva, mesmo
    // princípio das linhas de Seleções acima — saves anteriores a esta funcionalidade ficam
    // simplesmente sem nenhuma convocatória manual pendente.
    save.pendingNationalSquadPick = save.pendingNationalSquadPick && typeof save.pendingNationalSquadPick==="object" ? save.pendingNationalSquadPick : null;
    save.validationHistory=Array.isArray(save.validationHistory)?save.validationHistory:[]; save.saveGrowthAudit=save.saveGrowthAudit&&typeof save.saveGrowthAudit==="object"?save.saveGrowthAudit:null; save.calibrationValidationReport=save.calibrationValidationReport&&typeof save.calibrationValidationReport==="object"?save.calibrationValidationReport:null; save.calibrationValidationHistory=Array.isArray(save.calibrationValidationHistory)?save.calibrationValidationHistory:[]; save.marketLastRefreshSeason=save.marketLastRefreshSeason||null; save.convocadosSelecionados=save.convocadosSelecionados||null;
    // Fase 12/13: contratos completos, jogadores livres e defeso já processado nesta época.
    save.freeAgents=Array.isArray(save.freeAgents)?save.freeAgents:[];
    save.contractNegotiations=save.contractNegotiations&&typeof save.contractNegotiations==="object"?save.contractNegotiations:{};
    save.transferNegotiations=save.transferNegotiations&&typeof save.transferNegotiations==="object"?save.transferNegotiations:{};
    save.loanNegotiations=save.loanNegotiations&&typeof save.loanNegotiations==="object"?save.loanNegotiations:{};
    save.aiOffers=Array.isArray(save.aiOffers)?save.aiOffers:[]; save.loanHistory=Array.isArray(save.loanHistory)?save.loanHistory:[]; save.lastAiOfferDate=save.lastAiOfferDate||null;
    save.defesoProcessedSeason=save.defesoProcessedSeason!=null?save.defesoProcessedSeason:null;
    save.aiToAiMarketProcessedSeason=save.aiToAiMarketProcessedSeason!=null?save.aiToAiMarketProcessedSeason:null;
    save.lastTacticalTrainingDate=save.lastTacticalTrainingDate||null;
    save.lastMonthlyTacticalReport=save.lastMonthlyTacticalReport||null;
    Object.values(save.teams||{}).forEach(team=>{
      team.historicoMudancasDivisao=Array.isArray(team.historicoMudancasDivisao)?team.historicoMudancasDivisao:[];
      team.titulosClube=Array.isArray(team.titulosClube)?team.titulosClube:[];
      team.historicoReputacao=Array.isArray(team.historicoReputacao)?team.historicoReputacao:[];
      (team.players||[]).forEach(player=>{player.participacaoCompeticoes=player.participacaoCompeticoes&&typeof player.participacaoCompeticoes==="object"?player.participacaoCompeticoes:{};if(!Array.isArray(player.titulos))player.titulos=[];});
      team.planoFinanceiroMudancaDivisao=team.planoFinanceiroMudancaDivisao&&typeof team.planoFinanceiroMudancaDivisao==="object"?team.planoFinanceiroMudancaDivisao:null;
      if(team.financeiro){
        const f=team.financeiro;f.historicoAnual=Array.isArray(f.historicoAnual)?f.historicoAnual:[];f.calibracaoEconomica=f.calibracaoEconomica&&typeof f.calibracaoEconomica==="object"?f.calibracaoEconomica:{versao:ECONOMIC_CALIBRATION.version,mesesProcessados:0,historicoEstrutura:[]};f.calibracaoEconomica.versao=ECONOMIC_CALIBRATION.version;f.calibracaoEconomica.historicoEstrutura=Array.isArray(f.calibracaoEconomica.historicoEstrutura)?f.calibracaoEconomica.historicoEstrutura:[];f.auditoriaEpoca=f.auditoriaEpoca&&typeof f.auditoriaEpoca==="object"?f.auditoriaEpoca:{receitas:{},despesas:{}};f.auditoriaEpoca.receitas=f.auditoriaEpoca.receitas||{};f.auditoriaEpoca.despesas=f.auditoriaEpoca.despesas||{};f.saldoInicialEpoca=Number.isFinite(+f.saldoInicialEpoca)?+f.saldoInicialEpoca:(+f.saldo||0);f.dividaInicialEpoca=Number.isFinite(+f.dividaInicialEpoca)?+f.dividaInicialEpoca:(+f.divida||0)+(+f.creditoUtilizado||0);f.estadoCriseInicioEpoca=f.estadoCriseInicioEpoca||f.estadoCriseFinanceira||"normal";f.adaptacoesDivisaoAplicadas=Array.isArray(f.adaptacoesDivisaoAplicadas)?f.adaptacoesDivisaoAplicadas:[];
        f.estadoCriseFinanceira=["normal","critica","insolvencia","falencia"].includes(f.estadoCriseFinanceira)?f.estadoCriseFinanceira:"normal";
        f.mesesCriticosConsecutivos=Math.max(0,parseInt(f.mesesCriticosConsecutivos,10)||0);f.mesesInsolventeConsecutivos=Math.max(0,parseInt(f.mesesInsolventeConsecutivos,10)||0);f.mesesRecuperacaoConsecutivos=Math.max(0,parseInt(f.mesesRecuperacaoConsecutivos,10)||0);
        f.historicoCriseFinanceira=Array.isArray(f.historicoCriseFinanceira)?f.historicoCriseFinanceira:[];f.restricoesInsolvencia=!!f.restricoesInsolvencia;f.elegivelFalencia=!!f.elegivelFalencia;f.ultimaAdvertenciaEmitida=!!f.ultimaAdvertenciaEmitida;f.administracaoFinanceira=!!f.administracaoFinanceira;f.recapitalizacoesCrise=Math.max(0,parseInt(f.recapitalizacoesCrise,10)||0);
      }
    });
    save.youthCandidates=Array.isArray(save.youthCandidates)?save.youthCandidates:[];
    save.youthDecisionHistory=Array.isArray(save.youthDecisionHistory)?save.youthDecisionHistory:[];
    save.inactivePlayers=Array.isArray(save.inactivePlayers)?save.inactivePlayers:[];
    save.inactivePlayers=save.inactivePlayers.map((r,i)=>({...r,id:r.id||`legacy-inactive:${i}`,status:"inativo",inactiveReason:r.inactiveReason||"excesso-mercado",inactiveSeason:r.inactiveSeason||null,inactiveDate:r.inactiveDate||save.currentDate,seasonsUnsigned:Number(r.seasonsUnsigned||r.__seasonsUnsigned||0)}));
    save.retiredPlayers=Array.isArray(save.retiredPlayers)?save.retiredPlayers:[];
    save.retiredPlayers=save.retiredPlayers.map((r,i)=>({id:r.id||`legacy-retired:${i}:${String(r.name||"jogador").toLowerCase().replace(/\s+/g,"-")}`,name:r.name||"Jogador",age:r.age!=null?r.age:null,dataNascimento:r.dataNascimento||null,overallFinal:r.overallFinal!=null?r.overallFinal:null,reputacaoFinal:r.reputacaoFinal!=null?r.reputacaoFinal:null,clubeFinalId:r.clubeFinalId||null,clubeFinalNome:r.clubeFinalNome||(Array.isArray(r.clubes)&&r.clubes[0])||"Sem clube",pos:r.pos||null,linha:r.linha||null,clubes:Array.isArray(r.clubes)?r.clubes:[],jogos:r.jogos||0,golos:r.golos||0,assistencias:r.assistencias||0,titulos:Array.isArray(r.titulos)?r.titulos:(r.titulos||0),internacionalizacoes:r.internacionalizacoes||0,golosInternacional:r.golosInternacional||0,epocaReforma:r.epocaReforma||null}));
    save.retirementsProcessedSeason=save.retirementsProcessedSeason!=null?save.retirementsProcessedSeason:null;
    save.newGenerationProcessedSeason=save.newGenerationProcessedSeason!=null?save.newGenerationProcessedSeason:null;
    save.playoffActive=!!save.playoffActive; save.playoffClinchedAnnounced=!!save.playoffClinchedAnnounced; save.financePrizeAwarded=!!save.financePrizeAwarded; save.seasonOver=!!save.seasonOver; save.seasonTransitionApplied=!!save.seasonTransitionApplied;
    // Calibração financeira (proposta P5): migração aditiva — gravações antigas não têm este
    // campo, começam com o fundo vazio.
    save.fundoSolidariedadeEpoca=Math.max(0,Number(save.fundoSolidariedadeEpoca)||0);
    // Carreira do treinador (2026-09-05): migração aditiva — gravações antigas não têm este
    // campo, começam com reputação neutra (50), empregado, e sem historial/candidaturas/ofertas.
    // Nível 3 (2026-09-05): epocaInicioClube/reputacaoMaxima e titulos/temporadas por mandato são
    // aditivos sobre o mesmo objeto — gravações do Nível 1/2 simplesmente não os têm ainda.
    // Correção (bug pré-existente, encontrado ao acrescentar os 3 campos da Selecção Nacional
    // abaixo a este mesmo objeto): esta reconstrução nunca incluía stats/dataNascimento/
    // paisOrigem/nacionalidade/mandatoAtual — eram sempre silenciosamente perdidos em CADA
    // save/load (não só em saves antigos sem eles), e ensureManagerCareer() (04-financas.js),
    // chamada logo a seguir a carregar, regenerava-os do zero sempre que faltavam — stats/
    // dataNascimento de forma inofensiva (deterministicos pela mesma semente da carreira, saem
    // sempre iguais), mas mandatoAtual via defaultTreinadorMandato() começava sempre um mandato
    // NOVO, apagando jogos/vitórias/empates/derrotas do mandato em curso no clube a cada load, e
    // paisOrigem/nacionalidade voltavam sempre a "pt" por omissão, perdendo qualquer outra
    // nacionalidade escolhida. Os valores passam agora tal e qual quando presentes (undefined
    // quando o save é mesmo anterior a esta funcionalidade) — ensureManagerCareer() continua a
    // ser a única fonte de defaults/validação mais profunda, agora só para saves que realmente
    // não têm o campo.
    save.gestor=save.gestor&&typeof save.gestor==="object"
      ? {reputacao:Number.isFinite(save.gestor.reputacao)?save.gestor.reputacao:50,empregado:save.gestor.empregado!==false,dataInicioClube:save.gestor.dataInicioClube||null,epocaInicioClube:Number.isFinite(save.gestor.epocaInicioClube)?save.gestor.epocaInicioClube:save.season,reputacaoMaxima:Number.isFinite(save.gestor.reputacaoMaxima)?save.gestor.reputacaoMaxima:(Number.isFinite(save.gestor.reputacao)?save.gestor.reputacao:50),dataDespedimento:save.gestor.dataDespedimento||null,historico:Array.isArray(save.gestor.historico)?save.gestor.historico.map(h=>({...h,titulos:Array.isArray(h.titulos)?h.titulos:[],temporadas:Array.isArray(h.temporadas)?h.temporadas:[]})):[],candidaturas:Array.isArray(save.gestor.candidaturas)?save.gestor.candidaturas:[],ofertas:Array.isArray(save.gestor.ofertas)?save.gestor.ofertas:[],
          stats:save.gestor.stats&&typeof save.gestor.stats==="object"?save.gestor.stats:undefined,
          dataNascimento:save.gestor.dataNascimento||undefined,
          paisOrigem:save.gestor.paisOrigem||undefined,
          nacionalidade:save.gestor.nacionalidade||undefined,
          mandatoAtual:save.gestor.mandatoAtual&&typeof save.gestor.mandatoAtual==="object"?save.gestor.mandatoAtual:undefined,
          // Selecção Nacional — Acumulação de Cargo (2026-10-03): três campos aditivos novos,
          // mesmo padrão idempotente do resto de ensureManagerCareer() para o caso de faltarem.
          selecaoAtual:save.gestor.selecaoAtual&&typeof save.gestor.selecaoAtual==="object"?save.gestor.selecaoAtual:null,
          selecaoHistorico:Array.isArray(save.gestor.selecaoHistorico)?save.gestor.selecaoHistorico:[],
          convitesSelecao:Array.isArray(save.gestor.convitesSelecao)?save.gestor.convitesSelecao:[],
          serieReputacao:Array.isArray(save.gestor.serieReputacao)?save.gestor.serieReputacao:[]} // 2026-10-16: o gráfico de reputação perdia o histórico a cada carregamento
      : {reputacao:50,empregado:true,dataInicioClube:null,epocaInicioClube:save.season,reputacaoMaxima:50,dataDespedimento:null,historico:[],candidaturas:[],ofertas:[],selecaoAtual:null,selecaoHistorico:[],convitesSelecao:[]};
    Object.values(save.teams||{}).forEach(team=>{
      team.titulosClube=Array.from(new Map((team.titulosClube||[]).filter(Boolean).map(x=>[x.id||`${x.competicao}:${x.epoca}`,x])).values());
      team.historicoMudancasDivisao=Array.from(new Map((team.historicoMudancasDivisao||[]).filter(Boolean).map(x=>[x.key||`${x.epoca}:${x.divisaoOrigem}>${x.divisaoDestino}`,x])).values());
      team.historicoReputacao=Array.from(new Map((team.historicoReputacao||[]).filter(Boolean).map(x=>[x.epoca,x])).values());
      (team.players||[]).forEach(p=>{p.titulos=Array.from(new Set(p.titulos||[]));p.careerArchivesApplied=Array.from(new Set(p.careerArchivesApplied||[]));});
    });
    save.retiredPlayers=Array.from(new Map((save.retiredPlayers||[]).filter(Boolean).map(x=>[x.id,x])).values());
    save.inactivePlayers=Array.from(new Map((save.inactivePlayers||[]).filter(Boolean).map(x=>[x.id,x])).values());
    save.gameOver=!!save.gameOver; save.gameOverReason=save.gameOverReason||null;
    save.gameOverSnapshot=save.gameOverSnapshot&&typeof save.gameOverSnapshot==="object"?save.gameOverSnapshot:null;
    save.gameOverAt=save.gameOverAt?safeIsoDate(save.gameOverAt,save.currentDate):null;
    save.savedAt=safeIsoDate(save.savedAt||Date.now()); save.schema="hm2027-save";
    return save;
  }
  function validateMigratedSave(save){
    const errors=[];
    if(save.version!==SAVE_VERSION) errors.push("versão incorreta");
    if(!save.teams||!save.teams[save.userTeamId]) errors.push("clube do utilizador em falta");
    Object.values(save.teams||{}).forEach(team=>(team.players||[]).forEach(player=>{
      if(!Array.isArray(player.historico)) errors.push(`histórico inválido: ${team.name}/${player.name}`);
      if(!player.attrs||typeof player.attrs!=="object") errors.push(`atributos inválidos: ${team.name}/${player.name}`);
      if(!Number.isFinite(Number(player.potential))) errors.push(`potencial inválido: ${team.name}/${player.name}`);
      const emptySeason=createEmptyStats("season"),emptyCareer=createEmptyStats("career");
      if(!player.season||typeof player.season!=="object"||Object.keys(emptySeason).some(key=>player.season[key]==null)) errors.push(`época do jogador inválida: ${team.name}/${player.name}`);
      if(!player.career||typeof player.career!=="object"||Object.keys(emptyCareer).some(key=>player.career[key]==null)) errors.push(`carreira do jogador inválida: ${team.name}/${player.name}`);
      (player.historico||[]).forEach(row=>{
        if(row.movimento && !["livre","emprestimo","transferencia"].includes(row.movimento.tipo))
          errors.push(`movimento histórico inválido: ${team.name}/${player.name}`);
      });
    }));
    ["freeAgents","inactivePlayers","youthCandidates"].forEach(pool=>(save[pool]||[]).forEach(player=>{
      const emptySeason=createEmptyStats("season"),emptyCareer=createEmptyStats("career");
      if(!player||!player.season||typeof player.season!=="object"||Object.keys(emptySeason).some(key=>player.season[key]==null)) errors.push(`época do jogador inválida: ${pool}/${player&&player.name||"?"}`);
      if(!player||!player.career||typeof player.career!=="object"||Object.keys(emptyCareer).some(key=>player.career[key]==null)) errors.push(`carreira do jogador inválida: ${pool}/${player&&player.name||"?"}`);
    }));
    const retiredIds=new Set((save.retiredPlayers||[]).map(x=>x.id)),inactiveIds=(save.inactivePlayers||[]).map(x=>x.id);
    if(new Set(inactiveIds).size!==inactiveIds.length) errors.push("IDs duplicados nos inativos");
    if(inactiveIds.some(id=>retiredIds.has(id))) errors.push("jogador simultaneamente reformado e inativo");
    if((save.retiredPlayers||[]).some(r=>r.age!=null&&r.age<34)) errors.push("reforma real abaixo dos 34 anos");
    if(save.gameOver&&(!save.gameOverReason||!save.gameOverSnapshot||!save.gameOverAt)) errors.push("Game Over incompleto");
    Object.values(save.teams||{}).forEach(team=>{const f=team.financeiro;if(!f)return;if(!["normal","critica","insolvencia","falencia"].includes(f.estadoCriseFinanceira||"normal"))errors.push(`estado de crise inválido: ${team.name}`);if(!Array.isArray(f.historicoCriseFinanceira))errors.push(`histórico de crise inválido: ${team.name}`);});
    if(!Array.isArray(save.competitionState)||save.competitionState.length!==Object.keys(state.competitions).length) errors.push("competições incompletas");
    (save.competitionState||[]).forEach(c=>{
      if(!fixtureSaveIsValid(c.fixtures))errors.push(`calendário inválido: ${c.id}`);
      if(new Set(c.teamIds||[]).size!==(c.teamIds||[]).length)errors.push(`clubes duplicados: ${c.id}`);
      // Verificação semântica adicional (3.2 da auditoria): as duas linhas acima só confirmam a
      // FORMA. Corre em modo consultivo — regista na consola sem bloquear o carregamento — porque
      // esta verificação mais profunda (pertença à competição, round-robin completo, resultados
      // válidos) nunca foi testada contra gravações reais de utilizadores; um falso positivo aqui
      // não pode impedir alguém de carregar o jogo. Fica disponível para endurecer no futuro,
      // depois de correr sem queixas durante algum tempo.
      const semanticProblems=(save.seasonTransitionApplied&&save.inDefeso)?[]:validateCompetitionSnapshot(c, save.teams);   // 0.4.19: saves do defeso (pós-transição) têm clubes novos e calendários antigos — não é erro
      if(semanticProblems.length) console.warn("[HM2027] Inconsistência semântica na competição (não bloqueante):", semanticProblems);
    });
    if(errors.length) throw new Error("Gravação inválida após migração: "+errors.join("; "));
    return true;
  }

  function serializeCompetitionFixtures(fixtures){
    return fixtures.map(round => ({
      date: round.date.toISOString(),
      tvDecidido: !!round.tvDecidido,
      // Correção: __preGameReportDone (marca transitória de generatePreGameReport, em
      // 09-fluxo-epoca.js) não era gravado — ao carregar um save feito entre a véspera e o dia
      // do jogo, a marca desaparecia e o relatório do treinador adjunto era gerado outra vez,
      // duplicando a notícia. Passa a gravar-se tal como played/homeScore/awayScore.
      matches: round.map(f => ({ home:f.home, away:f.away, played:f.played, homeScore:f.homeScore, awayScore:f.awayScore, soWinner:f.soWinner||null, preGameReportDone:!!f.__preGameReportDone, tv:f.tv||null })),
    }));
  }
  function deserializeCompetitionFixtures(saved){
    return (saved||[]).map(r => {
      const round = r.matches.map(m => {
        const {preGameReportDone, tv, ...rest} = m;
        const fx = { ...rest, soWinner: m.soWinner||null, __preGameReportDone: !!preGameReportDone };
        if(tv) fx.tv = tv;
        return fx;
      });
      round.date = new Date(r.date);
      if(r.tvDecidido) round.tvDecidido = true;
      return round;
    });
  }

  function compactSaveClone(value){ return JSON.parse(JSON.stringify(value)); }
  function compactHistoricalDataForSave(save){
    // Compacta apenas dados operacionais. Históricos desportivos, títulos, reformas,
    // transferências, empréstimos, mudanças de divisão e resumos anuais são preservados.
    save.news=(save.news||[]).slice(0,160);
    save.aiOffers=(save.aiOffers||[]).filter(o=>o&&["pendente","contraproposta","contraproposta-enviada","jogador-a-decidir","a-confirmar"].includes(o.status)).slice(0,80);
    const compactNegotiations=obj=>Object.fromEntries(Object.entries(obj||{}).filter(([,v])=>v&&!["concluida","recusada","expirada","cancelada"].includes(v.status)));
    save.contractNegotiations=compactNegotiations(save.contractNegotiations);
    save.transferNegotiations=compactNegotiations(save.transferNegotiations);
    Object.values(save.teams||{}).forEach(team=>{
      if(team.financeiro&&Array.isArray(team.financeiro.movimentos)) team.financeiro.movimentos=team.financeiro.movimentos.slice(0,100);
      if(Array.isArray(team.historicoTatico)) team.historicoTatico=team.historicoTatico.slice(0,80);
      if(Array.isArray(team.historicoReputacao)) team.historicoReputacao=team.historicoReputacao.slice(-50);
      if(team.financeiro&&Array.isArray(team.financeiro.historicoEpocas)) team.financeiro.historicoEpocas=team.financeiro.historicoEpocas.slice(-50);
      (team.players||[]).forEach(player=>{
        if(Array.isArray(player.careerArchivesApplied)) player.careerArchivesApplied=player.careerArchivesApplied.slice(-40);
        if(Array.isArray(player.historico)) player.historico=player.historico.slice(-60);
      });
    });
    return save;
  }

  function buildSaveObject(){
    const save={
      version: SAVE_VERSION,
      schema: "hm2027-save",
      savedAt: new Date().toISOString(),
      managerName: state.managerName,
      userTeamId: state.userTeamId,
      userCompetitionId: state.userCompetitionId,
      viewedCompetitionId: state.viewedCompetitionId,
      season: state.season,
      currentRound: state.currentRound,
      seasonOver: state.seasonOver,
      seasonOverSinceDate: state.seasonOverSinceDate ? state.seasonOverSinceDate.toISOString() : null,
      seasonCloseStuckWarned: !!state.seasonCloseStuckWarned,
      financePrizeAwarded: !!state.financePrizeAwarded,
      fundoSolidariedadeEpoca: Math.max(0,Number(state.fundoSolidariedadeEpoca)||0),
      gameOver:!!state.gameOver, gameOverReason:state.gameOverReason||null, gameOverSnapshot:state.gameOverSnapshot||null, gameOverAt:state.gameOverAt||null,
      currentDate: state.currentDate ? state.currentDate.toISOString() : null,
      speedMs: state.speedMs,
      convocadosSelecionados: state.convocadosSelecionados || null,
      playoffActive: state.playoffActive,
      playoffClinchedAnnounced: state.playoffClinchedAnnounced,
      playoff: state.playoff ? { ...state.playoff, nextGameDate: state.playoff.nextGameDate.toISOString() } : null,
      news: state.news.map(n => ({ date: n.date.toISOString(), text: n.text, kind: n.kind, title: n.title || deriveNewsTitle(n.text), sender: n.sender || resolveNewsSender(n.kind), archived: !!n.archived, read: !!n.read })),
      // Consolidação do ponto 3.4 da auditoria externa: até aqui, o calendário de cada
      // competição era gravado até 3 vezes — save.fixtures (só a competição do utilizador),
      // save.otherCompetitions (todas as restantes) e save.competitionState (todas, incluindo a
      // do utilizador) — três estruturas paralelas com os mesmos dados, introduzidas em fases
      // diferentes do desenvolvimento e nunca fundidas. A partir de agora só se grava
      // competitionState, que já era a representação mais completa das três (aplySaveObjectUnchecked
      // e migrateSaveObject foram atualizados para dependerem só dela). Saves antigos, já com
      // fixtures/otherCompetitions gravados por versões anteriores do jogo, continuam a
      // carregar-se normalmente — migrateSaveObject mantém a leitura desses campos legados como
      // reserva, só quando competitionState não vier presente ou vier incompleta.
      globalAgenda:(state.globalAgenda||[]).map(e=>({id:e.id,competitionId:e.competitionId,roundIndex:e.roundIndex,date:new Date(e.date).toISOString(),status:e.status,processedAt:e.processedAt?new Date(e.processedAt).toISOString():null})),
      pendingAgendaEventId:state.pendingAgendaEventId||null,
      matchSummaries: JSON.parse(JSON.stringify(state.matchSummaries||{})),
      decisoesFinais: JSON.parse(JSON.stringify(state.decisoesFinais||[])),
      staffRetirados: JSON.parse(JSON.stringify(state.staffRetirados||[])), staffEspecialistas: JSON.parse(JSON.stringify(state.staffEspecialistas||[])), staffPropostas: JSON.parse(JSON.stringify(state.staffPropostas||[])), staffProcessedSeason: state.staffProcessedSeason!=null?state.staffProcessedSeason:null, staffMonthKey: state.staffMonthKey||null,
      competitionArchive: JSON.parse(JSON.stringify(state.competitionArchive||{})),   // 0.4.21: 5 épocas anteriores por competição   // 0.4.20: resumos compactos dos jogos da época
      competitionState:Object.values(state.competitions).map(c=>({id:c.id,teamIds:c.teamIds.slice(),currentRound:c.currentRound,status:c.status,fixtures:serializeCompetitionFixtures(c.fixtures),playoff:c.playoff?JSON.parse(JSON.stringify(c.playoff)):null})),
      plataTie:state.plataTie?{...state.plataTie,games:state.plataTie.games.map(g=>({...g,date:new Date(g.date).toISOString()}))}:null,
      promotionTie:state.promotionTie?{...state.promotionTie,games:state.promotionTie.games.map(g=>({...g,date:new Date(g.date).toISOString()}))}:null,
      secondDivisionFinal:state.secondDivisionFinal?{...state.secondDivisionFinal,games:state.secondDivisionFinal.games.map(g=>({...g,date:new Date(g.date).toISOString()}))}:null,
      tacaPortugal: state.tacaPortugal ? { ...state.tacaPortugal, jogos: Object.fromEntries(Object.entries(state.tacaPortugal.jogos).map(([fase,jogos])=>[fase, jogos.map(j=>({...j, date: j.date?new Date(j.date).toISOString():null}))])) } : null,
      supertaca: state.supertaca ? {
        historico: (state.supertaca.historico||[]).map(e=>({...e, date: e.date?new Date(e.date).toISOString():null})),
        jogo: state.supertaca.jogo ? {...state.supertaca.jogo, date: state.supertaca.jogo.date?new Date(state.supertaca.jogo.date).toISOString():null} : null,
      } : null,
      eliteCup: state.eliteCup ? {
        historico: (state.eliteCup.historico||[]).map(e=>eliteCupSerializeEdition(e)),
        edicao: state.eliteCup.edicao ? eliteCupSerializeEdition(state.eliteCup.edicao) : null,
      } : null,
      eliteCupPostSequence: state.eliteCupPostSequence||null,
      preSeason: state.preSeason ? JSON.parse(JSON.stringify(state.preSeason)) : null,
      arbitros: state.arbitros ? JSON.parse(JSON.stringify(state.arbitros)) : null,
      satelites: state.satelites ? JSON.parse(JSON.stringify(state.satelites)) : null,
      calAmig: state.calAmig ? JSON.parse(JSON.stringify(state.calAmig)) : null,
      lesoes: state.lesoes ? JSON.parse(JSON.stringify(state.lesoes)) : null,
      relB: state.relB ? JSON.parse(JSON.stringify(state.relB)) : null,
      copaDelRey: state.copaDelRey ? {
        historico: (state.copaDelRey.historico||[]).map(e=>nationalCupSerializeEdition(e)),
        edicao: state.copaDelRey.edicao ? nationalCupSerializeEdition(state.copaDelRey.edicao) : null,
      } : null,
      coppaItalia: state.coppaItalia ? {
        historico: (state.coppaItalia.historico||[]).map(e=>nationalCupSerializeEdition(e)),
        edicao: state.coppaItalia.edicao ? nationalCupSerializeEdition(state.coppaItalia.edicao) : null,
      } : null,
      copaPrincesa: state.copaPrincesa ? {
        historico: (state.copaPrincesa.historico||[]).map(e=>nationalCupSerializeEdition(e)),
        edicao: state.copaPrincesa.edicao ? nationalCupSerializeEdition(state.copaPrincesa.edicao) : null,
      } : null,
      supercopaEspana: state.supercopaEspana ? {
        historico: (state.supercopaEspana.historico||[]).map(e=>supercopaEspanaSerializeEdition(e)),
        edicao: state.supercopaEspana.edicao ? supercopaEspanaSerializeEdition(state.supercopaEspana.edicao) : null,
      } : null,
      supercoppaItaliana: state.supercoppaItaliana ? {
        historico: (state.supercoppaItaliana.historico||[]).map(e=>supercoppaItalianaSerializeJogo(e)),
        jogo: state.supercoppaItaliana.jogo ? supercoppaItalianaSerializeJogo(state.supercoppaItaliana.jogo) : null,
      } : null,
      // Competições Europeias (07g-europa.js): os clubes da "nuvem" já vão dentro de state.teams
      // (compactSaveClone(state.teams), abaixo) — só o estado próprio da(s) prova(s) precisa de
      // serialização dedicada (datas em ISO string, tal como as restantes provas acima).
      europa: state.europa ? {
        nuvemGerada: !!state.europa.nuvemGerada,
        coefPais: state.europa.coefPais || {},
        coefClube: state.europa.coefClube || {},
        historico: state.europa.historico || [],
        edicao: state.europa.edicao ? europaSerializeEdicao(state.europa.edicao) : null,
      } : null,
      pendingEuropaSlot: state.pendingEuropaSlot || null,
      // Seleções Nacionais (07h-selecoes.js): historico/ranking/proxima/ultimaConvocatoria não têm
      // nenhuma Date a serializar (só códigos, números e texto) — gravados tal e qual. edicao é a
      // única estrutura com Date (o array dates) — precisa de serialização dedicada (mesmo
      // princípio de europa.edicao, acima), correção necessária a partir de 2026-09-27, quando a
      // resolução do torneio passou a estender-se por vários dias reais (antes disso, o torneio
      // resolvia-se sempre por completo numa única chamada síncrona, nunca ficando "em curso"
      // entre dois saves).
      selecoesHistorico: state.selecoesHistorico || [],
      selecoesRanking: state.selecoesRanking || {},
      selecoesProxima: state.selecoesProxima || null,
      selecoesUltimaConvocatoria: state.selecoesUltimaConvocatoria || {},
      selecoes: state.selecoes ? { edicao: state.selecoes.edicao ? selecaoSerializeEdicao(state.selecoes.edicao) : null, edicaoS19: state.selecoes.edicaoS19 ? selecaoSerializeEdicao(state.selecoes.edicaoS19) : null } : null,
      okLigaRunnerUp: state.okLigaRunnerUp||null, serieA1RunnerUp: state.serieA1RunnerUp||null,
      placardChampion:state.placardChampion||null, okLigaChampion:state.okLigaChampion||null, serieA1Champion:state.serieA1Champion||null, promotionEvent:state.promotionEvent||null,
      seasonTransitionApplied:!!state.seasonTransitionApplied,
      bTeamsExtintas: Array.isArray(state.bTeamsExtintas)?state.bTeamsExtintas.slice():[],
      // 3.ª Divisão (2026-10-16): snapshot dos vencedores de zona e marca do título processado —
      // sem estes, carregar a meio dos apuramentos relia tabelas já "contaminadas" e repetia o título.
      terceiraDivisaoZoneWinners:Array.isArray(state.terceiraDivisaoZoneWinners)?state.terceiraDivisaoZoneWinners.slice():null,
      derbies:state.derbies&&typeof state.derbies==="object"?JSON.parse(JSON.stringify(state.derbies)):null,
      terceiraDivisaoZoneTables:state.terceiraDivisaoZoneTables&&typeof state.terceiraDivisaoZoneTables==="object"?JSON.parse(JSON.stringify(state.terceiraDivisaoZoneTables)):null,
      userZonaCompetitionId:state.userZonaCompetitionId||null,
      terceiraDivisaoResultadoProcessado:state.terceiraDivisaoResultadoProcessado!=null?state.terceiraDivisaoResultadoProcessado:null,
      transferMarket:state.transferMarket||[],transferHistory:state.transferHistory||[],marketLastRefreshSeason:state.marketLastRefreshSeason,internalTransferHistory:state.internalTransferHistory||[],marketDecisionHistory:state.marketDecisionHistory||[],clubMovements:state.clubMovements||[],lastSeasonSummary:state.lastSeasonSummary||null, validationHistory:state.validationHistory||[], saveGrowthAudit:state.saveGrowthAudit||null, calibrationValidationReport:state.calibrationValidationReport||null, calibrationValidationHistory:state.calibrationValidationHistory||[],
      freeAgents:state.freeAgents||[], defesoProcessedSeason:state.defesoProcessedSeason!=null?state.defesoProcessedSeason:null, aiToAiMarketProcessedSeason:state.aiToAiMarketProcessedSeason!=null?state.aiToAiMarketProcessedSeason:null, lastTacticalTrainingDate:state.lastTacticalTrainingDate||null, lastMonthlyTacticalReport:state.lastMonthlyTacticalReport||null, retiredPlayers:state.retiredPlayers||[], inactivePlayers:state.inactivePlayers||[], youthCandidates:state.youthCandidates||[], youthDecisionHistory:state.youthDecisionHistory||[], treinadoresDisponiveis:compactSaveClone(state.treinadoresDisponiveis||[]), retirementsProcessedSeason:state.retirementsProcessedSeason!=null?state.retirementsProcessedSeason:null, newGenerationProcessedSeason:state.newGenerationProcessedSeason!=null?state.newGenerationProcessedSeason:null, contractNegotiations:state.contractNegotiations||{}, transferNegotiations:state.transferNegotiations||{}, loanNegotiations:state.loanNegotiations||{}, aiOffers:state.aiOffers||[], loanHistory:state.loanHistory||[], lastAiOfferDate:state.lastAiOfferDate||null, pendingMedicalEvaluations:state.pendingMedicalEvaluations||[],
      // Correção: estes campos nunca eram gravados, por isso um save feito a meio do ecrã de
      // defeso perdia essa informação — ao carregar, o jogo forçava a saída do defeso sem
      // nunca ter chegado a gerar o calendário da nova época (isso só acontece quando o
      // utilizador carrega no botão de avançar). Agora ficam gravados tal como estavam.
      inDefeso:!!state.inDefeso, isPreSeasonDefeso:!!state.isPreSeasonDefeso, pendingSeasonSummary:state.pendingSeasonSummary||null, lastDefesoStats:state.lastDefesoStats||null, pendingSeasonStartDate:state.pendingSeasonStartDate||null,
      gestor: state.gestor||null,
      // Semente de carreira (2026-09-17): usada para o jitter de desempate entre candidatos do
      // mercado (aiCandidateScoreJitter, 04-financas.js) — precisa de sobreviver ao save/load
      // para o mesmo resultado se manter reproduzível dentro da mesma carreira. Campo simples,
      // sem bump de SAVE_VERSION (mesmo padrão já usado nesta sessão para campos novos deste tipo).
      gameSeed: state.gameSeed||null,
      // Motor de Eventos Narrativos (2026-09-28, 09b-eventos-narrativos.js): campos aditivos
      // simples, sem bump de SAVE_VERSION (mesmo padrão de selecoesHistorico/gameSeed acima).
      // eventoGoloFantasmaSeguimento serializa tal e qual (só tem data em ISO string e texto).
      eventosHistorico: state.eventosHistorico||[],
      eventosCooldown: state.eventosCooldown||{},
      eventosUltimoTexto: state.eventosUltimoTexto||{},
      eventoGoloFantasmaSeguimento: state.eventoGoloFantasmaSeguimento||null,
      eventosHeroiSeason: state.eventosHeroiSeason!=null?state.eventosHeroiSeason:null,
      // Fase 2: uma decisão de evento épico/lendário por tomar (ctx só tem strings/números,
      // serializa tal e qual) — sem isto, gravar a meio de uma decisão pendente perdia-a.
      pendingNarrativeEvent: state.pendingNarrativeEvent||null,
      // Seleccionador Nacional — Acumulação de Cargo (2026-10-03): convocatória manual da
      // selecção do utilizador ainda por confirmar, se houver (código, prova, época e as
      // escolhas já feitas no modal) — campo aditivo simples (só strings/números/booleans),
      // serializa tal e qual, mesmo padrão de pendingNarrativeEvent acima.
      pendingNationalSquadPick: state.pendingNationalSquadPick||null,
      // Fase 3 ("A Lenda"): id do jogador consagrado como lenda do clube do utilizador, se algum
      // (team.dinastiaAnunciada/legadoDinastia e p.vilaoDoClube/vilaoClubeId/... são campos
      // aditivos simples dentro de team/players — já viajam tal e qual via compactSaveClone
      // abaixo, sem precisar de entrada própria aqui).
      lendaJogadorId: state.lendaJogadorId||null,
      // Setas de evolução (08-evolucao-jogadores.js) e Registos das ligas (10b-registos.js) — campos
      // aditivos simples; evolucaoTick tem de viajar com os jogadores (p.evolucao.tick), senão o
      // primeiro dia após carregar apagava todas as setas ativas.
      evolucaoTick: state.evolucaoTick||0,
      registos: state.registos||null,
      teams: compactSaveClone(state.teams),
    };
    // 2026-10-16: as seleções virtuais (selecaoNacional-*) usam os MESMOS objetos dos jogadores dos
    // clubes. Gravadas como cópias ficavam desligadas depois de carregar, e as internacionalizações/
    // golos/títulos da edição em curso não chegavam ao jogador do clube. Grava-se só o id (os
    // fictícios __selecaoFiller não existem em mais lado nenhum, esses vão por inteiro).
    Object.keys(state.teams).forEach(id=>{
      const t=state.teams[id];
      if(t && t.selecaoNacional && save.teams[id]) save.teams[id].players=(t.players||[]).map(p=>p.__selecaoFiller?compactSaveClone(p):{__selecaoRef:p.id});
    });
    // Fase 4: gravação de fidelidade total. Não compactar históricos, notícias,
    // movimentos financeiros, negociações ou carreiras: o round-trip deve preservar tudo.
    return attachSaveIntegrity(save);
  }

  function applySaveObjectUnchecked(save){
    state.managerName = save.managerName || "";
    state.userTeamId = save.userTeamId;
    const loadedDef=CLUB_DEFS.find(d=>d.id===save.userTeamId);
    state.userCompetitionId = save.userCompetitionId || clubDefinitionCompetitionId(loadedDef||{});
    if(!state.competitions[state.userCompetitionId]) state.userCompetitionId="placard-2026-27";
    state.viewedCompetitionId=save.viewedCompetitionId&&state.competitions[save.viewedCompetitionId]?save.viewedCompetitionId:state.userCompetitionId;
    state.season = save.season;
    // Fallback (2026-09-17): saves gravados antes deste campo existir não têm gameSeed — gera-se
    // um na primeira carga, para que o jitter de mercado (aiCandidateScoreJitter) passe a ter
    // efeito também nestas carreiras já em curso, em vez de ficar permanentemente desligado.
    state.gameSeed = save.gameSeed || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    state.seasonOver = save.seasonOver;
    // Fallback: saves gravados antes deste campo existir não têm seasonOverSinceDate — se a época
    // já estiver "presa" (seasonOver true) num save antigo, conta-se a partir de agora em vez de
    // nunca disparar o aviso de diagnóstico (ver globalSeasonCloseBlockers).
    state.seasonOverSinceDate = save.seasonOverSinceDate ? new Date(save.seasonOverSinceDate) : (save.seasonOver ? new Date(save.currentDate||Date.now()) : null);
    state.seasonCloseStuckWarned = !!save.seasonCloseStuckWarned;
    state.financePrizeAwarded = !!save.financePrizeAwarded;
    state.fundoSolidariedadeEpoca = Math.max(0,Number(save.fundoSolidariedadeEpoca)||0);
    state.gameOver=!!save.gameOver; state.gameOverReason=save.gameOverReason||null; state.gameOverSnapshot=save.gameOverSnapshot||null; state.gameOverAt=save.gameOverAt?new Date(save.gameOverAt):null;
    state.currentDate = save.currentDate ? new Date(save.currentDate) : new Date();
    state.speedMs = save.speedMs || state.speedMs;
    state.convocadosSelecionados = save.convocadosSelecionados || null;
    state.playoffActive = !!save.playoffActive;
    state.playoffClinchedAnnounced = !!save.playoffClinchedAnnounced;
    state.playoff = save.playoff ? { ...save.playoff, nextGameDate: new Date(save.playoff.nextGameDate) } : null;
    state.pendingPlayoffSeries = null;
    state.matchSummaries = (save.matchSummaries && typeof save.matchSummaries==='object') ? save.matchSummaries : {};   // 0.4.20
    state.decisoesFinais = Array.isArray(save.decisoesFinais) ? save.decisoesFinais : [];   // 0.4.25
    state.staffRetirados = Array.isArray(save.staffRetirados) ? save.staffRetirados : []; state.staffEspecialistas = Array.isArray(save.staffEspecialistas) ? save.staffEspecialistas : []; state.staffPropostas = Array.isArray(save.staffPropostas) ? save.staffPropostas : []; state.staffProcessedSeason = save.staffProcessedSeason != null ? save.staffProcessedSeason : null; state.staffMonthKey = save.staffMonthKey || null;   // 0.4.26
    if(typeof dfSweepLocks==='function') dfSweepLocks();
    state.competitionArchive = (save.competitionArchive && typeof save.competitionArchive==='object') ? save.competitionArchive : {};   // 0.4.21
    state.viewedArchive = null;
    state.news = (save.news||[]).map(n => ({ date:new Date(n.date), text:n.text, kind:n.kind, title: n.title || deriveNewsTitle(n.text), sender: n.sender || resolveNewsSender(n.kind||"geral"), archived: !!n.archived, read: n.read!=null?!!n.read:true }));
    // Consolidação do ponto 3.4 da auditoria externa: uma gravação passa a guardar UMA única
    // representação do calendário de cada competição (save.competitionState) — antes havia três
    // estruturas paralelas com essencialmente os mesmos dados (save.fixtures só para a competição
    // do utilizador, save.otherCompetitions para as restantes, e save.competitionState para
    // todas), que só existiam porque foram introduzidas em fases diferentes do desenvolvimento e
    // nunca chegaram a ser fundidas. migrateSaveObject já garante que, a partir daqui,
    // save.competitionState está sempre completo para TODAS as competições (para gravações
    // antigas, reconstruído a partir dos campos legados fixtures/otherCompetitions — esses
    // continuam a ser lidos, mas só ali, nunca aqui). Aplica-se agora de uma só vez à competição
    // do utilizador e a todas as outras pelo mesmo caminho de código — antes eram dois caminhos
    // separados que podiam divergir (e a competição do utilizador, ao contrário das restantes,
    // não tinha rede de segurança nenhuma se save.fixtures viesse vazio ou inválido).
    const savedCompetitions = {};
    (save.competitionState||[]).forEach(c => { savedCompetitions[c.id] = c; });
    Object.values(state.competitions).forEach(comp => {
      const saved = savedCompetitions[comp.id];
      if(saved && Array.isArray(saved.teamIds) && saved.teamIds.length) comp.teamIds = saved.teamIds.slice();
      if(saved && saved.fixtures && saved.fixtures.length){
        comp.currentRound=saved.currentRound; comp.status=saved.status||"regular";
        comp.fixtures=deserializeCompetitionFixtures(saved.fixtures);
        // 0.4.19: quadro do playoff da própria competição (o resolvido por IA nas divisões que o utilizador não joga também fica gravado)
        comp.playoff=(saved.playoff&&saved.playoff.series)?{...saved.playoff,nextGameDate:saved.playoff.nextGameDate?new Date(saved.playoff.nextGameDate):new Date(state.currentDate)}:null;
      } else {
        comp.fixtures=generateValidatedFixtures(comp.teamIds); comp.currentRound=0; comp.status="regular"; assignFixtureDatesFor(comp);
      }
    });
    state.teams = save.teams;
    relinkSelecaoSquadsOnLoad(state.teams);
    normalizeLoadedTeams(state.teams);
    state.globalAgenda=(save.globalAgenda||[]).map(e=>({...e,date:new Date(e.date),processedAt:e.processedAt?new Date(e.processedAt):null}));
    rebuildGlobalAgenda();
    state.pendingAgendaEventId=null;
    state.plataTie=save.plataTie?{...save.plataTie,games:save.plataTie.games.map(g=>({...g,date:new Date(g.date)}))}:null;
    state.promotionTie=save.promotionTie?{...save.promotionTie,games:save.promotionTie.games.map(g=>({...g,date:new Date(g.date)}))}:null;
    state.secondDivisionFinal=save.secondDivisionFinal?{...save.secondDivisionFinal,games:save.secondDivisionFinal.games.map(g=>({...g,date:new Date(g.date)}))}:null;
    state.tacaPortugal = save.tacaPortugal ? { ...save.tacaPortugal, jogos: Object.fromEntries(Object.entries(save.tacaPortugal.jogos).map(([fase,jogos])=>[fase, jogos.map(j=>({...j, date: j.date?new Date(j.date):null}))])) } : null;
    state.pendingTacaPortugalFase=null; state.pendingTacaPortugalIndex=null;
    state.supertaca = save.supertaca ? {
      historico: (save.supertaca.historico||[]).map(e=>({...e, date: e.date?new Date(e.date):null})),
      jogo: save.supertaca.jogo ? {...save.supertaca.jogo, date: save.supertaca.jogo.date?new Date(save.supertaca.jogo.date):null} : null,
    } : { historico:[], jogo:null };
    state.pendingSupertaca=false;
    state.pendingAmigavel=false;
    state.preSeason = (save.preSeason && typeof save.preSeason==="object" && Array.isArray(save.preSeason.amigaveis)) ? JSON.parse(JSON.stringify(save.preSeason)) : null;
    state.arbitros = (save.arbitros && typeof save.arbitros==="object" && save.arbitros.pool) ? JSON.parse(JSON.stringify(save.arbitros)) : null;
    state.lesoes = (save.lesoes && typeof save.lesoes==="object") ? JSON.parse(JSON.stringify(save.lesoes)) : null;
    state.relB = (save.relB && typeof save.relB==="object") ? JSON.parse(JSON.stringify(save.relB)) : null;
    state.calAmig = (save.calAmig && typeof save.calAmig==="object" && Array.isArray(save.calAmig.jogos)) ? JSON.parse(JSON.stringify(save.calAmig)) : null;
    state.satelites = (save.satelites && typeof save.satelites==="object" && save.satelites.acordos) ? JSON.parse(JSON.stringify(save.satelites)) : null;
    state.eliteCup = save.eliteCup ? {
      historico: (save.eliteCup.historico||[]).map(e=>eliteCupDeserializeEdition(e)),
      edicao: save.eliteCup.edicao ? eliteCupDeserializeEdition(save.eliteCup.edicao) : null,
    } : { historico:[], edicao:null };
    state.pendingEliteCupFase=null; state.pendingEliteCupIndex=null;
    state.eliteCupPostSequence = save.eliteCupPostSequence||null;
    state.copaDelRey = save.copaDelRey ? {
      historico: (save.copaDelRey.historico||[]).map(e=>nationalCupDeserializeEdition(e)),
      edicao: save.copaDelRey.edicao ? nationalCupDeserializeEdition(save.copaDelRey.edicao) : null,
    } : { historico:[], edicao:null };
    state.pendingCopaDelReyFase=null; state.pendingCopaDelReyIndex=null;
    state.coppaItalia = save.coppaItalia ? {
      historico: (save.coppaItalia.historico||[]).map(e=>nationalCupDeserializeEdition(e)),
      edicao: save.coppaItalia.edicao ? nationalCupDeserializeEdition(save.coppaItalia.edicao) : null,
    } : { historico:[], edicao:null };
    state.pendingCoppaItaliaFase=null; state.pendingCoppaItaliaIndex=null;
    state.copaPrincesa = save.copaPrincesa ? {
      historico: (save.copaPrincesa.historico||[]).map(e=>nationalCupDeserializeEdition(e)),
      edicao: save.copaPrincesa.edicao ? nationalCupDeserializeEdition(save.copaPrincesa.edicao) : null,
    } : { historico:[], edicao:null };
    state.pendingCopaPrincesaFase=null; state.pendingCopaPrincesaIndex=null;
    state.supercopaEspana = save.supercopaEspana ? {
      historico: (save.supercopaEspana.historico||[]).map(e=>supercopaEspanaDeserializeEdition(e)),
      edicao: save.supercopaEspana.edicao ? supercopaEspanaDeserializeEdition(save.supercopaEspana.edicao) : null,
    } : { historico:[], edicao:null };
    state.pendingSupercopaEspanaFase=null; state.pendingSupercopaEspanaIndex=null;
    state.supercoppaItaliana = save.supercoppaItaliana ? {
      historico: (save.supercoppaItaliana.historico||[]).map(e=>supercoppaItalianaDeserializeJogo(e)),
      jogo: save.supercoppaItaliana.jogo ? supercoppaItalianaDeserializeJogo(save.supercoppaItaliana.jogo) : null,
    } : { historico:[], jogo:null };
    state.pendingSupercoppaItalianaLeg=null;
    // Competições Europeias (07g-europa.js): state.teams já foi reposto acima (linha ~412) com
    // os clubes da nuvem incluídos — ensureEuropaNuvemClubes() mais abaixo (chamado a partir de
    // europaInitEdition, ou diretamente aqui) só preenche o que faltar, nunca substitui.
    state.europa = save.europa && typeof save.europa==="object"
      ? {
          nuvemGerada: !!save.europa.nuvemGerada,
          coefPais: save.europa.coefPais && typeof save.europa.coefPais==="object" ? save.europa.coefPais : {},
          coefClube: save.europa.coefClube && typeof save.europa.coefClube==="object" ? save.europa.coefClube : {},
          historico: Array.isArray(save.europa.historico) ? save.europa.historico : [],
          edicao: save.europa.edicao ? europaDeserializeEdicao(save.europa.edicao) : null,
        }
      : { nuvemGerada:false, coefPais:{}, coefClube:{}, historico:[], edicao:null };
    EUROPA_PAISES.forEach(p=>{ if(!Array.isArray(state.europa.coefPais[p])) state.europa.coefPais[p]=[]; });
    ensureEuropaNuvemClubes();
    // Seleções Nacionais (07h-selecoes.js) — ver comentário em buildSaveObject/migrateSaveObject.
    // As equipas virtuais de uma edição em curso (selecaoNacional-*) já são carregadas tal e qual
    // dentro de state.teams (compactSaveClone, abaixo) — só edicao.dates precisa de revivificação
    // explícita para Date (mesmo padrão de player.convocadoSelecaoAte, em normalizeLoadedTeams).
    // Motor de Eventos Narrativos (2026-09-28) — ver comentário em buildSaveObject.
    state.eventosHistorico = Array.isArray(save.eventosHistorico) ? save.eventosHistorico : [];
    state.eventosCooldown = save.eventosCooldown && typeof save.eventosCooldown==="object" ? save.eventosCooldown : {};
    state.eventosUltimoTexto = save.eventosUltimoTexto && typeof save.eventosUltimoTexto==="object" ? save.eventosUltimoTexto : {};
    state.eventoGoloFantasmaSeguimento = save.eventoGoloFantasmaSeguimento || null;
    state.eventosHeroiSeason = save.eventosHeroiSeason!=null ? save.eventosHeroiSeason : null;
    // Fase 3 ("A Lenda") — ver comentário em buildSaveObject.
    state.lendaJogadorId = save.lendaJogadorId || null;
    state.evolucaoTick = save.evolucaoTick || 0;
    state.registos = (save.registos && typeof save.registos==='object') ? save.registos : null;
    state.pendingNarrativeEvent = save.pendingNarrativeEvent || null;
    // Seleccionador Nacional — Acumulação de Cargo (2026-10-03) — ver comentário em
    // buildSaveObject/migrateSaveObject. Reaberto mais abaixo, junto do resto dos modais
    // pendentes, se ainda houver uma convocatória manual por confirmar.
    state.pendingNationalSquadPick = save.pendingNationalSquadPick && typeof save.pendingNationalSquadPick==="object" ? save.pendingNationalSquadPick : null;
    state.selecoesHistorico = Array.isArray(save.selecoesHistorico) ? save.selecoesHistorico : [];
    state.selecoesRanking = save.selecoesRanking && typeof save.selecoesRanking==="object" ? save.selecoesRanking : {};
    state.selecoesProxima = save.selecoesProxima || null;
    state.selecoesUltimaConvocatoria = save.selecoesUltimaConvocatoria && typeof save.selecoesUltimaConvocatoria==="object" ? save.selecoesUltimaConvocatoria : {};
    state.selecoes = { edicao: save.selecoes && save.selecoes.edicao ? selecaoDeserializeEdicao(save.selecoes.edicao) : null, edicaoS19: save.selecoes && save.selecoes.edicaoS19 ? selecaoDeserializeEdicao(save.selecoes.edicaoS19) : null };
    // Correcção (auditoria externa, 2026-09-17): pendingEuropaSlot era o único "pendente" de
    // prova a sobreviver ao carregamento — pendingTacaPortugalFase/Index, pendingSupertaca e
    // pendingEliteCupFase/Index são sempre anulados, acima. Mas pendingFixture (o jogo em si) é
    // SEMPRE anulado no carregamento, para qualquer prova, alguns parágrafos abaixo — por isso um
    // pendingEuropaSlot restaurado ficava sempre órfão, sem o jogo a que se referia, podendo
    // apontar para um slot que já não é o próximo a resolver. Anula-se agora aqui também, tal
    // como as suas provas irmãs.
    state.pendingEuropaSlot = null;
    state.okLigaRunnerUp=save.okLigaRunnerUp||null; state.serieA1RunnerUp=save.serieA1RunnerUp||null;
    state.placardChampion=save.placardChampion||null; state.okLigaChampion=save.okLigaChampion||null; state.serieA1Champion=save.serieA1Champion||null; state.promotionEvent=save.promotionEvent||null;
    state.seasonTransitionApplied=!!save.seasonTransitionApplied;
    state.bTeamsExtintas=Array.isArray(save.bTeamsExtintas)?save.bTeamsExtintas.slice():[];
    state.terceiraDivisaoZoneWinners=Array.isArray(save.terceiraDivisaoZoneWinners)?save.terceiraDivisaoZoneWinners.slice():null;
    state.derbies=save.derbies&&typeof save.derbies==="object"?save.derbies:null;
    state.terceiraDivisaoZoneTables=save.terceiraDivisaoZoneTables&&typeof save.terceiraDivisaoZoneTables==="object"?save.terceiraDivisaoZoneTables:null;
    state.userZonaCompetitionId=save.userZonaCompetitionId||null;
    state.terceiraDivisaoResultadoProcessado=save.terceiraDivisaoResultadoProcessado!=null?save.terceiraDivisaoResultadoProcessado:null; state.pendingPromotionTieGameIndex=null; state.pendingPlataTieGameIndex=null; state.pendingSecondDivisionFinalGameIndex=null; state.transferMarket=save.transferMarket||[];state.transferHistory=save.transferHistory||[];state.marketLastRefreshSeason=save.marketLastRefreshSeason||null;state.internalTransferHistory=save.internalTransferHistory||[];state.marketDecisionHistory=save.marketDecisionHistory||[];state.clubMovements=Array.isArray(save.clubMovements)?save.clubMovements:[];state.lastSeasonSummary=save.lastSeasonSummary||null;state.validationHistory=save.validationHistory||[];state.saveGrowthAudit=save.saveGrowthAudit||null;state.calibrationValidationReport=save.calibrationValidationReport||null;state.calibrationValidationHistory=save.calibrationValidationHistory||[];
    state.freeAgents=save.freeAgents||[]; state.defesoProcessedSeason=save.defesoProcessedSeason!=null?save.defesoProcessedSeason:null; state.aiToAiMarketProcessedSeason=save.aiToAiMarketProcessedSeason!=null?save.aiToAiMarketProcessedSeason:null; state.lastTacticalTrainingDate=save.lastTacticalTrainingDate||null; state.lastMonthlyTacticalReport=save.lastMonthlyTacticalReport||null; state.retiredPlayers=save.retiredPlayers||[]; state.inactivePlayers=save.inactivePlayers||[]; state.youthCandidates=save.youthCandidates||[]; state.youthDecisionHistory=save.youthDecisionHistory||[]; state.treinadoresDisponiveis=save.treinadoresDisponiveis||[];
    [state.freeAgents,state.inactivePlayers,state.youthCandidates].forEach(pool=>pool.forEach(ensurePlayerStatsStructure)); state.retirementsProcessedSeason=save.retirementsProcessedSeason!=null?save.retirementsProcessedSeason:null; state.newGenerationProcessedSeason=save.newGenerationProcessedSeason!=null?save.newGenerationProcessedSeason:null; state.contractNegotiations=save.contractNegotiations||{}; state.transferNegotiations=save.transferNegotiations||{}; state.loanNegotiations=save.loanNegotiations||{}; state.aiOffers=save.aiOffers||[]; state.loanHistory=save.loanHistory||[]; state.lastAiOfferDate=save.lastAiOfferDate||null; state.uiNegotiationOpenId=null; state.pendingMedicalEvaluations=save.pendingMedicalEvaluations||[];
    // Correção: em vez de forçar sempre a saída do defeso (o que deixava o jogo com as
    // divisões já atualizadas mas o calendário/estatísticas da época anterior por resetear, se
    // o save tivesse sido feito nesse ecrã), restaura-se exatamente o estado gravado — e, se
    // ainda estiver em defeso, mostra-se de novo o ecrã correspondente, tal como estava.
    state.inDefeso=!!save.inDefeso; state.pendingSeasonSummary=save.pendingSeasonSummary||null; state.lastDefesoStats=save.lastDefesoStats||null;
    state.isPreSeasonDefeso=!!save.isPreSeasonDefeso; state.pendingSeasonStartDate=save.pendingSeasonStartDate?new Date(save.pendingSeasonStartDate):null;
    state.gestor=save.gestor&&typeof save.gestor==="object"?save.gestor:null; ensureManagerCareer();
    const defesoModalEl=document.getElementById("defesoModal");
    // Correção (Elite Cup): se a prova ainda estiver por concluir, um save feito nesta altura
    // tem state.inDefeso=true "herdado" de antes (ver finalizeNewSeason/07d-elite-cup.js — a
    // cauda que desliga inDefeso só corre depois de a Elite Cup terminar), mas mostrar aqui o
    // ecrã de defeso ficaria errado: o jogo está, de facto, a meio da Elite Cup. Nesse caso o
    // ecrã de defeso só volta a aparecer depois de o gancho de resumo, mais abaixo, terminar a
    // prova.
    const eliteCupPendente = !!(state.eliteCup && state.eliteCup.edicao && state.eliteCup.edicao.fase!=="concluida");
    if(state.inDefeso && !eliteCupPendente){
      // Retoma exatamente o ecrã de defeso em que o utilizador estava — sem isto, o jogo ficava
      // com as divisões já atualizadas (subidas/descidas aplicadas antes de gravar) mas o
      // calendário e as estatísticas da época anterior nunca chegavam a ser substituídos pelos
      // da nova época, porque isso só acontece quando se carrega no botão de avançar.
      const continuarBtnEl=document.getElementById("continuarBtn");
      if(continuarBtnEl){ continuarBtnEl.disabled=false; continuarBtnEl.textContent = state.isPreSeasonDefeso ? "Iniciar a Época" : "Avançar para a nova época"; }
      if(state.isPreSeasonDefeso) renderPreSeasonModal(); else renderDefesoModal();
    } else if(defesoModalEl) defesoModalEl.classList.add("hidden");
    if(eliteCupPendente){
      // A Elite Cup não corre pelo ciclo diário normal (resolve-se de forma comprimida, ver
      // 07d-elite-cup.js) — sem este gancho explícito, um save feito a meio da prova (mesmo
      // depois de a convocatória do utilizador ter sido aberta) ficaria "esquecido" ao carregar,
      // porque nada mais voltaria a chamar processEliteCupForCurrentDate. Adiado para o próximo
      // tick, tal como o alerta de Game Over em applySaveObject, para dar tempo à UI de montar.
      setTimeout(()=>{ if(typeof processEliteCupForCurrentDate==="function") processEliteCupForCurrentDate(); },0);
    }
    // Motor de Eventos Narrativos (Fase 2, 2026-09-28): uma decisão pendente sobrevive ao save —
    // reabre o modal de escolha, tal como o ecrã de defeso acima, dado tempo à UI para montar.
    if(state.pendingNarrativeEvent){
      setTimeout(()=>{ if(typeof openEventoNarrativoModal==="function") openEventoNarrativoModal(); },0);
    }
    // Seleccionador Nacional — Acumulação de Cargo (2026-10-03): mesmo padrão outra vez — uma
    // convocatória manual da selecção ainda por confirmar sobrevive ao save e reabre o modal
    // correspondente (as escolhas já feitas, se alguma, também sobreviveram em
    // pending.selecionados).
    if(state.pendingNationalSquadPick){
      setTimeout(()=>{ if(typeof openSelecaoConvocatoriaManualModal==="function") openSelecaoConvocatoriaManualModal(); },0);
    }
    state.match = null;
    state.pendingFixture = null; state.pendingSuspensionServing = null; state.matchDayReady = false;
    // Reforço de emergência entre Equipa A e Equipa B (2026-10-03): um save feito exatamente a
    // meio da preparação de um jogo (depois de ensureMinimumSquad já ter ido buscar um reforço
    // real à equipa irmã, mas antes de a partida terminar e o devolver) gravava esse jogador
    // "emprestado" dentro do plantel de destino, com a marca __loanedForMatchFrom — como
    // state.pendingProvisional é sempre limpo ao carregar (linha acima), nada mais voltaria a
    // chamar removeProvisionalPlayers por ele, e o jogador ficava preso lá para sempre. Mesmo
    // princípio do jogador provisório (Henrique Dias) "nunca ficar no plantel... ou save" já
    // aplicado no fecho de época (ver closeCompletedSeasonPlayerStats, 08-evolucao-jogadores.js) —
    // devolve-o à equipa de origem (ou, na pior das hipóteses, descarta-o) logo ao carregar.
    // Jovens da academia chamados à equipa B (08zb-b-experiencia.js) regressam à academia.
    if(typeof bxLimparOrfaos==="function") bxLimparOrfaos();
    Object.values(state.teams).forEach(team=>{
      if(!team || !Array.isArray(team.players)) return;
      team.players = team.players.filter(p=>{
        if(!p || typeof p!=="object") return false;
        if(p.__provisional) return false;
        if(p.__loanedForMatchFrom){
          const origin = state.teams[p.__loanedForMatchFrom];
          delete p.__loanedForMatchFrom; delete p.__bxRodagem; delete p.__bxAntes;
          if(origin && origin!==team && !origin.players.some(x=>x.id===p.id)) origin.players.push(p);
          return false;
        }
        return true;
      });
    });
    state.pendingProvisional = null;
    const speedSelectEl = document.getElementById("speedSelect");
    if(speedSelectEl) speedSelectEl.value = String(state.speedMs);
  }

  function applySaveObject(rawSave){
    validateRawSaveIntegrity(rawSave);
    const save=migrateSaveObject(rawSave);
    validateMigratedSave(save);
    applySaveObjectUnchecked(save);
    if(save.__plataCatchUp && !state.inDefeso) catchUpPlataRounds();
    state.lastLoadedSaveVersion=save.migratedFromVersion;
    if(state.gameOver)setTimeout(()=>{if(typeof showGameOverModal==="function")showGameOverModal();},0);
    return save;
  }

  // Compatibilidade com saves anteriores a esta revisão: garante que todas as propriedades novas
  // existem com um valor seguro, sem apagar nenhum progresso já guardado.
  // Recompõe os plantéis das seleções virtuais a partir dos jogadores reais (clubes e academias).
  function relinkSelecaoSquadsOnLoad(teams){
    const virt=Object.values(teams||{}).filter(t=>t&&t.selecaoNacional&&Array.isArray(t.players));
    if(!virt.length) return;
    const byId=new Map();
    Object.values(teams).forEach(t=>{
      if(!t||t.selecaoNacional) return;
      (t.players||[]).forEach(p=>{ if(p&&p.id) byId.set(p.id,p); });
      if(t.academy&&t.academy.brackets) Object.values(t.academy.brackets).forEach(b=>(b.players||[]).forEach(p=>{ if(p&&p.id&&!byId.has(p.id)) byId.set(p.id,p); }));
    });
    virt.forEach(t=>{
      t.players=t.players.map(p=>p&&p.__selecaoRef?byId.get(p.__selecaoRef):p).filter(Boolean);
    });
  }
  function normalizeLoadedTeams(teams){
    Object.values(teams||{}).forEach(t => {
      // Histórico de entradas persistente no save: normaliza saves antigos e preserva
      // transferências, empréstimos e entradas sem custos já registadas.
      if(!Array.isArray(t.players)) t.players=[];
      t.players.forEach(player=>{
        ensurePlayerStatsStructure(player);
        // Seleções Nacionais (2026-09-26): convocadoSelecaoAte é uma Date atribuída diretamente
        // ao jogador — compactSaveClone (JSON.parse(JSON.stringify(...))) já a converte para ISO
        // string automaticamente ao gravar (Date tem .toJSON()), mas nada a revive de volta a
        // Date ao carregar (não há reviver genérico neste ficheiro — todas as outras datas
        // guardadas, ex. globalAgenda/tacaPortugal, têm o mesmo tratamento explícito). Sem esta
        // linha, `state.currentDate <= p.convocadoSelecaoAte` compararia sempre Number<=NaN
        // (comparação Date<=String força ToNumber na string) e ficaria sempre falsa após um
        // save/load a meio da janela do torneio.
        if(player.convocadoSelecaoAte) player.convocadoSelecaoAte = new Date(player.convocadoSelecaoAte);
        if(!Array.isArray(player.historico)) player.historico=[];
        player.historico.forEach(row=>{
          if(!row.movimento) return;
          const tipo=["livre","emprestimo","transferencia"].includes(row.movimento.tipo) ? row.movimento.tipo : null;
          row.movimento=tipo ? {tipo,valor:Math.max(0,Math.round(Number(row.movimento.valor)||0))} : null;
        });
        if(player.freeAgentContext){const c=player.freeAgentContext;player.freeAgentContext={...c,formerTraining:c.formerTraining||"Boas",formerRole:c.formerRole||"Rotacao",lastSalary:Math.max(0,Number(c.lastSalary)||0),formerImportance:clamp(Number(c.formerImportance)||0,0,100),releasedSeason:Math.max(1,parseInt(c.releasedSeason,10)||state.season),rejectedTeams:Array.isArray(c.rejectedTeams)?c.rejectedTeams.slice(-12):[]};}
        if(player.movimentoEntrada){
          const m=player.movimentoEntrada;
          const tipo=["livre","emprestimo","transferencia"].includes(m.tipo) ? m.tipo : null;
          player.movimentoEntrada=tipo ? {
            epoca:Math.max(1,parseInt(m.epoca,10)||state.season),
            clubeId:String(m.clubeId||t.id), tipo, valor:Math.max(0,Math.round(Number(m.valor)||0))
          } : null;
        }
      });
      if(t.aiRecruitmentLedger){const l=t.aiRecruitmentLedger;t.aiRecruitmentLedger={key:String(l.key||""),entradas:Math.max(0,l.entradas|0),compras:Math.max(0,l.compras|0),livres:Math.max(0,l.livres|0),emprestimos:Math.max(0,l.emprestimos|0),promocoesB:Math.max(0,l.promocoesB|0),totalComprometido:Math.max(0,Math.round(Number(l.totalComprometido)||0)),playerIds:Array.isArray(l.playerIds)?[...new Set(l.playerIds.map(String))]:[]};}
      (t.players||[]).forEach(p=>{if(p.aiRecruitmentDecision)p.aiRecruitmentDecision={...p.aiRecruitmentDecision,season:Math.max(1,p.aiRecruitmentDecision.season|0),teamId:String(p.aiRecruitmentDecision.teamId||t.id),totalCost:Math.max(0,Math.round(Number(p.aiRecruitmentDecision.totalCost)||0))};});
      if(t.financeiro) normalizeFinancePhase2(t);
      // Sistema numérico de reputação (v1.2): normalizeClubReputation aceita tanto um número
      // (formato novo) como uma das quatro categorias antigas ("Local"/"Nacional"/...) — migração
      // idempotente (AC-02/AC-03/AC-08): chamar duas vezes com o mesmo save dá sempre o mesmo
      // número, e um save já migrado não é alterado.
      t.reputacao = normalizeClubReputation(t.reputacao, t);
      if(t.reputacaoPontos==null) t.reputacaoPontos = t.reputacao;
      syncClubStrategicProfile(t);
      const principalMap={"fc-porto-b":"porto","ad-valongo-b":"valongo","oc-barcelos-b":"barcelos","ud-oliveirense-b":"oliveirense","sporting-cp-b":"sporting","sl-benfica-b":"benfica","riba-dave-hc-b":"ribadave","hc-braga-b":"braga","j-pacense-b":"pacense","ad-sanjoanense-b":"sanjoanense","ch-carvalhos-b":"ch-carvalhos","aa-espinho-b":"ass-academica-espinho","ha-cambra-b":"ha-cambra","a-academica-c-b":"ass-academica-coimbra","hc-turquel-b":"hc-turquel","hc-mealhada-b":"hc-mealhada","s-alenquer-b-b":"sp-alenquer-e-benfica","ae-fisica-d-b":"ae-fisica-d","cd-paco-de-arcos-b":"cd-paco-de-arcos","fc-barcelona-b":"fc-barcelona","reus-deportiu-b":"reus-deportiu","igualada-hc-b":"igualada-hc","ce-noia-b":"ce-noia"};
      const bMap={"porto":"fc-porto-b","valongo":"ad-valongo-b","barcelos":"oc-barcelos-b","oliveirense":"ud-oliveirense-b","sporting":"sporting-cp-b","benfica":"sl-benfica-b","ribadave":"riba-dave-hc-b","braga":"hc-braga-b","pacense":"j-pacense-b","sanjoanense":"ad-sanjoanense-b","ch-carvalhos":"ch-carvalhos-b","ass-academica-espinho":"aa-espinho-b","ha-cambra":"ha-cambra-b","ass-academica-coimbra":"a-academica-c-b","hc-turquel":"hc-turquel-b","hc-mealhada":"hc-mealhada-b","sp-alenquer-e-benfica":"s-alenquer-b-b","ae-fisica-d":"ae-fisica-d-b","cd-paco-de-arcos":"cd-paco-de-arcos-b","fc-barcelona":"fc-barcelona-b","reus-deportiu":"reus-deportiu-b","igualada-hc":"igualada-hc-b","ce-noia":"ce-noia-b"};
      if(t.equipaPrincipalId==null) t.equipaPrincipalId=principalMap[t.id]||null; if(t.equipaBId==null) t.equipaBId=bMap[t.id]||null; invalidateUserControlledCache();
      if(t.reputacaoPontos==null) t.reputacaoPontos = t.reputacao;
      if(!t.condicoesTreino) t.condicoesTreino = "Boas";
      // Migração (auditoria externa, 2026-09-17): saves gravados antes de team.pais existir como
      // atributo próprio do clube (ver teamCountry, 01-nucleo.js) ficam com o valor que a antiga
      // derivação por divisão já lhes dava — nunca muda o país de um clube já em jogo, só passa a
      // gravá-lo explicitamente a partir de agora.
      if(!t.pais) t.pais = (t.divisaoAtual==="ok-liga"||t.divisaoAtual==="ok-liga-plata") ? "es" : t.divisaoAtual==="serie-a1" ? "it" : "pt";
      if(t.confiancaDirecao==null) t.confiancaDirecao = 60;
      // Fase A: renomeação real tactic->mentalidade e agressividadeTatica->pressao, com
      // migração de valores antigos (cauteloso/normal/agressivo -> baixa/media/alta) e um
      // sistema tático novo (3-1/2-2), que não existia antes — 3-1 por omissão.
      if(!t.mentalidade) t.mentalidade = t.tactic || "equilibrado";
      if(!t.pressao){
        const oldPressao = t.agressividadeTatica;
        t.pressao = oldPressao==="cauteloso" ? "baixa" : oldPressao==="agressivo" ? "alta" : oldPressao==="normal" ? "media" : (oldPressao || "media");
      }
      if(!t.sistema) t.sistema = "3-1";
      delete t.tactic; delete t.agressividadeTatica;
      // Identidade + familiaridade tática (Fase 1): saves anteriores não têm nenhum destes
      // campos — initTacticalIdentity só atua quando ainda não existem (não sobrepõe saves
      // já migrados nem altera decisões já tomadas pelo utilizador).
      initTacticalIdentity(t);
      // Reformas: saves anteriores não têm o campo de reforma anunciada — é seguro como
      // "ausente" (undefined = sem decisão tomada ainda).
      // Academia e Juvenis (Fase 1, 2026-09-22; initFormationQuality removida na Fase 5):
      // gravações anteriores a esta funcionalidade não têm t.academy — bootstrapAcademyIfEmpty
      // cria-a já com os 4 escalões preenchidos (via initAcademyLevel) para clubes elegíveis
      // (decisão 3 do utilizador: reinício limpo, não conversão de state.youthCandidates); para
      // clubes não elegíveis (3ª divisão/nuvem) não faz nada. Idempotente e seguro correr
      // incondicionalmente em todo o load, mesmo já migrado.
      bootstrapAcademyIfEmpty(t);
      // Staff — Treinadores (2026-09-22): mesmo raciocínio e mesma elegibilidade da Academia —
      // gravações antigas não têm t.treinador, bootstrapTreinadorIfEmpty cria-o para clubes
      // elegíveis; idempotente, seguro correr incondicionalmente em todo o load.
      bootstrapTreinadorIfEmpty(t);
      // Mercado de treinadores (2026-09-23): saves anteriores a esta fase não têm salário nem os
      // contadores de segurança no cargo (treinadorConfiancaBaixaMeses/treinadorAvisoEmitido) —
      // ensureTreinadorSeguranca é idempotente, seguro correr incondicionalmente em todo o load.
      // t.treinadorVacancia fica tal como estiver no save (null/ausente = sem vaga, forma correcta
      // por omissão para qualquer clube que já tenha treinador ou nunca tenha sido elegível).
      ensureTreinadorSeguranca(t);
      if(!Array.isArray(t.recentResults)) t.recentResults = [];
      initClubFinance(t);
      // Fase 14: migra clubes com finanças de saves anteriores (sem perfis reais) para o novo
      // formato — preserva saldo/movimentos existentes, só acrescenta os campos em falta.
      if(t.financeiro && t.financeiro.sponsorNome==null){
        const c=financeConfig(t);
        t.financeiro.sponsorNome=c.sponsorNome; t.financeiro.sponsorValorAnual=c.sponsorValorAnual; t.financeiro.sponsorObjetivo=c.objetivoDesportivo;
        t.financeiro.receitaMensalQuotas=c.quotas; t.financeiro.receitaMensalApoioMunicipal=c.apoioMunicipal;
        t.financeiro.percSocios=c.percSocios; t.financeiro.mediaSocios=t.financeiro.mediaSocios||0; t.financeiro.mediaBilhetesPagos=t.financeiro.mediaBilhetesPagos||0;
        if(t.financeiro.divida==null) t.financeiro.divida=0;
      }
      (t.players||[]).forEach((p, idx) => {
        if(!p.id){
          const base = t.id+"-"+slugify(p.name||("jogador"+idx));
          let candidate = base, n = 2;
          while((t.__usedIdsBackfill||(t.__usedIdsBackfill=new Set())).has(candidate)){ candidate = base+"-"+n; n++; }
          t.__usedIdsBackfill.add(candidate);
          p.id = candidate;
        }
        if(!p.season) p.season = {};
        if(p.season.jogosTitular == null) p.season.jogosTitular = 0;
        if(p.season.jogosSuplente == null) p.season.jogosSuplente = 0;
        if(p.season.mvp == null) p.season.mvp = 0;
        if(p.season.golosSofridos == null) p.season.golosSofridos = 0;
        if(p.season.penaltisMarcados == null) p.season.penaltisMarcados = 0;
        if(p.season.penaltisFalhados == null) p.season.penaltisFalhados = 0;
        if(p.season.penaltisTentados == null) p.season.penaltisTentados = 0;
        if(p.season.penaltisDefendidos == null) p.season.penaltisDefendidos = 0;
        if(p.season.penaltisSofridos == null) p.season.penaltisSofridos = 0;
        if(p.season.livresDiretosMarcados == null) p.season.livresDiretosMarcados = 0;
        if(p.season.livresDiretosFalhados == null) p.season.livresDiretosFalhados = 0;
        if(p.season.livresDiretosTentados == null) p.season.livresDiretosTentados = 0;
        if(p.season.livresDiretosDefendidos == null) p.season.livresDiretosDefendidos = 0;
        if(p.season.livresDiretosSofridos == null) p.season.livresDiretosSofridos = 0;
        if(!p.career) p.career = { golos:0, assistencias:0, jogos:0, amarelos:0, azuis:0, vermelhos:0 };
        if(p.career.golosSofridos == null) p.career.golosSofridos = 0;
        if(p.career.mvp == null) p.career.mvp = 0;
        if(p.condicao == null) p.condicao = 100;
        if(!p.attrs) p.attrs = {};
        if(p.pos==="J"){
          if(p.attrs.meiaDistancia==null) p.attrs.meiaDistancia = p.attrs.habilidade!=null ? p.attrs.habilidade : 12;
          if(p.attrs.finalizacao==null) p.attrs.finalizacao = p.attrs.habilidade!=null ? p.attrs.habilidade : 12;
          if(p.attrs.velocidade==null) p.attrs.velocidade = 12;
          if(p.attrs.aceleracao==null) p.attrs.aceleracao = 12;
          if(p.attrs.desarme==null) p.attrs.desarme = p.attrs.posicionamento!=null ? p.attrs.posicionamento : 12;
        } else if(p.pos==="GR"){
          if(p.attrs.meiaDistancia==null) p.attrs.meiaDistancia = p.attrs.reflexos!=null ? p.attrs.reflexos : 12;
        }
        if(!Array.isArray(p.historico)) p.historico = [];
        if(!Array.isArray(p.titulos)) p.titulos = [];
        if(!Array.isArray(p.careerArchivesApplied)) p.careerArchivesApplied=[];
        if(p.internacionalizacoes == null) p.internacionalizacoes = 0;
        if(p.golosInternacional == null) p.golosInternacional = 0;
        if(!p.dataNascimento){
          const rngDob = makeSeededRng(p.id+"|"+p.name+"|dob-backfill");
          p.dataNascimento = makeBirthDate(rngDob, p.age!=null ? p.age : 24);
        }
        if(!p.nacionalidade) p.nacionalidade = "Portuguesa";
        // Liga espanhola (2026-09-06): saves anteriores à OK Liga não têm país de origem — como
        // não existia então nenhum jogador espanhol, "pt" é sempre a inferência correta (mesmo
        // que "nacionalidade" tenha sido editada manualmente para outra coisa qualquer, o campo
        // que decide deslocação/prémio salarial é sempre paisOrigem, nunca o texto livre).
        if(!p.paisOrigem) p.paisOrigem = p.nacionalidade==="Espanhola" ? "es" : "pt";
        if(p.pos==="J" && !p.linha){
          const rngLinha = makeSeededRng(p.id+"|"+p.name+"|linha-backfill");
          p.linha = seededRnd(rngLinha,0,1)===0 ? "Avancado" : "DefesaMedio";
        }
        if(p.satisfacao == null) p.satisfacao = p.moral!=null ? p.moral : 70;
        if(p.reputacaoJogador == null) p.reputacaoJogador = computePlayerReputation(p);
        // Fase 12: migra contratos de saves anteriores (v10 e abaixo), que só tinham
        // salarioMensal/anos, para o formato completo com datas e papel no plantel.
        if(!p.contrato) p.contrato = generateContract(overall(p), p.age);
        if(!p.contrato.dataFim){
          const baseDate = state.currentDate ? isoDate(state.currentDate) : "2026-08-01";
          const anos = p.contrato.anos>0 ? p.contrato.anos : 1;
          p.contrato = generateContract(overall(p), p.age, {
            anos, salarioMensal: p.contrato.salarioMensal, dataInicio: baseDate,
            papel: p.titular ? "Titular" : undefined,
          });
        }
        if(p.preContrato===undefined) p.preContrato = null;
        delete p.__manualResolutionSeason;
      });
      if(!Array.isArray(t.avaliacaoDirecao)) t.avaliacaoDirecao = [];
      delete t.__usedIdsBackfill;
    });
  }

  // No desktop os avisos aparecem dentro do jogo (toast) em vez de uma janela do sistema.
  function avisoGuardar(msg){ const D = window.hm2027Desktop; if(D && D.ativo() && D.aviso) D.aviso(msg); else alert(msg); }

  let _aposGuardar = null;   // usado pelo botão Sair ("Guardar e sair")

  // ---------------------------------------------------------------------------------------------
  // Gravação atual + autosave (2026-10-13). Na versão desktop o jogo lembra o ficheiro que o utilizador
  // gravou (1.º Guardar) ou carregou, e todos os Guardar seguintes — manuais ou automáticos — substituem
  // esse mesmo ficheiro. "Guardar como…" (Definições) escolhe um nome novo. No browser não dá para
  // substituir um ficheiro sem pedir ao utilizador (limitação do navegador): continua a descarregar.
  // ---------------------------------------------------------------------------------------------
  const AUTOSAVE_KEY = "hm2027_autosave";
  const AUTOSAVE_OPCOES = ["nenhum","semanal","mensal"];
  let _saveAtual = null;        // nome (sem extensão) do ficheiro atual na pasta de saves
  let _autoRef = null;          // data de jogo do último autosave (ou do arranque/carregamento)
  let _autoAOcupar = false;
  function emDesktop(){ return !!(window.hm2027Desktop && window.hm2027Desktop.ativo()); }
  function autosaveModo(){
    try{ const v = localStorage.getItem(AUTOSAVE_KEY); return AUTOSAVE_OPCOES.includes(v) ? v : "nenhum"; }catch(e){ return "nenhum"; }
  }
  function definirAutosave(v){
    if(!AUTOSAVE_OPCOES.includes(v)) return;
    try{ localStorage.setItem(AUTOSAVE_KEY, v); }catch(e){}
    _autoRef = state.currentDate ? new Date(state.currentDate.getTime()) : null;
    atualizarDefGravacao();
  }
  function novoSaveAtual(nome){
    _saveAtual = nome || null;
    _autoRef = state.currentDate ? new Date(state.currentDate.getTime()) : null;
    atualizarDefGravacao();
  }
  function pacoteDeGravacao(){
    const save = buildSaveObject();
    const json = JSON.stringify(save);
    const club = myTeam();
    const nomeClube = club ? club.name : "Jogo";
    const epoca = seasonLabel(state.season);
    const data = state.currentDate ? fmtDateShort(state.currentDate) : "";
    const dateTag = state.currentDate ? fmtDateShort(state.currentDate).replace(/\//g,"-") : "save";
    return { json, club, nomeClube, dateTag,
             nome: `${nomeClube} - ${epoca.replace("/","-")} - ${dateTag}`,
             meta: { clube: nomeClube, epoca, data, treinador: state.managerName || "" } };
  }
  function pensar(fn){ if(window.hm2027Pensar) window.hm2027Pensar(fn); else fn(); }
  function saveGame(opts){
    opts = opts || {};
    if(!state.userTeamId){ avisoGuardar("Escolhe primeiro um clube antes de guardar."); return; }
    if(state.pendingPostMatchCtx){ avisoGuardar("Carrega em Continuar para sair do jogo terminado antes de guardar."); return; }
    // Correção (2026-10-16): gravar num dia de jogo com o jogo do utilizador por disputar perdia esse
    // jogo ao carregar (os jogos da IA desse dia já estavam feitos e o dia de jogo não era rearmado;
    // nos playoffs, as séries da IA jogavam duas vezes no mesmo dia).
    if(state.matchDayReady){ avisoGuardar("Hoje há jogo: joga ou simula o jogo de hoje antes de guardar."); return; }
    pensar(() => saveGameInterno(opts));
  }
  function saveGameInterno(opts){
    const pac = pacoteDeGravacao();
    const { json, club, dateTag } = pac;
    // localStorage continua a servir de rede de segurança, mas a gravação "oficial" é o ficheiro descarregado
    try{ localStorage.setItem(SAVE_KEY, json); }catch(e){ /* ignore, file download is what matters */ }
    // Versão desktop (Tauri): pasta própria, ver 13-desktop.js.
    if(emDesktop()){
      const D = window.hm2027Desktop;
      const depois = (n) => { novoSaveAtual(n); const f = _aposGuardar; _aposGuardar = null; if(f) f(); };
      const abrirPicker = () => D.abrirGuardar({ json, nome: _saveAtual || pac.nome, meta: pac.meta, aoGuardar: depois });
      if(_saveAtual && !opts.como){
        // Há um ficheiro atual: substitui-o diretamente, sem perguntar o nome outra vez.
        D.guardarSave(_saveAtual, json, pac.meta)
          .then(n => { D.aviso(`Jogo guardado: ${n}`); depois(n); })
          .catch(e => { D.aviso("Não foi possível guardar por cima da gravação atual: " + (e && e.message ? e.message : e)); abrirPicker(); });
      }else abrirPicker();
      return;
    }
    try{
      const blob = new Blob([json], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `pista-${club ? club.id : "jogo"}-${dateTag}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(()=>URL.revokeObjectURL(url), 2000);
      if(_aposGuardar){ const f = _aposGuardar; _aposGuardar = null; setTimeout(f, 800); }
      alert("Jogo guardado! O ficheiro foi descarregado — guarda-o num sítio seguro. Usa \"Carregar Jogo\" e escolhe esse ficheiro para continuares mais tarde.");
    }catch(e){
      alert("Não foi possível gerar o ficheiro de gravação neste navegador.");
    }
  }

  function applyLoadedSave(save){
    const migrated=applySaveObject(save);
    // 2026-10-16: estado de ecrã da sessão anterior (equipa B de outro clube no Plantel, histórico
    // do "Voltar", ficha de jogador antiga) e o ecrã de falência ficavam por cima do jogo carregado.
    state.plantelViewTeamId=null; state.plantelViewMode=null; state.viewHistory=[];
    try{ playerModalHistory=[]; }catch(e){}
    // 0.2.12: saves antigos — clubes da 3.ª Divisão (sem descida) ainda com o objetivo "Assegurar a manutenção".
    try{ Object.values(state.teams).forEach(t=>{ if(t.divisaoAtual==="3div" && t.financeiro && /manuten/i.test(t.financeiro.sponsorObjetivo||"")) t.financeiro.sponsorObjetivo=genericObjetivoDesportivo(t); }); }catch(e){}
    if(!state.gameOver){ const go=document.getElementById("gameOverOverlay"); if(go) go.classList.add("hidden"); document.body.classList.remove("game-over-active"); }
    document.getElementById("mainMenuOverlay").classList.add("hidden");
    document.getElementById("managerNameOverlay").classList.add("hidden");
    document.getElementById("teamSelectOverlay").classList.add("hidden");
    setView("clube");
    state.viewHistory=[]; if(typeof syncBackButtonVisibility==="function") syncBackButtonVisibility();
    renderAll();
  }

  function loadGameFromFile(file){
    const reader = new FileReader();
    reader.onload = (evt) => loadGameFromText(evt.target.result);
    reader.onerror = () => alert("Não foi possível ler o ficheiro selecionado.");
    reader.readAsText(file);
  }
  function loadGameFromText(texto, nomeFicheiro){
    pensar(() => loadGameFromTextInterno(texto, nomeFicheiro));
  }
  function loadGameFromTextInterno(texto, nomeFicheiro){
      try{
        const rawSave = JSON.parse(texto);
        const migrated=applyLoadedSave(rawSave);
        novoSaveAtual(nomeFicheiro || null);   // os Guardar seguintes (e o autosave) substituem este ficheiro
        if(Number(rawSave.version||6)<SAVE_VERSION) avisoGuardar(`Gravação v${rawSave.version||6} migrada com sucesso para v${SAVE_VERSION}. O progresso, plantéis e histórico foram preservados.`);
      }catch(e){
        console.error("[HM2027] Falha ao carregar save:",e);
        avisoGuardar("Não foi possível carregar a gravação: "+(e&&e.message?e.message:"ficheiro inválido"));
      }
  }

  // Abre o seletor de gravações (lista dentro do jogo na versão desktop, <input type=file> no browser).
  function escolherGravacaoParaCarregar(){
    if(window.hm2027Desktop && window.hm2027Desktop.ativo()){
      window.hm2027Desktop.abrirCarregar({ haProgresso: !!state.userTeamId, aoCarregar: (texto, nome) => loadGameFromText(texto, nome) });
      return;
    }
    document.getElementById("loadFileInput").click();
  }

  document.getElementById("saveGameBtn").addEventListener("click", () => { _aposGuardar = null; saveGame(); });
  window.hm2027NovaCarreira = () => { _saveAtual = null; _autoRef = null; atualizarDefGravacao(); };

  // Autosave: chamado depois de cada avanço de dias. Semanal = passaram 7+ dias de jogo desde o último;
  // mensal = mudou o mês de jogo. Só na versão desktop (precisa de substituir um ficheiro).
  function autosaveAposAvanco(){
    const modo = autosaveModo();
    if(modo === "nenhum" || !emDesktop() || !state.userTeamId || !state.currentDate) return;
    const agora = state.currentDate;
    if(!_autoRef || agora.getTime() < _autoRef.getTime()){ _autoRef = new Date(agora.getTime()); return; }
    const dias = (agora.getTime() - _autoRef.getTime()) / 86400000;
    const mudouMes = agora.getFullYear() !== _autoRef.getFullYear() || agora.getMonth() !== _autoRef.getMonth();
    if(modo === "semanal" ? dias < 7 : !mudouMes) return;
    if(_autoAOcupar || state.gameOver || state.pendingPostMatchCtx || state.matchDayReady || (state.match && !state.match.finished)) return;
    _autoAOcupar = true;
    try{
      const pac = pacoteDeGravacao();
      const nome = _saveAtual || `${pac.nomeClube} - Autosave`;
      _autoRef = new Date(agora.getTime());
      try{ localStorage.setItem(SAVE_KEY, pac.json); }catch(e){}
      window.hm2027Desktop.guardarSave(nome, pac.json, pac.meta)
        .then(n => window.hm2027Desktop.aviso(`Autosave: ${n}`))
        .catch(e => window.hm2027Desktop.aviso("Autosave falhou: " + (e && e.message ? e.message : e)))
        .finally(() => { _autoAOcupar = false; });
    }catch(e){ _autoAOcupar = false; console.error("[HM2027] autosave:", e); }
  }
  window.hm2027Autosave = autosaveAposAvanco;

  // Secção "Gravações" nas Definições.
  function atualizarDefGravacao(){
    const ov = document.getElementById("settingsOverlay"); if(!ov) return;
    const modo = autosaveModo(), desk = emDesktop();
    ov.querySelectorAll("[data-autosave]").forEach(b => { b.classList.toggle("active", b.getAttribute("data-autosave") === modo); b.disabled = !desk; b.style.opacity = desk ? "" : "0.5"; });
    const info = document.getElementById("setAutosaveInfo");
    if(info){
      info.textContent = !desk
        ? "O autosave só existe na aplicação de desktop (um navegador não pode substituir ficheiros sozinho). No browser, o jogo descarrega um ficheiro novo de cada vez que carregas em Guardar."
        : (_saveAtual
            ? `Ficheiro atual: «${_saveAtual}». Guardar e autosave substituem este ficheiro.`
            : "Ainda não há ficheiro atual: o primeiro Guardar (ou carregar uma gravação) define-o. Entretanto, o autosave grava em «<Clube> - Autosave».");
    }
    const como = document.getElementById("setGuardarComoBtn");
    if(como){ como.disabled = !desk || !state.userTeamId; como.style.opacity = como.disabled ? "0.5" : ""; }
    const sb = document.getElementById("saveGameBtn");
    if(sb) sb.title = desk && _saveAtual ? `Guardar por cima de «${_saveAtual}»` : "Guardar jogo";
  }
  document.querySelectorAll("[data-autosave]").forEach(b => b.addEventListener("click", () => definirAutosave(b.getAttribute("data-autosave"))));
  const _gc = document.getElementById("setGuardarComoBtn");
  if(_gc) _gc.addEventListener("click", () => { document.getElementById("settingsOverlay").classList.add("hidden"); _aposGuardar = null; saveGame({ como: true }); });
  ["menuSettingsBtn","settingsBtn"].forEach(id => { const b = document.getElementById(id); if(b) b.addEventListener("click", atualizarDefGravacao); });
  atualizarDefGravacao();
  window.hm2027GuardarEDepois = (cb) => { _aposGuardar = cb; saveGame(); };
  document.getElementById("loadFileInput").addEventListener("change", (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = ""; // allows re-selecting the same file later
    if(file) loadGameFromFile(file);
  });
  document.getElementById("loadGameBtn").addEventListener("click", () => {
    const emDesktop = window.hm2027Desktop && window.hm2027Desktop.ativo();   // no desktop a confirmação é feita no próprio seletor
    if(!emDesktop && state.userTeamId && !confirm("Isto substitui o teu progresso atual pelo jogo do ficheiro que vais escolher. Continuar?")) return;
    escolherGravacaoParaCarregar();
  });

  // =================================================================
