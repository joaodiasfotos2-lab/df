// ============================= 08zn-staff-ecossistema.js =============================
// Ecossistema de staff — fase 1 (0.4.26). Pedido: "passagem de alguns jogadores para treinador
// quando acabam a carreira. Treinadores também se retiram. Deve haver um ecossistema de staff."
// Decisões do utilizador (2026-11-07): adjunto já na fase 1; pirâmide de carreira começa na 3.ª
// divisão; lendas do clube do utilizador podem ser oferecidas ao seu staff; staff especializado
// (preparador físico, treinador de GR, scout — fases seguintes) será manual com sugestão do adjunto.
//
// Modelo (mesma forma do treinador principal, 08c): pessoa = {id, nome, dataNascimento, nacionalidade,
//   paisOrigem, stats(12), clubeActualId, mandatoAtual, historico, etapa 0|1|2, funcao, origem
//   "gerado"|"ex-jogador", salario, semClubeDesde, jogadorId?, carreiraJogador?}.
//   etapa = nível já atingido na pirâmide: 0 formação · 1 adjunto · 2 principal.
// Lugares por clube (só clubes com academia — academyEligible): team.treinador (principal, 08c),
//   team.adjunto, team.treinadorFormacao. team.staffVagas.{adjunto,formacao}=true só no clube do
//   utilizador: lugar vazio à espera de ele contratar (a IA preenche os seus sozinha).
// Fluxos:
//   - Jogador que se reforma → ~20–55% passa a treinador (staffFromRetiredPlayer, chamado de
//     processRetirements). Entra no pool state.treinadoresDisponiveis. Lenda/ídolo do clube do
//     utilizador → proposta ao utilizador (state.staffPropostas, janela com Aceitar/Recusar).
//   - Treinadores retiram-se dos 60 aos 72 anos (staffAnnual, chamado de beginDefeso); arquivo em
//     state.staffRetirados. Pool: sem clube há >3 épocas → reforma/afastamento. Sem limite fixo de 25.
//   - Pirâmide: formação → adjunto → principal. Vagas de principal são preenchidas (08c) também por
//     promoção do adjunto do próprio clube ou de outro (candidatos extra: staffExtraHireCandidates).
//   - Adjunto: com a vaga de principal aberta, a equipa perde menos rendimento (0,96 em vez de 0,93).
//     Treinador de formação: ±10% no desenvolvimento da Academia (junto do efeito do principal).
//   - Custo: o staff do utilizador já está "incluído na estrutura" do clube; só o que exceder o salário
//     base do escalão é debitado (staffMensal).
// =================================================================================
var STAFF_RETIRE_MIN = 60;
var STAFF_RETIRE_MAX = 72;
var STAFF_POOL_CAP = 320;
var STAFF_PROPOSTA_DIAS = 14;
var STAFF_FUNCOES = {
  adjunto: { label: "Treinador adjunto", etapa: 1, slot: "adjunto", frac: 0.45 },
  formacao: { label: "Treinador de formação", etapa: 0, slot: "treinadorFormacao", frac: 0.30 },
  // Fase 2 (0.4.26): staff especializado — carreira própria (pool state.staffEspecialistas), sem pirâmide.
  fisico: { label: "Preparador físico", etapa: 0, slot: "preparadorFisico", frac: 0.30, esp: true },
  gr: { label: "Treinador de guarda-redes", etapa: 0, slot: "treinadorGR", frac: 0.30, esp: true },
  scout: { label: "Scout principal", etapa: 0, slot: "scoutPrincipal", frac: 0.30, esp: true },
};
var STAFF_ESP = {
  fisico: ["preparacaoFisica", "prevencaoLesoes", "recuperacao"],
  gr: ["tecnicaGR", "reflexosGR", "desenvolvimentoGR"],
  scout: ["redeContactos", "avaliacao", "rapidez"],
};
var STAFF_ESP_LABEL = {
  preparacaoFisica: "Preparação física", prevencaoLesoes: "Prevenção de lesões", recuperacao: "Recuperação",
  tecnicaGR: "Técnica de GR", reflexosGR: "Reflexos e 1×1", desenvolvimentoGR: "Desenvolvimento de GR",
  redeContactos: "Rede de contactos", avaliacao: "Avaliação de talento", rapidez: "Rapidez de relatório",
};

function staffEtapa(c){ return c && c.etapa != null ? c.etapa : 2; }
function staffExp(c){ return c && c.stats && Number.isFinite(c.stats.reputacaoExperiencia) ? c.stats.reputacaoExperiencia : 8; }
function staffIdade(c, date){
  const d = new Date(date || state.currentDate || new Date()), b = new Date(c.dataNascimento);
  if(isNaN(b.getTime())) return 45;
  let a = d.getFullYear() - b.getFullYear();
  if(d.getMonth() < b.getMonth() || (d.getMonth() === b.getMonth() && d.getDate() < b.getDate())) a--;
  return a;
}
function staffRetireProb(age){
  if(age < STAFF_RETIRE_MIN) return 0;
  if(age >= STAFF_RETIRE_MAX) return 1;
  return Math.pow((age - (STAFF_RETIRE_MIN - 1)) / (STAFF_RETIRE_MAX - STAFF_RETIRE_MIN + 1), 1.8);
}
function staffPool(){ if(!Array.isArray(state.treinadoresDisponiveis)) state.treinadoresDisponiveis = []; return state.treinadoresDisponiveis; }
function staffEspPool(){ if(!Array.isArray(state.staffEspecialistas)) state.staffEspecialistas = []; return state.staffEspecialistas; }
function staffPoolFor(fn){ return STAFF_FUNCOES[fn].esp ? staffEspPool().filter(c => c.espFuncao === fn) : staffPool(); }
function staffAddToPool(c){ (c.espFuncao ? staffEspPool() : staffPool()).push(c); }
function staffRemoveFromPool(c){ if(c.espFuncao) state.staffEspecialistas = staffEspPool().filter(x => x !== c); else state.treinadoresDisponiveis = staffPool().filter(x => x !== c); }
function staffEspQuality(c){ if(!c || !c.espStats) return staffExp(c); const v = Object.values(c.espStats); return v.length ? v.reduce((a, b) => a + b, 0) / v.length : 8; }
function staffArquivo(){ if(!Array.isArray(state.staffRetirados)) state.staffRetirados = []; return state.staffRetirados; }
function staffPropostas(){ if(!Array.isArray(state.staffPropostas)) state.staffPropostas = []; return state.staffPropostas; }
function staffHistTotals(c){
  const h = Array.isArray(c.historico) ? c.historico : [], m = c.mandatoAtual || {};
  return h.reduce((a, x) => ({ j: a.j + (x.jogos || 0), v: a.v + (x.vitorias || 0) }), { j: m.jogos || 0, v: m.vitorias || 0 });
}
function staffArquivar(c, motivo, clube){
  const t = staffHistTotals(c);
  staffArquivo().unshift({ id: c.id, nome: c.nome, idade: staffIdade(c), epoca: seasonLabel(state.season), motivo, etapa: staffEtapa(c), origem: c.origem || "gerado",
    clube: clube ? clube.name : null, jogos: t.j, vitorias: t.v, exp: Math.round(staffExp(c)) });
  if(staffArquivo().length > 400) staffArquivo().length = 400;
}

// ---------- salários ----------
function staffSalario(c, funcao, team){
  if(funcao === "principal") return treinadorSalarioMensal(c.stats, team);
  const f = STAFF_FUNCOES[funcao];
  return Math.max(400, Math.round(treinadorSalarioMensal(c.stats, team) * f.frac / 50) * 50);
}
function staffBaseline(team, funcao){
  const f = STAFF_FUNCOES[funcao];
  const rep = clamp((team.reputacao || 50) / 5, 2, 18);
  return Math.max(400, Math.round((800 + rep * 180) * f.frac / 50) * 50);
}
function staffExtraMensal(team){
  let extra = 0;
  Object.keys(STAFF_FUNCOES).forEach(fn => {
    const c = team[STAFF_FUNCOES[fn].slot];
    if(c) extra += Math.max(0, (c.salario != null ? c.salario : staffSalario(c, fn, team)) - staffBaseline(team, fn));
  });
  return extra;
}
function staffMensal(date){
  const d = new Date(date), key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
  if(state.staffMonthKey === key) return;
  state.staffMonthKey = key;
  staffFillMissing();
  const team = state.teams[state.userTeamId];
  if(!team || team.equipaPrincipalId) return;
  staffContratosBackfill(team);
  const extra = staffExtraMensal(team);
  if(extra > 0) addFinanceMovement(team, "despesa", "Staff", "Salários do staff técnico acima da estrutura base do clube", Math.round(extra), d);
  try { staffCobicaMensal(team, d); staffSugestaoMensal(team, d); } catch(e){ console.warn("[HM2027] staff 2b", e); }
}

// ---------- geração ----------
function staffGenerateEsp(team, funcao, poolOnly, repOverride){
  const rng0 = makeSeededRng(`espgen:${team.id}:${funcao}:${uid()}`);
  const t = { ...team, reputacao: repOverride != null ? repOverride : team.reputacao };
  const pais = normalizeCountryCode(teamCountry(team));
  const id = `${poolOnly ? "pool" : team.id}-${funcao}-${uid()}`;
  const rng = makeSeededRng(id);
  const idade = seededRnd(rng, 26, 52);
  const base = 4 + ((t.reputacao || 50) / 100) * 12;
  const esp = {};
  STAFF_ESP[funcao].forEach(k => { esp[k] = clampAttr(base + seededRnd(rng, -3, 3)); });
  const q = STAFF_ESP[funcao].reduce((a, k) => a + esp[k], 0) / 3;
  const stats = generateTreinadorStats(t, rng);
  stats.reputacaoExperiencia = q;
  const c = {
    id, nome: randomNameForCountry(pais, rng), dataNascimento: makeBirthDate(rng, idade, state.currentDate ? new Date(state.currentDate) : undefined),
    nacionalidade: nationalityForCountry(pais), paisOrigem: pais, stats, espStats: esp, espFuncao: funcao,
    clubeActualId: poolOnly ? null : team.id, mandatoAtual: poolOnly ? null : defaultTreinadorMandato(state.season, state.currentDate),
    historico: [], etapa: 0, funcao, origem: "gerado", semClubeDesde: poolOnly ? isoDate(state.currentDate || new Date()) : null,
  };
  if(!poolOnly) c.salario = staffSalario(c, funcao, team);
  return c;
}
function staffGenerate(team, funcao){
  const f = STAFF_FUNCOES[funcao];
  if(f.esp) return staffGenerateEsp(team, funcao, false);
  const pais = normalizeCountryCode(teamCountry(team));
  const id = `${team.id}-${funcao}-${uid()}`;
  const rng = makeSeededRng(id);
  const idade = funcao === "adjunto" ? seededRnd(rng, 32, 56) : seededRnd(rng, 28, 50);
  const stats = generateTreinadorStats(team, rng);
  const penal = funcao === "adjunto" ? 1.5 : 3;
  TREINADOR_STATS_COMPETENCIA.forEach(k => { stats[k] = clampAttr(stats[k] - penal); });
  const c = {
    id, nome: randomNameForCountry(pais, rng), dataNascimento: makeBirthDate(rng, idade, state.currentDate ? new Date(state.currentDate) : undefined),
    nacionalidade: nationalityForCountry(pais), paisOrigem: pais, stats, clubeActualId: team.id,
    mandatoAtual: defaultTreinadorMandato(state.season, state.currentDate), historico: [], etapa: f.etapa, funcao, origem: "gerado",
  };
  c.salario = staffSalario(c, funcao, team);
  return c;
}
function staffSeedEspPool(team){
  // Semente do mercado de especialistas (jogo novo ou gravação anterior à 0.4.27): ~10 por especialidade.
  Object.keys(STAFF_FUNCOES).filter(fn => STAFF_FUNCOES[fn].esp).forEach(fn => {
    let n = staffPoolFor(fn).length;
    const rng = makeSeededRng(`staff-esp-seed:${fn}:${state.season}:${team.id}`);
    while(n < 10){ staffEspPool().push(staffGenerateEsp(team, fn, true, seededRnd(rng, 25, 70))); n++; }
  });
}
function bootstrapStaffIfEmpty(team){
  if(!academyEligible(team)) return;
  staffSeedEspPool(team);
  Object.keys(STAFF_FUNCOES).forEach(fn => {
    const slot = STAFF_FUNCOES[fn].slot;
    if(team[slot]) return;
    if(team.staffVagas && team.staffVagas[fn]) return;
    team[slot] = staffGenerate(team, fn);
  });
}

// ---------- ex-jogadores → treinadores ----------
function staffCoachFromPlayer(player, team, etapa, rng){
  const ovr = overall(player), rep = player.reputacaoJogador || 0;
  const jogos = ((player.career && player.career.jogos) || 0) + ((player.season && player.season.jogos) || 0);
  const expBase = clampAttr(2 + ovr * 0.22 + rep / 100 * 5 + Math.min(2, jogos / 300));
  const stats = {};
  TREINADOR_STATS_COMPETENCIA.forEach(k => { stats[k] = clampAttr(expBase - 1 + seededRnd(rng, -3, 3)); });
  stats.reputacaoExperiencia = clampAttr(expBase);
  TREINADOR_STATS_PERFIL.forEach(k => { stats[k] = clampAttr(treinadorPerfilRoll(rng)); });
  const pais = normalizeCountryCode(player.paisOrigem || teamCountry(team));
  const c = {
    id: `${player.id}-treinador-${uid()}`, nome: player.name, dataNascimento: player.dataNascimento || makeBirthDate(rng, player.age || 35, state.currentDate ? new Date(state.currentDate) : undefined),
    nacionalidade: player.nacionalidade || nationalityForCountry(pais), paisOrigem: pais, stats, clubeActualId: null, mandatoAtual: null, historico: [],
    etapa, funcao: etapa >= 1 ? "adjunto" : "formacao", origem: "ex-jogador", jogadorId: player.id, especialidade: player.pos === "GR" ? "GR" : null,
    carreiraJogador: { jogos, ovr: Math.round(ovr), clube: team.name, epoca: seasonLabel(state.season) },
    semClubeDesde: isoDate(state.currentDate || new Date()),
  };
  return c;
}
function staffEspFromPlayer(player, team, rng, funcao){
  const ovr = overall(player), rep = player.reputacaoJogador || 0;
  const jogos = ((player.career && player.career.jogos) || 0) + ((player.season && player.season.jogos) || 0);
  const q = clampAttr(3 + ovr * 0.3 + rep / 100 * 4 + Math.min(2, jogos / 300));
  const esp = {};
  STAFF_ESP[funcao].forEach(k => { esp[k] = clampAttr(q + seededRnd(rng, -2, 2)); });
  const stats = {};
  TREINADOR_STATS_COMPETENCIA.forEach(k => { stats[k] = clampAttr(q - 1 + seededRnd(rng, -3, 3)); });
  stats.reputacaoExperiencia = q;
  TREINADOR_STATS_PERFIL.forEach(k => { stats[k] = clampAttr(treinadorPerfilRoll(rng)); });
  const pais = normalizeCountryCode(player.paisOrigem || teamCountry(team));
  return {
    id: `${player.id}-${funcao}-${uid()}`, nome: player.name, dataNascimento: player.dataNascimento || makeBirthDate(rng, player.age || 35, state.currentDate ? new Date(state.currentDate) : undefined),
    nacionalidade: player.nacionalidade || nationalityForCountry(pais), paisOrigem: pais, stats, espStats: esp, espFuncao: funcao,
    clubeActualId: null, mandatoAtual: null, historico: [], etapa: 0, funcao, origem: "ex-jogador", jogadorId: player.id,
    carreiraJogador: { jogos, ovr: Math.round(ovr), clube: team.name, epoca: seasonLabel(state.season) }, semClubeDesde: isoDate(state.currentDate || new Date()),
  };
}
function staffFromRetiredPlayer(player, team){
  try {
    if(!player || !team || team.selecaoNacional || team.nuvemEuropeia) return null;
    const rep = player.reputacaoJogador || 0;
    const jogos = ((player.career && player.career.jogos) || 0) + ((player.season && player.season.jogos) || 0);
    const mine = team.id === state.userTeamId;
    const lenda = mine && state.lendaJogadorId === player.id;
    const rng = makeSeededRng(`staff-ex:${player.id}:${state.season}`);
    let p = 0.10 + Math.min(0.15, rep / 100 * 0.15) + Math.min(0.12, jogos / 600 * 0.12) + (player.pos === "GR" ? 0.04 : 0);
    if(!lenda && seededRndFloat(rng, 0, 1) >= p) return null;
    const etapa = (lenda || rep >= 65 || jogos >= 400) ? 1 : 0;
    // 0.4.26: antigos guarda-redes tornam-se muitas vezes treinadores de GR (especialistas)
    const paraGR = player.pos === "GR" && seededRndFloat(rng, 0, 1) < 0.7;
    const c = paraGR ? staffEspFromPlayer(player, team, rng, "gr") : staffCoachFromPlayer(player, team, etapa, rng);
    const destino = paraGR ? "gr" : (etapa >= 1 ? "adjunto" : "formacao");
    if(mine && (lenda || (jogos >= 150 && seededRndFloat(rng, 0, 1) < 0.5))){
      staffCriarProposta(team, c, destino, lenda ? "lenda" : "idolo");
      return c;
    }
    staffAddToPool(c);
    return c;
  } catch(e){ console.warn("[HM2027] staffFromRetiredPlayer", e); return null; }
}

// ---------- instalação num lugar ----------
function staffLimparSlot(team, funcao, motivo){
  const f = STAFF_FUNCOES[funcao], old = team[f.slot];
  if(!old) return null;
  const d = new Date(state.currentDate || new Date());
  const m = old.mandatoAtual || { jogos: 0, vitorias: 0, empates: 0, derrotas: 0 };
  old.historico = Array.isArray(old.historico) ? old.historico : [];
  old.historico.unshift({ clubId: team.id, clubName: team.name, epocaSaida: seasonLabel(state.season), jogos: m.jogos, vitorias: m.vitorias, empates: m.empates, derrotas: m.derrotas, motivoSaida: motivo || "substituido", data: isoDate(d), funcao });
  if(old.historico.length > 10) old.historico.length = 10;
  old.clubeActualId = null; old.mandatoAtual = null; old.semClubeDesde = isoDate(d); old.salario = null;
  team[f.slot] = null;
  return old;
}
function staffInstalar(team, funcao, c){
  const f = STAFF_FUNCOES[funcao];
  c.clubeActualId = team.id; c.funcao = funcao; c.etapa = Math.max(c.etapa != null ? c.etapa : 0, f.etapa);
  c.mandatoAtual = defaultTreinadorMandato(state.season, state.currentDate);
  c.semClubeDesde = null;
  c.salario = staffSalario(c, funcao, team);
  if(team.id === state.userTeamId){ c.contratoAte = staffContratoNovo(); c.contratadoEm = isoDate(new Date(state.currentDate || new Date())); c.protegidoAte = null; }
  else { c.contratoAte = null; c.contratadoEm = null; c.protegidoAte = null; }
  team[f.slot] = c;
  if(team.staffVagas) team.staffVagas[funcao] = false;
}

// ---------- preencher lugares (IA) ----------
function staffFitSlot(c, team, funcao){
  if(STAFF_FUNCOES[funcao].esp) return -Math.abs(staffEspQuality(c) - (4 + (team.reputacao || 50) * 0.12));
  const alvo = (team.reputacao || 50) / 5 - (funcao === "adjunto" ? 2 : 4);
  return -Math.abs(staffExp(c) - alvo) - (funcao === "adjunto" ? 0 : Math.max(0, staffEtapa(c) - 1) * 3);
}
function staffFillSlot(team, funcao){
  const f = STAFF_FUNCOES[funcao];
  if(team[f.slot]) return;
  const rng = makeSeededRng(`staff-fill:${team.id}:${funcao}:${state.season}`);
  // promoção interna: o treinador de formação sobe a adjunto
  if(funcao === "adjunto" && team.treinadorFormacao && staffExp(team.treinadorFormacao) >= 9 && seededRndFloat(rng, 0, 1) < 0.5){
    const c = staffLimparSlot(team, "formacao", "promovido");
    staffInstalar(team, "adjunto", c);
    return;
  }
  const pool = staffPoolFor(funcao);
  const esp = !!f.esp;
  const cand = pool.map(c => ({ c, fit: staffFitSlot(c, team, funcao) }))
    .filter(x => !(x.c.historico && x.c.historico[0] && x.c.historico[0].clubId === team.id) && x.fit > -4 && (esp || staffExp(x.c) <= (team.reputacao || 50) / 5 + 2) && (funcao !== "formacao" || staffEtapa(x.c) <= 1))
    .sort((a, b) => b.fit - a.fit);
  if(cand.length){
    const c = cand[0].c;
    staffRemoveFromPool(c);
    staffInstalar(team, funcao, c);
    return;
  }
  staffInstalar(team, funcao, staffGenerate(team, funcao));
}

function staffFillMissing(){
  Object.values(state.teams).forEach(t => {
    if(t.id === state.userTeamId || t.equipaPrincipalId || !academyEligible(t)) return;
    Object.keys(STAFF_FUNCOES).forEach(fn => { if(!t[STAFF_FUNCOES[fn].slot]) staffFillSlot(t, fn); });
  });
}
// ---------- candidatos extra à vaga de principal (promoção do adjunto) ----------
function staffExtraHireCandidates(team, date, rng){
  const out = [];
  const alvo = (team.reputacao || 50) / 5;
  if(team.adjunto && staffExp(team.adjunto) >= alvo - 5)
    out.push({ tr: team.adjunto, score: treinadorFitScore(team.adjunto, team) + 2.5, origemClube: null, origemAdjunto: team });
  if(seededRndFloat(rng, 0, 1) < 0.25){
    Object.values(state.teams).forEach(other => {
      if(other.id === team.id || other.id === state.userTeamId || !academyEligible(other) || !other.adjunto) return;
      if(staffExp(other.adjunto) < Math.max(6, alvo - 3) || staffExp(other.adjunto) > alvo + 2) return;
      out.push({ tr: other.adjunto, score: treinadorFitScore(other.adjunto, team) + 1, origemClube: null, origemAdjunto: other });
    });
  }
  return out;
}
// Chamado por hireTreinadorForVacancy quando a escolha vem de um lugar de adjunto.
function staffPromoverAdjunto(tr, origem, team, date){
  const c = staffLimparSlot(origem, "adjunto", "promovido");
  if(origem.id !== team.id) pushTreinadorMercadoNews(origem, date, `${escapeHtml(tr.nome)}, adjunto do ${teamLinkHtml(origem.id)}, assume o comando técnico de outro clube.`, "Adjunto promovido a treinador");
  return c || tr;
}

// ---------- processo anual ----------
function staffProgress(c, role){
  if(!c || !c.stats) return;
  if(c.espStats){
    Object.keys(c.espStats).forEach(k => { c.espStats[k] = clamp(c.espStats[k] + (c.espStats[k] < 15 ? 0.3 : 0.1), 0, 20); });
    c.stats.reputacaoExperiencia = staffEspQuality(c);
    return;
  }
  const e = staffExp(c);
  let d = 0;
  if(role === "principal"){
    const m = c.mandatoAtual;
    if(m && m.jogos >= 10){ const pct = treinadorRecordPct(m); d = pct >= 60 ? 1 : pct >= 50 ? 0.6 : pct >= 35 ? 0.2 : -0.4; }
    else d = 0.2;
  } else { d = e < 13 ? 0.5 : 0.2; }
  if(d) c.stats.reputacaoExperiencia = clamp(e + d, 0, 20);
}
function staffAnnual(){
  if(state.staffProcessedSeason === state.season) return;
  state.staffProcessedSeason = state.season;
  const date = new Date(state.currentDate || new Date());
  const iso = isoDate(date);
  const teams = Object.values(state.teams).filter(t => academyEligible(t) && !t.equipaPrincipalId);
  // 1. progressão de experiência
  teams.forEach(t => {
    if(t.treinador && t.id !== state.userTeamId) staffProgress(t.treinador, "principal");
    Object.keys(STAFF_FUNCOES).forEach(fn => { const c = t[STAFF_FUNCOES[fn].slot]; if(c) staffProgress(c, fn); });
  });
  // 2. reformas — principais (IA), adjuntos, formação, pool
  const retire = (c, tag) => seededRndFloat(makeSeededRng(`staff-ret:${c.id}:${state.season}:${tag}`), 0, 1) < staffRetireProb(staffIdade(c, date));
  teams.forEach(t => {
    const tr = t.treinador;
    if(tr && t.id !== state.userTeamId && retire(tr, "p")){
      registerTreinadorClubExit(tr, t, date, "reforma");
      staffArquivar(tr, "reforma", t);
      t.treinador = null;
      const rng = makeSeededRng(`treinador-vaga:${t.id}:${iso}`);
      t.treinadorVacancia = { desde: iso, motivo: "reforma", resolverEm: isoDate(addDays(date, seededRnd(rng, 14, 28))) };
      t.treinadorConfiancaBaixaMeses = 0; t.treinadorAvisoEmitido = false;
      pushTreinadorMercadoNews(t, date, `${escapeHtml(tr.nome)} reforma-se do banco do ${teamLinkHtml(t.id)}, aos ${staffIdade(tr, date)} anos.`, "Treinador reforma-se");
    }
    Object.keys(STAFF_FUNCOES).forEach(fn => {
      const c = t[STAFF_FUNCOES[fn].slot];
      if(c && retire(c, fn)){
        staffLimparSlot(t, fn, "reforma"); staffArquivar(c, "reforma", t);
        if(t.id === state.userTeamId){
          t.staffVagas = t.staffVagas || {}; t.staffVagas[fn] = true;
          pushNews(date, `${escapeHtml(c.nome)}, ${STAFF_FUNCOES[fn].label.toLowerCase()} do teu clube, reformou-se. Podes contratar um substituto em Clube → Staff técnico.`, "staff", "Staff: reforma", { teamId: t.id });
        }
      }
    });
  });
  const limparPool = c => {
    const idade = staffIdade(c, date);
    const ult = (c.historico && c.historico[0] && c.historico[0].data) || c.semClubeDesde;
    const anos = ult ? (date - new Date(ult)) / 31557600000 : 0;
    let sai = null;
    if(retire(c, "pool")) sai = "reforma";
    else if(anos >= 3 && seededRndFloat(makeSeededRng(`staff-afast:${c.id}:${state.season}`), 0, 1) < 0.35) sai = "afastado";
    else if(idade >= 66 && anos >= 1) sai = "reforma";
    if(!sai) return true;
    staffArquivar(c, sai, null);
    return false;
  };
  state.treinadoresDisponiveis = staffPool().filter(limparPool);
  state.staffEspecialistas = staffEspPool().filter(limparPool);
  // 2b. rotação: adjuntos e formadores de clubes de IA mudam de ares ao fim de 2+ épocas (~10%/ano)
  teams.forEach(t => {
    if(t.id === state.userTeamId) return;
    Object.keys(STAFF_FUNCOES).forEach(fn => {
      const c = t[STAFF_FUNCOES[fn].slot];
      if(!c || !c.mandatoAtual || (state.season - (c.mandatoAtual.epocaInicio || 0)) < 2) return;
      if(seededRndFloat(makeSeededRng(`staff-rot:${c.id}:${state.season}`), 0, 1) < 0.10){
        const velho = staffLimparSlot(t, fn, "saida");
        if(velho) staffAddToPool(velho);
      }
    });
  });
  // 2c. entrada de especialistas de carreira própria (mantém ~12 por especialidade no mercado)
  Object.keys(STAFF_FUNCOES).filter(fn => STAFF_FUNCOES[fn].esp).forEach(fn => {
    let n = staffPoolFor(fn).length;
    const clubes = teams.filter(t => t.id !== state.userTeamId);
    const rngIn = makeSeededRng(`staff-esp-in:${fn}:${state.season}`);
    while(n < 12 && clubes.length){
      const base = clubes[seededRnd(rngIn, 0, clubes.length - 1)];
      staffEspPool().push(staffGenerateEsp(base, fn, true, seededRnd(rngIn, 25, 70)));
      n++;
    }
  });
  if(typeof staffCriarRenovacoes === "function") staffCriarRenovacoes();   // 0.4.28: contratos do staff do utilizador
  // 3. preencher lugares (clubes de IA); o utilizador contrata os seus
  teams.forEach(t => {
    if(t.id === state.userTeamId) return;
    Object.keys(STAFF_FUNCOES).forEach(fn => staffFillSlot(t, fn));
  });
  // 3b. repor o mercado de especialistas depois de os clubes de IA se servirem (o utilizador precisa de escolha)
  Object.keys(STAFF_FUNCOES).filter(fn => STAFF_FUNCOES[fn].esp).forEach(fn => {
    let n = staffPoolFor(fn).length;
    const clubes = teams.filter(t => t.id !== state.userTeamId);
    const rngIn = makeSeededRng(`staff-esp-in2:${fn}:${state.season}`);
    while(n < 10 && clubes.length){
      const base = clubes[seededRnd(rngIn, 0, clubes.length - 1)];
      staffEspPool().push(staffGenerateEsp(base, fn, true, seededRnd(rngIn, 25, 70)));
      n++;
    }
  });
  // 4. limite técnico de segurança do pool
  const pool = staffPool();
  if(pool.length > STAFF_POOL_CAP){
    pool.sort((a, b) => staffExp(b) - staffExp(a));
    pool.slice(STAFF_POOL_CAP).forEach(c => staffArquivar(c, "afastado", null));
    pool.length = STAFF_POOL_CAP;
  }
}

// ---------- efeitos ----------
function staffFormacaoMult(team){
  const c = team && team.treinadorFormacao;
  if(!c || !c.stats || c.stats.desenvolvimentoJovens == null) return 1;
  return clamp(1 + (c.stats.desenvolvimentoJovens - 10) * 0.01, 0.9, 1.1);
}

// ---------- propostas ao utilizador (lendas e ídolos) ----------
function staffCriarProposta(team, c, funcao, motivo){
  const d = new Date(state.currentDate || new Date());
  const id = `sp:${c.id}`;
  c.semClubeDesde = isoDate(d);
  const p = { id, tipo: funcao, motivo, clubId: team.id, criada: isoDate(d), expiraEm: isoDate(addDays(d, STAFF_PROPOSTA_DIAS)), estado: "pendente", coach: c };
  staffPropostas().unshift(p);
  if(staffPropostas().length > 20) staffPropostas().length = 20;
  const quem = motivo === "lenda" ? "a lenda do clube" : "antigo jogador do clube";
  pushNews(d, `${escapeHtml(c.nome)}, ${quem}, terminou a carreira e quer ficar ligado ao ${teamLinkHtml(team.id)} como ${STAFF_FUNCOES[funcao].label.toLowerCase()}. Tens até ${fmtDateShort(p.expiraEm)} para decidir. <button class="news-open-staff" data-staff-act="proposta" data-id="${id}">Ver proposta →</button>`,
    "staff", "Proposta de staff", { teamId: team.id, autoAdvanceStop: true });
  return p;
}
function staffProposta(id){ return staffPropostas().find(p => p.id === id) || null; }
function staffResponderProposta(id, aceitar){
  const p = staffProposta(id);
  if(!p || p.estado !== "pendente") return { ok: false, reason: "Esta proposta já não está pendente." };
  const team = state.teams[p.clubId];
  if(p.motivo === "renovacao" || p.motivo === "cobica") return staffResponderContinuidade(p, aceitar);
  if(aceitar){
    if(!team) return { ok: false, reason: "O clube já não existe." };
    const velho = staffLimparSlot(team, p.tipo, "substituido");
    if(velho) staffAddToPool(velho);
    staffInstalar(team, p.tipo, p.coach);
    p.estado = "aceite";
    pushNews(state.currentDate, `${escapeHtml(p.coach.nome)} é o novo ${STAFF_FUNCOES[p.tipo].label.toLowerCase()} do ${teamLinkHtml(team.id)}.`, "staff", "Staff: novo elemento", { teamId: team.id });
  } else {
    p.estado = "recusada";
    staffAddToPool(p.coach);
  }
  return { ok: true };
}
function staffResolveExpired(date){
  const iso = isoDate(new Date(date));
  staffPropostas().forEach(p => {
    if(p.estado !== "pendente" || iso <= p.expiraEm) return;
    p.estado = "expirada";
    if(p.motivo === "renovacao") staffSaidaFimContrato(p);
    else if(p.motivo === "cobica") staffSaidaParaRival(p);
    else staffAddToPool(p.coach);
  });
}

// ---------- contratar (utilizador) ----------
function staffCandidatos(funcao){
  const f = STAFF_FUNCOES[funcao];
  return staffPoolFor(funcao).filter(c => funcao === "formacao" ? staffEtapa(c) <= 1 : true)
    .map(c => ({ c, q: f.esp ? staffEspQuality(c) : TREINADOR_STATS_COMPETENCIA.reduce((a, k) => a + (c.stats[k] || 0), 0) / TREINADOR_STATS_COMPETENCIA.length + (funcao === "formacao" ? (c.stats.desenvolvimentoJovens || 0) * 0.5 : 0) }))
    .sort((a, b) => b.q - a.q).slice(0, 14).map(x => x.c);
}
function staffAceita(c, team, funcao){
  const need = staffExp(c) * 4 - (funcao === "adjunto" ? 10 : 20);
  return (team.reputacao || 50) >= need ? { ok: true } : { ok: false, reason: `${c.nome} não aceita: o clube não tem a estatura que ele procura.` };
}
function staffContratar(funcao, coachId){
  const team = state.teams[state.userTeamId], f = STAFF_FUNCOES[funcao];
  if(!team || !f) return { ok: false, reason: "Clube inválido." };
  const c = staffPoolFor(funcao).find(x => x.id === coachId);
  if(!c) return { ok: false, reason: "Este candidato já não está disponível." };
  const a = staffAceita(c, team, funcao);
  if(!a.ok) return a;
  staffRemoveFromPool(c);
  const velho = staffLimparSlot(team, funcao, "substituido");
  if(velho) staffAddToPool(velho);
  staffInstalar(team, funcao, c);
  pushNews(state.currentDate, `${escapeHtml(c.nome)} é o novo ${f.label.toLowerCase()} do ${teamLinkHtml(team.id)}.`, "staff", "Staff: novo elemento", { teamId: team.id });
  return { ok: true };
}

// ---------- fichas ----------
function staffFindById(id){
  let c = staffPool().find(x => x.id === id) || staffEspPool().find(x => x.id === id);
  if(c) return { c, clube: null };
  const p = staffPropostas().find(x => x.coach && x.coach.id === id && x.motivo !== "renovacao" && x.motivo !== "cobica");
  if(p) return { c: p.coach, clube: null };
  for(const t of Object.values(state.teams)){
    for(const fn of Object.keys(STAFF_FUNCOES)){ const x = t[STAFF_FUNCOES[fn].slot]; if(x && x.id === id) return { c: x, clube: t }; }
  }
  return null;
}
function staffFichaData(id){
  const r = staffFindById(id);
  if(!r) return null;
  const { c, clube } = r;
  const funcao = clube ? STAFF_FUNCOES[c.funcao] && STAFF_FUNCOES[c.funcao].label : (c.espFuncao ? `${STAFF_FUNCOES[c.espFuncao].label} (sem clube)` : null);
  const salFn = c.espFuncao || (c.funcao === "formacao" ? "formacao" : "adjunto");
  return {
    kind: "pessoa", teamId: clube ? clube.id : null, nome: c.nome, nacionalidade: c.nacionalidade, dataNascimento: c.dataNascimento, stats: c.stats,
    clubeNome: clube ? clube.name : "Sem clube", mandatoAtual: c.mandatoAtual || defaultTreinadorMandato(state.season, state.currentDate),
    historico: c.historico || [], salario: c.salario != null ? c.salario : staffSalario(c, salFn, state.teams[state.userTeamId] || {}),
    contratoAte: clube && clube.id === state.userTeamId && c.contratoAte ? seasonLabel(c.contratoAte) : null,
    espStats: c.espStats || null, efeito: clube && c.espFuncao ? staffEfeitoTexto(c.espFuncao, clube) : null,
    funcaoLabel: funcao || (staffEtapa(c) >= 2 ? "Treinador (sem clube)" : "Candidato a staff"),
    origem: c.origem === "ex-jogador" ? `Ex-jogador${c.carreiraJogador ? ` (${c.carreiraJogador.jogos} jogos, OVR ${c.carreiraJogador.ovr})` : ""}` : (c.espFuncao ? "Especialista de carreira" : "Treinador de carreira"),
  };
}

// ---------- interface ----------
function staffStatCell(v){ return `<b style="color:${typeof attrValColor === "function" ? attrValColor(Math.round(v)) : "inherit"}">${Math.round(v)}</b>`; }
function staffClubHtml(team){
  if(!academyEligible(team) || team.equipaPrincipalId) return "";
  const mine = team.id === state.userTeamId;
  const rows = Object.keys(STAFF_FUNCOES).map(fn => {
    const f = STAFF_FUNCOES[fn], c = team[f.slot];
    const hire = mine ? ` <button class="btn btn-ghost" data-staff-act="hire" data-funcao="${fn}">${c ? "Mudar" : "Contratar"}</button>` : "";
    if(!c) return `<div class="pm-retro-row"><span class="lbl">${f.label}</span><span class="val">${mine ? '<span class="helptext">vaga por preencher</span>' : "—"}${hire}</span></div>`;
    const sal = c.salario != null ? c.salario : staffSalario(c, fn, team);
    const extra = mine ? Math.max(0, sal - staffBaseline(team, fn)) : 0;
    return `<div class="pm-retro-row"><span class="lbl">${f.label}</span><span class="val">${escapeHtml(c.nome)} <span class="helptext">${staffIdade(c)} anos · ${f.esp ? `nível ${Math.round(staffEspQuality(c))}` : `exp. ${Math.round(staffExp(c))}`}${c.origem === "ex-jogador" ? " · ex-jogador" : ""}${extra > 0 ? ` · +${fmtMoney(extra)}/mês` : ""}</span> <button class="btn btn-ghost" data-staff-act="ficha" data-id="${c.id}">Ficha</button>${hire}</span></div>`;
  }).join("");
  let props = "";
  if(mine){
    const pend = staffPropostas().filter(p => p.estado === "pendente");
    if(pend.length) props = `<div class="pm-retro-subline" style="margin-top:8px;">Propostas de staff:</div>` + pend.map(p => `<div class="pm-retro-row"><span class="lbl">${escapeHtml(p.coach.nome)}</span><span class="val">${STAFF_FUNCOES[p.tipo].label} · até ${fmtDateShort(p.expiraEm)} <button class="btn btn-ghost" data-staff-act="proposta" data-id="${p.id}">Ver</button></span></div>`).join("");
  }
  return `<div class="pm-retro-section-lbl" style="margin-top:14px;">Staff técnico</div>${rows}${props}`;
}
function staffOverlay(html){
  let root = document.getElementById("staffOverlay");
  if(root) root.remove();
  root = document.createElement("div");
  root.id = "staffOverlay"; root.className = "nm-overlay"; root.style.zIndex = 190;
  root.innerHTML = `<div class="nm-modal" role="dialog" aria-modal="true" style="max-width:min(940px,94vw);">${html}</div>`;
  document.body.appendChild(root);
  return root;
}
function staffRefresh(){
  try { if(state.activeView === "staff" && typeof renderStaffPanel === "function") renderStaffPanel(); } catch(e){}
  try { if(typeof renderClubFichaView === "function" && document.getElementById("fichaStaffOpenBtn")) renderClubFichaView(); } catch(e){}
  try { if(typeof renderAll === "function") renderAll(); } catch(e){}
}
function openStaffHireModal(funcao){
  const team = state.teams[state.userTeamId], f = STAFF_FUNCOES[funcao];
  if(!team || !f) return;
  const cand = staffCandidatos(funcao);
  const atual = team[f.slot];
  const rows = cand.map(c => {
    const sal = staffSalario(c, funcao, team), extra = Math.max(0, sal - staffBaseline(team, funcao));
    const cols = f.esp ? STAFF_ESP[funcao].map(k => `<td>${staffStatCell(c.espStats[k])}</td>`).join("") : `<td>${staffStatCell(staffExp(c))}</td><td>${staffStatCell(c.stats.desenvolvimentoJovens || 0)}</td><td>${staffStatCell(c.stats.adaptabilidade || 0)}</td>`;
    return `<tr><td style="text-align:left;">${escapeHtml(c.nome)}</td><td>${staffIdade(c)}</td><td>${c.origem === "ex-jogador" ? "ex-jogador" : (f.esp ? "carreira" : "treinador")}</td>${cols}<td>${fmtMoney(sal)}${extra > 0 ? ` <span class="helptext">(+${fmtMoney(extra)})</span>` : ""}</td><td style="white-space:nowrap;"><button class="btn btn-ghost" data-staff-act="ficha" data-id="${c.id}">Ficha</button> <button class="btn btn-primary" data-staff-do="contratar" data-id="${c.id}">Contratar</button></td></tr>`;
  }).join("");
  const root = staffOverlay(`
    <div class="nm-box" style="margin-bottom:8px;"><b>${f.label}</b> — ${atual ? `atual: ${escapeHtml(atual.nome)}` : "vaga por preencher"}.
      <div class="helptext" style="margin-top:4px;">Salário incluído na estrutura do clube: ${fmtMoney(staffBaseline(team, funcao))}/mês. O que exceder é debitado todos os meses.</div></div>
    <div class="nm-box" style="max-height:48vh;overflow:auto;"><table class="pm-retro-stat-table" style="text-align:center;"><thead><tr><th style="text-align:left;">Nome</th><th>Idade</th><th>Origem</th>${f.esp ? STAFF_ESP[funcao].map(k => `<th>${escapeHtml(STAFF_ESP_LABEL[k])}</th>`).join("") : "<th>Exp.</th><th>Jov.</th><th>Adapt.</th>"}<th>Salário/mês</th><th></th></tr></thead><tbody>${rows || `<tr><td colspan="9">Sem candidatos disponíveis de momento.</td></tr>`}</tbody></table></div>
    <div class="nm-err" id="staffErr"></div>
    <div class="nm-foot"><button class="nm-btn" data-staff-do="fechar">Fechar</button></div>`);
  root.addEventListener("click", ev => {
    const b = ev.target.closest("[data-staff-do]");
    if(!b) return;
    const act = b.getAttribute("data-staff-do");
    if(act === "fechar"){ root.remove(); return; }
    if(act === "contratar"){
      const r = staffContratar(funcao, b.getAttribute("data-id"));
      if(!r.ok){ const er = document.getElementById("staffErr"); if(er) er.textContent = r.reason || "Não foi possível contratar."; return; }
      root.remove(); staffRefresh();
    }
  });
}
function openStaffProposalModal(id){
  const p = staffProposta(id);
  if(!p || p.estado !== "pendente") return;
  const team = state.teams[p.clubId], c = p.coach, f = STAFF_FUNCOES[p.tipo];
  const atual = team && team[f.slot];
  const sal = staffSalario(c, p.tipo, team), extra = Math.max(0, sal - staffBaseline(team, p.tipo));
  const kv = (k, v) => `<div class="nm-kv"><span>${k}</span><b>${v}</b></div>`;
  if(p.motivo === "renovacao" || p.motivo === "cobica") return openStaffContinuidadeModal(p);
  const root = staffOverlay(`
    <div class="nm-head"><h3>🎓 Proposta de staff</h3><p>${escapeHtml(c.nome)} quer ficar ligado ao clube depois de terminar a carreira.</p></div>
    <div class="nm-box">
      ${kv("Candidato", `${escapeHtml(c.nome)} · ${staffIdade(c)} anos`)}
      ${kv("Carreira de jogador", c.carreiraJogador ? `${c.carreiraJogador.jogos} jogos · OVR final ${c.carreiraJogador.ovr}` : "—")}
      ${kv("Função proposta", f.label)}
      ${f.esp ? kv("Nível de especialidade", `${Math.round(staffEspQuality(c))}`) : kv("Experiência / Desenvolvimento de jovens", `${Math.round(staffExp(c))} / ${Math.round(c.stats.desenvolvimentoJovens || 0)}`)}
      ${kv("Salário", `${fmtMoney(sal)}/mês${extra > 0 ? ` (+${fmtMoney(extra)} acima da estrutura)` : " (incluído na estrutura)"}`)}
      ${kv("Atual", atual ? `${escapeHtml(atual.nome)} (passa a disponível)` : "vaga por preencher")}
      ${kv("Decides até", fmtDateShort(p.expiraEm))}
      <div class="nm-err" id="staffErr"></div>
    </div>
    <div class="nm-foot"><button class="nm-btn" data-staff-do="later">Decidir mais tarde</button><button class="nm-btn" data-staff-do="recusar">Recusar</button><button class="nm-btn p" data-staff-do="aceitar">Aceitar</button><button class="nm-btn" data-staff-act="ficha" data-id="${c.id}">Ficha</button></div>`);
  root.addEventListener("click", ev => {
    const b = ev.target.closest("[data-staff-do]");
    if(!b) return;
    const act = b.getAttribute("data-staff-do");
    if(act === "later"){ root.remove(); return; }
    const r = staffResponderProposta(id, act === "aceitar");
    if(!r.ok){ const er = document.getElementById("staffErr"); if(er) er.textContent = r.reason || "Erro."; return; }
    root.remove(); staffRefresh();
  });
}
document.addEventListener("click", ev => {
  const b = ev.target.closest && ev.target.closest("[data-staff-act]");
  if(!b) return;
  ev.preventDefault();
  const act = b.getAttribute("data-staff-act");
  if(act === "ficha") openTreinadorModal("pessoa", b.getAttribute("data-id"));
  else if(act === "hire") openStaffHireModal(b.getAttribute("data-funcao"));
  else if(act === "proposta") openStaffProposalModal(b.getAttribute("data-id"));
});


// ============================= Fase 2a: efeitos reais dos especialistas =============================
// Efeito relativo ao que se espera do clube: nível do especialista menos o nível "típico" da reputação
// do clube (4 + rep×0,12). Um clube com staff normal fica neutro (a calibração existente não muda);
// quem contrata melhor do que o esperado ganha uma vantagem de ±~10%; lugar vazio = −4.
function staffDonoDoStaff(team){ return team && team.equipaPrincipalId ? (state.teams[team.equipaPrincipalId] || team) : team; }
function staffRel(team, funcao){
  const t = staffDonoDoStaff(team);
  if(!t) return 0;
  const c = t[STAFF_FUNCOES[funcao].slot];
  if(!c) return academyEligible(t) ? -4 : 0;
  return clamp(staffEspQuality(c) - (4 + (t.reputacao || 50) * 0.12), -6, 8);
}
// Preparador físico: risco de lesão, duração e recuperação (junto do departamento médico, 04-financas.js).
function staffFisicoInjuryMult(team){ return clamp(1 - staffRel(team, "fisico") * 0.012, 0.9, 1.08); }
function staffFisicoDurationMult(team){ return clamp(1 - staffRel(team, "fisico") * 0.01, 0.92, 1.06); }
function staffFisicoRecoveryMult(team){ return clamp(1 + staffRel(team, "fisico") * 0.01, 0.94, 1.08); }
// Treinador de GR: evolução anual dos guarda-redes (crescimento e declínio) e uma pequena parte na
// probabilidade de golo sofrido.
function staffGRDevMult(team){ return clamp(1 + staffRel(team, "gr") * 0.015, 0.91, 1.12); }
function staffGRGoalMult(team){ return clamp(1 - staffRel(team, "gr") * 0.004, 0.97, 1.025); }
// Scout principal (só o clube do utilizador): confiança dos relatórios, rapidez, custo, capacidade.
function staffScoutConfBonus(){ const t = state.teams[state.userTeamId]; return t ? clamp(staffRel(t, "scout") * 1.2, -6, 10) : 0; }
function staffScoutSpeedMult(team){ return clamp(1 - staffRel(team, "scout") * 0.015, 0.82, 1.1); }
function staffScoutCostMult(team){ return clamp(1 - staffRel(team, "scout") * 0.01, 0.92, 1.06); }
function staffScoutCapacityBonus(team){ return staffRel(team, "scout") >= 5 ? 1 : 0; }
function staffPct(m){ const v = Math.round((m - 1) * 100); return (v > 0 ? "+" : "") + v + "%"; }
function staffEfeitoTexto(funcao, team){
  if(funcao === "fisico") return `Risco de lesão ${staffPct(staffFisicoInjuryMult(team))} · duração das lesões ${staffPct(staffFisicoDurationMult(team))} · recuperação ${staffPct(staffFisicoRecoveryMult(team))}`;
  if(funcao === "gr") return `Evolução dos guarda-redes ${staffPct(staffGRDevMult(team))} · golos sofridos ${staffPct(staffGRGoalMult(team))}`;
  if(funcao === "scout") return `Prazo dos relatórios ${staffPct(staffScoutSpeedMult(team))} · custo ${staffPct(staffScoutCostMult(team))} · confiança ${staffScoutConfBonus() >= 0 ? "+" : ""}${Math.round(staffScoutConfBonus())}${staffScoutCapacityBonus(team) ? " · +1 pedido em simultâneo" : ""}`;
  if(funcao === "formacao") return `Desenvolvimento da Academia ${staffPct(staffFormacaoMult(team))}`;
  if(funcao === "adjunto") return "Interino quando falta o principal (perde-se menos rendimento)";
  return "";
}

// ============================= Separador Staff =============================
function renderStaffPanel(){
  const root = document.getElementById("staffContent");
  if(!root) return;
  const team = state.teams[state.userTeamId];
  if(!team){ root.innerHTML = ""; return; }
  if(!academyEligible(team) || team.equipaPrincipalId){ root.innerHTML = `<p class="helptext">Este clube não tem estrutura de staff própria.</p>`; return; }
  const g = ensureManagerCareer();
  const pct = treinadorRecordPct(g.mandatoAtual);
  const extraTotal = staffExtraMensal(team);
  let rows = `<tr><td style="text-align:left;">Treinador principal</td><td style="text-align:left;">${escapeHtml(state.managerName || "—")} <span class="helptext">(tu)</span></td><td>—</td><td>—</td><td>—</td><td>—</td><td style="text-align:left;" class="helptext">${g.mandatoAtual.jogos} jogos · ${pct}%V</td><td><button class="btn btn-ghost" id="staffVerGestorBtn">Ficha</button></td></tr>`;
  rows += Object.keys(STAFF_FUNCOES).map(fn => {
    const f = STAFF_FUNCOES[fn], c = team[f.slot];
    if(!c) return `<tr><td style="text-align:left;">${f.label}</td><td style="text-align:left;" class="helptext">vaga por preencher</td><td>—</td><td>—</td><td>—</td><td>—</td><td style="text-align:left;" class="helptext">${f.esp ? "sem efeito (penalização leve)" : ""}</td><td><button class="btn btn-primary" data-staff-act="hire" data-funcao="${fn}">Contratar</button></td></tr>`;
    const sal = c.salario != null ? c.salario : staffSalario(c, fn, team);
    const extra = Math.max(0, sal - staffBaseline(team, fn));
    return `<tr><td style="text-align:left;">${f.label}</td><td style="text-align:left;">${escapeHtml(c.nome)}${c.origem === "ex-jogador" ? ' <span class="helptext">ex-jogador</span>' : ""}</td><td>${staffIdade(c)}</td><td>${staffStatCell(f.esp ? staffEspQuality(c) : staffExp(c))}</td><td>${fmtMoney(sal)}${extra > 0 ? ` <span class="helptext">(+${fmtMoney(extra)})</span>` : ""}</td><td>${c.contratoAte ? escapeHtml(seasonLabel(c.contratoAte)) : "—"}</td><td style="text-align:left;" class="helptext">${escapeHtml(staffEfeitoTexto(fn, team))}</td><td><button class="btn btn-ghost" data-staff-act="ficha" data-id="${c.id}">Ficha</button> <button class="btn btn-ghost" data-staff-act="hire" data-funcao="${fn}">Mudar</button></td></tr>`;
  }).join("");
  const pend = staffPropostas().filter(p => p.estado === "pendente");
  const props = pend.length ? `<div class="eyebrow" style="margin:16px 0 8px;">Propostas de staff (${pend.length})</div>` + pend.map(p => `<div class="fixture-row"><div>${escapeHtml(p.coach.nome)}</div><div class="vs">${STAFF_FUNCOES[p.tipo].label}</div><div>até ${fmtDateShort(p.expiraEm)} <button class="btn btn-ghost" data-staff-act="proposta" data-id="${p.id}">Ver</button></div></div>`).join("") : "";
  root.innerHTML = `
    <p class="helptext" style="margin:0 0 10px;">O salário base de cada função já está incluído na estrutura do clube. Só o que exceder o salário base do escalão (${fmtMoney(staffBaseline(team, "adjunto"))} para o adjunto) é debitado todos os meses. Os efeitos medem-se contra o que se espera de um clube da tua reputação: staff normal = neutro, melhor = vantagem, lugar vazio = pequena penalização.</p>
    <div class="eyebrow" style="margin:6px 0 8px;">Custo extra mensal do staff: <b>${fmtMoney(extraTotal)}</b></div>
    <div style="overflow:auto;"><table class="pm-retro-stat-table" style="text-align:center;"><thead><tr><th style="text-align:left;">Função</th><th style="text-align:left;">Nome</th><th>Idade</th><th>Nível</th><th>Salário/mês</th><th>Contrato</th><th style="text-align:left;">Efeito</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
    ${staffSugestoesHtml(team)}
    ${props}`;
  const gb = document.getElementById("staffVerGestorBtn");
  if(gb) gb.addEventListener("click", () => openTreinadorModal("gestor", state.userTeamId));
}


// ============================= Fase 2b (0.4.28): contratos, cobiça e adjunto =============================
// Contratos: só o staff do utilizador tem prazo. Fim de contrato → proposta de renovação no defeso (decide o
// utilizador; sem decisão, a pessoa sai). Cobiça: um clube de reputação igual ou superior tenta contratar um
// elemento acima do esperado — o utilizador escolhe reter (aumento) ou deixar sair; sem decisão, sai.
// Adjunto: a competência do adjunto afecta os avisos de rotação, a certeza dos veredictos das experiências
// e a qualidade das sugestões de contratação.
var STAFF_COBICA_DIAS = 10;
function staffContratoNovo(){ return (state.inDefeso ? state.season + 2 : state.season + 1); }
function staffRelCoach(c, team, fn){
  const t = staffDonoDoStaff(team);
  return clamp(staffExp(c) - ((t.reputacao || 50) / 5 - (fn === "adjunto" ? 2 : 4)), -6, 8);
}
function staffRelSlot(team, fn){
  if(STAFF_FUNCOES[fn].esp) return staffRel(team, fn);
  const t = staffDonoDoStaff(team), c = t && t[STAFF_FUNCOES[fn].slot];
  return c ? staffRelCoach(c, t, fn) : -4;
}
function staffContratosBackfill(team){
  Object.keys(STAFF_FUNCOES).forEach(fn => {
    const c = team[STAFF_FUNCOES[fn].slot];
    if(c && c.contratoAte == null) c.contratoAte = state.season + seededRnd(makeSeededRng(`staff-ct:${c.id}`), 0, 1);
  });
}
function staffNomeFn(fn){ return STAFF_FUNCOES[fn].label.toLowerCase(); }
function staffSaidaFimContrato(p){
  const team = state.teams[p.clubId], c = p.coach, fn = p.tipo;
  if(!team || team[STAFF_FUNCOES[fn].slot] !== c) return;
  staffLimparSlot(team, fn, "fim-contrato");
  team.staffVagas = team.staffVagas || {}; team.staffVagas[fn] = true;
  c.contratoAte = null; staffAddToPool(c);
  pushNews(state.currentDate, `${escapeHtml(c.nome)} deixou o cargo de ${staffNomeFn(fn)} do ${teamLinkHtml(team.id)}: o contrato terminou.`, "staff", "Staff: saída", { teamId: team.id });
}
function staffSaidaParaRival(p){
  const team = state.teams[p.clubId], c = p.coach, fn = p.tipo, rival = state.teams[p.rivalId];
  if(!team || team[STAFF_FUNCOES[fn].slot] !== c) return;
  staffLimparSlot(team, fn, "cobicado");
  team.staffVagas = team.staffVagas || {}; team.staffVagas[fn] = true;
  if(rival && !rival.equipaPrincipalId){
    const antigo = staffLimparSlot(rival, fn, "substituido");
    if(antigo) staffAddToPool(antigo);
    staffInstalar(rival, fn, c);
    pushNews(state.currentDate, `${escapeHtml(c.nome)} deixou o ${teamLinkHtml(team.id)} e é o novo ${staffNomeFn(fn)} do ${teamLinkHtml(rival.id)}.`, "staff", "Staff: saída", { teamId: team.id });
  } else { staffAddToPool(c); }
}
function staffResponderContinuidade(p, aceitar){
  const team = state.teams[p.clubId], c = p.coach, fn = p.tipo;
  if(!team || team[STAFF_FUNCOES[fn].slot] !== c){ p.estado = "expirada"; return { ok: false, reason: "Este elemento já não está no staff." }; }
  if(aceitar){
    c.salario = p.salarioNovo;
    c.contratoAte = p.motivo === "renovacao" ? state.season + 2 : staffContratoNovo();
    if(p.motivo === "cobica") c.protegidoAte = state.season + 1;
    p.estado = "aceite";
    pushNews(state.currentDate, p.motivo === "renovacao"
      ? `${escapeHtml(c.nome)} renovou como ${staffNomeFn(fn)} até ${seasonLabel(c.contratoAte)}.`
      : `${escapeHtml(c.nome)} ficou no ${teamLinkHtml(team.id)} como ${staffNomeFn(fn)}, com novo contrato até ${seasonLabel(c.contratoAte)}.`, "staff", "Staff: renovação", { teamId: team.id });
  } else {
    p.estado = "recusada";
    if(p.motivo === "renovacao") staffSaidaFimContrato(p); else staffSaidaParaRival(p);
  }
  return { ok: true };
}
function staffCriarRenovacoes(){
  const team = state.teams[state.userTeamId];
  if(!team || team.equipaPrincipalId || !academyEligible(team)) return;
  staffContratosBackfill(team);
  const d = new Date(state.currentDate || new Date());
  Object.keys(STAFF_FUNCOES).forEach(fn => {
    const c = team[STAFF_FUNCOES[fn].slot];
    if(!c || c.contratoAte == null || c.contratoAte > state.season) return;
    if(staffPropostas().some(p => p.estado === "pendente" && p.coach === c)) return;
    const sal = c.salario != null ? c.salario : staffSalario(c, fn, team);
    const rel = staffRelSlot(team, fn);
    const novo = Math.round(sal * (1.04 + Math.max(0, rel) * 0.012) / 10) * 10;
    const id = `sr:${c.id}:${state.season}`;
    staffPropostas().unshift({ id, tipo: fn, motivo: "renovacao", clubId: team.id, criada: isoDate(d), expiraEm: isoDate(addDays(d, STAFF_PROPOSTA_DIAS)), estado: "pendente", coach: c, salarioNovo: novo });
    pushNews(d, `O contrato de ${escapeHtml(c.nome)}, ${staffNomeFn(fn)}, termina esta época. Propõe renovar por duas épocas com ${fmtMoney(novo)}/mês. Tens até ${fmtDateShort(isoDate(addDays(d, STAFF_PROPOSTA_DIAS)))} para decidir. <button class="news-open-staff" data-staff-act="proposta" data-id="${id}">Ver proposta →</button>`,
      "staff", "Staff: fim de contrato", { teamId: team.id, autoAdvanceStop: true });
  });
  if(staffPropostas().length > 30) staffPropostas().length = 30;
}
function staffCobicaCriar(team, fn, rivalId, d){
  const c = team[STAFF_FUNCOES[fn].slot];
  if(!c) return null;
  const sal = c.salario != null ? c.salario : staffSalario(c, fn, team);
  const novo = Math.round(sal * 1.25 / 10) * 10;
  const id = `sc:${c.id}:${isoDate(d)}`;
  const p = { id, tipo: fn, motivo: "cobica", clubId: team.id, rivalId, criada: isoDate(d), expiraEm: isoDate(addDays(d, STAFF_COBICA_DIAS)), estado: "pendente", coach: c, salarioNovo: novo };
  staffPropostas().unshift(p);
  if(staffPropostas().length > 30) staffPropostas().length = 30;
  pushNews(d, `O ${teamLinkHtml(rivalId)} quer contratar ${escapeHtml(c.nome)}, o teu ${staffNomeFn(fn)}. Podes retê-lo com ${fmtMoney(novo)}/mês e novo contrato, ou deixá-lo sair. Tens até ${fmtDateShort(p.expiraEm)}. <button class="news-open-staff" data-staff-act="proposta" data-id="${id}">Decidir →</button>`,
    "staff", "Staff: cobiça de outro clube", { teamId: team.id, autoAdvanceStop: true });
  return p;
}
function staffCobicaMensal(team, d){
  if(staffPropostas().some(p => p.estado === "pendente" && p.motivo === "cobica")) return;
  const rng = makeSeededRng(`staff-cobica:${team.id}:${d.getFullYear()}-${d.getMonth()}`);
  const rivais = Object.values(state.teams).filter(t => t.id !== team.id && !t.equipaPrincipalId && !t.nuvemEuropeia && !t.selecaoNacional && academyEligible(t) && (t.reputacao || 0) >= (team.reputacao || 0) - 3);
  if(!rivais.length) return;
  const cands = [];
  Object.keys(STAFF_FUNCOES).forEach(fn => {
    const c = team[STAFF_FUNCOES[fn].slot];
    if(!c) return;
    if(c.protegidoAte != null && c.protegidoAte >= state.season) return;
    if(c.contratadoEm && (d - new Date(c.contratadoEm)) / 864e5 < 120) return;
    const rel = staffRelSlot(team, fn);
    if(rel < 1) return;
    cands.push({ fn, rel });
  });
  for(const x of cands){
    const prob = clamp(0.02 + 0.012 * x.rel, 0, 0.10);
    if(seededRndFloat(rng, 0, 1) < prob){
      const rival = rivais[seededRnd(rng, 0, rivais.length - 1)];
      staffCobicaCriar(team, x.fn, rival.id, d);
      return;
    }
  }
}
function openStaffContinuidadeModal(p){
  const team = state.teams[p.clubId], c = p.coach, f = STAFF_FUNCOES[p.tipo];
  const sal = c.salario != null ? c.salario : staffSalario(c, p.tipo, team);
  const kv = (k, v) => `<div class="nm-kv"><span>${k}</span><b>${v}</b></div>`;
  const cobica = p.motivo === "cobica";
  const q = f.esp ? Math.round(staffEspQuality(c)) : Math.round(staffExp(c));
  const root = staffOverlay(`
    <div class="nm-head"><h3>${cobica ? "📣 Cobiça de outro clube" : "📝 Fim de contrato"}</h3><p>${cobica ? `O ${escapeHtml(state.teams[p.rivalId] ? state.teams[p.rivalId].name : "clube rival")} quer contratar ${escapeHtml(c.nome)}.` : `O contrato de ${escapeHtml(c.nome)} termina esta época.`}</p></div>
    <div class="nm-box">
      ${kv("Função", f.label)}
      ${kv("Nível", String(q))}
      ${kv("Efeito atual", escapeHtml(staffEfeitoTexto(p.tipo, team)) || "—")}
      ${kv("Salário atual", `${fmtMoney(sal)}/mês`)}
      ${kv(cobica ? "Para o reter" : "Renovação", `${fmtMoney(p.salarioNovo)}/mês · ${cobica ? "novo contrato" : "duas épocas"}`)}
      ${kv("Decides até", fmtDateShort(p.expiraEm))}
      <p class="helptext" style="margin-top:8px;">${cobica ? "Se o deixares sair ou não decidires até à data, o lugar fica vago até contratares outro elemento." : "Se não renovares ou não decidires até à data, sai e o lugar fica vago até contratares outro elemento."}</p>
      <div class="nm-err" id="staffErr"></div>
    </div>
    <div class="nm-foot"><button class="nm-btn" data-staff-do="later">Decidir mais tarde</button><button class="nm-btn" data-staff-do="recusar">${cobica ? "Deixar sair" : "Não renovar"}</button><button class="nm-btn p" data-staff-do="aceitar">${cobica ? "Reter" : "Renovar"}</button><button class="nm-btn" data-staff-act="ficha" data-id="${c.id}">Ficha</button></div>`);
  root.addEventListener("click", ev => {
    const b = ev.target.closest("[data-staff-do]");
    if(!b) return;
    const act = b.getAttribute("data-staff-do");
    if(act === "later"){ root.remove(); return; }
    const r = staffResponderProposta(p.id, act === "aceitar");
    if(!r.ok){ const er = document.getElementById("staffErr"); if(er) er.textContent = r.reason || "Erro."; return; }
    root.remove(); staffRefresh();
  });
}

// ---------- adjunto ----------
function staffAdjRel(team){
  const t = staffDonoDoStaff(team);
  if(!t) return 0;
  return staffRelSlot(t, "adjunto");
}
// A partir de que carga o adjunto sugere rotação (65 por defeito; adjunto melhor avisa mais cedo).
function staffAdjCargaMin(team){ return clamp(65 - staffAdjRel(team) * 1.0, 58, 71); }
// Ruído (determinístico, por chave) nos juízos do adjunto: quase nulo num adjunto muito bom, grande num mau.
function staffAdjRuido(team, chave){
  const amp = clamp(1.6 - staffAdjRel(team) * 0.2, 0.2, 2.8);
  return seededRndFloat(makeSeededRng(`adjruido:${team.id}:${chave}`), -amp, amp);
}
function staffSugestoes(team){
  const out = [];
  const rng = makeSeededRng(`staff-sug:${team.id}:${state.season}:${new Date(state.currentDate || Date.now()).getMonth()}`);
  const adjRel = staffAdjRel(team);
  Object.keys(STAFF_FUNCOES).forEach(fn => {
    const atual = team[STAFF_FUNCOES[fn].slot];
    const rel = staffRelSlot(team, fn);
    if(atual && rel > -1.5) return;
    if(fn === "adjunto" && !atual) { /* o adjunto também sugere o seu próprio substituto */ }
    const f = STAFF_FUNCOES[fn];
    const q = c => f.esp ? staffEspQuality(c) : staffExp(c);
    const lista = staffCandidatos(fn).filter(c => staffAceita(c, team, fn).ok && (!atual || q(c) >= q(atual) + 1.5)).sort((a, b) => q(b) - q(a));
    if(!lista.length) return;
    // adjunto fraco falha a melhor escolha de vez em quando
    let i = 0;
    if(adjRel < 0 && lista.length > 1 && seededRndFloat(rng, 0, 1) < Math.min(0.6, -adjRel * 0.12)) i = 1;
    out.push({ fn, c: lista[i], atual });
  });
  return out;
}
function staffSugestoesHtml(team){
  const s = staffSugestoes(team);
  if(!s.length) return "";
  return `<div class="eyebrow" style="margin:16px 0 8px;">Sugestões do adjunto</div>` + s.map(x => {
    const f = STAFF_FUNCOES[x.fn];
    const nivel = f.esp ? Math.round(staffEspQuality(x.c)) : Math.round(staffExp(x.c));
    const quem = x.atual ? `${escapeHtml(f.label)}: trocar ${escapeHtml(x.atual.nome)} por <b>${escapeHtml(x.c.nome)}</b> (nível ${nivel})` : `${escapeHtml(f.label)}: lugar vago — sugiro <b>${escapeHtml(x.c.nome)}</b> (nível ${nivel})`;
    return `<div class="fixture-row"><div>${quem}</div><div class="vs"></div><div><button class="btn btn-ghost" data-staff-act="ficha" data-id="${x.c.id}">Ficha</button> <button class="btn btn-ghost" data-staff-act="hire" data-funcao="${x.fn}">Ver candidatos</button></div></div>`;
  }).join("");
}
function staffSugestaoMensal(team, d){
  const s = staffSugestoes(team);
  if(!s.length) return;
  const iso = isoDate(d);
  if(team.staffUltimaSugestao && (d - new Date(team.staffUltimaSugestao)) / 864e5 < 60) return;
  team.staffUltimaSugestao = iso;
  const linhas = s.map(x => `${STAFF_FUNCOES[x.fn].label}: ${escapeHtml(x.c.nome)}`).join("; ");
  pushNews(d, `Sugestão do adjunto: ${linhas}. Vê o separador <b>Staff</b>.`, "staff", "Sugestão do adjunto", { teamId: team.id });
}
