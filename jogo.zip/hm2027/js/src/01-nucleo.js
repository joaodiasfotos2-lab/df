  // ============================= 01-nucleo.js =============================
  // Núcleo: cabeçalho da IIFE, constantes e clubes reais
(function(){
  "use strict";

  // =================================================================
  // Constants & real clubs
  // =================================================================
  const CLUB_DEFS = window.HM2027_DATABASE.clubs;;
  // Correção: as cores mostradas na classificação, na ficha do clube e no cabeçalho do próprio
  // clube vinham de "team.color", uma cópia gravada no save no momento da criação da carreira —
  // quando a base de dados corrigia a cor oficial de um clube (ex.: HC Liceo) num lançamento
  // posterior, essa correção nunca chegava às carreiras já em curso, porque nada voltava a ler
  // de CLUB_DEFS depois do arranque. clubDisplayColor trata a base de dados atual (CLUB_DEFS)
  // como fonte de verdade e só recorre a "team.color" como recurso, para clubes sem definição.
  function clubDisplayColor(team){
    if(!team) return "#666";
    const def = CLUB_DEFS.find(d=>d.id===team.id);
    return (def && (def.primaryColor||def.color)) || team.color || "#164fb8";
  }
  // Cor do texto sobre o fundo do clube — por omissão, contraste automático preto/branco
  // (contrastText, 06-motor-jogo.js). Pedido do utilizador, 2026-09-26, sobre o AD Oeiras: "tem
  // de ser branco e letras encarnadas" — um fundo branco dava, por contraste automático, texto
  // preto, não o encarnado pedido. def.textColor é um campo opcional da base de dados só para
  // estes casos, e só substitui o contraste automático quando o fundo mostrado é exatamente a
  // cor principal do clube (o caso "normal") — se a cor efetiva recuou para a secundária/
  // terciária por colisão com o adversário (ver effectiveHomeColor), mantém-se sempre o
  // contraste automático, para nunca arriscar fundo=texto.
  function clubTextColor(team, bg){
    const color = bg || clubDisplayColor(team);
    const def = team && CLUB_DEFS.find(d=>d.id===team.id);
    const primaryOfDef = def && (def.primaryColor||def.color);
    if(def && def.textColor && color && primaryOfDef && String(color).toLowerCase()===String(primaryOfDef).toLowerCase()){
      return def.textColor;
    }
    return contrastText(color);
  }
  // Reskin visual (Fase 1) — badge de iniciais para clubes sem escudo em imagem (praticamente
  // todos: só o Sporting teve um PNG usado nos mockups, que nunca chegou a este repositório).
  // Em vez de manter uma lista de excepções por clube, gera sempre 3 letras a partir do nome:
  // a palavra mais longa do nome é normalmente a identificadora ("Sporting" em "Sporting CP",
  // "Benfica" em "SL Benfica", "Oliveirense" em "UD Oliveirense" — mesmo critério já usado à mão
  // no mockup da Partida). Usar sempre com contrastText(clubDisplayColor(team)) para a cor do
  // texto, nunca uma cor fixa.
  function clubBadgeInitials(name){
    if(!name) return "?";
    const words = String(name).replace(/["“”]/g,"").trim().split(/\s+/).filter(Boolean);
    if(!words.length) return "?";
    let longest = words[0];
    for(const w of words){ if(w.length>longest.length) longest = w; }
    return longest.slice(0,3).toUpperCase();
  }
  // Escudos reais (pedido do utilizador, 2026-09-25: "incluir", com 14 imagens anexadas) —
  // os 14 clubes do Campeonato Placard (a divisão de topo, onde a carreira do utilizador
  // decorre sempre) ganham o escudo real em vez da badge de iniciais+cor. Ficheiros PNG com
  // fundo transparente em img/badges/<id>.png. Mapeamento confirmado por eliminação: 11 das 14
  // imagens tinham o nome do clube ou as suas iniciais legíveis (OCB=Barcelos, JP=Pacense,
  // AJV=Viana, HC Braga, FCP=Porto, ADS=Sanjoanense [fundado 1924], OEIRAS, SLB=Benfica,
  // UDO=Oliveirense, SCP=Sporting, "Riba D'Ave HC"); as 3 restantes foram identificadas pelos
  // únicos 3 clubes do Placard ainda sem imagem — Tomar, Valongo, Candelária — cruzado com a
  // heráldica de cada escudo: cruz vermelha de Tomé (Ordem de Cristo) → Tomar; "CSC" → Candelária
  // SC; o terceiro (Discóbolo) → Valongo, por eliminação.
  //
  // Alargado (pedido do utilizador, 2026-10-04: "incluir", com 14 imagens anexadas) aos 14
  // clubes da OK Liga (Espanha) — a divisão estrangeira completa, tal como o Placard já tinha
  // cobertura total. Mapeamento confirmado por eliminação: 13 das 14 imagens tinham o nome do
  // clube ou as suas iniciais legíveis (I.H.C.=Igualada HC, CPV=CP Voltregà, "P.V." com castelo
  // nas armas de Vilafranca do Penedès=CP Vilafranca, CP Calafell, Hockey Lloret=CH Lloret, CH
  // Caldes, CE Noia, FCB=FC Barcelona, Lleida=CE Lleida, SHUM=SHUM Maçanet, Rivas Las Lagunas=CP
  // Rivas, Reus Deportiu, PAS=PAS Alcoi); a única restante — uma silhueta preta abstrata de um
  // jogador — coube ao único clube da OK Liga ainda sem imagem, HC Liceo, por eliminação (mesmo
  // método já usado para os 3 clubes do Placard sem nome legível). Os restantes ~97 clubes (2ª/3ª
  // Divisão portuguesa, Serie A1) continuam com a badge de iniciais — não há imagens oficiais
  // disponíveis para todos, e uma mistura de escudo real + badge genérica na mesma lista/tabela
  // ficaria inconsistente, por isso os escudos reais só se usam nos 3 sítios onde se destaca a
  // identidade de UM clube de cada vez (escolha de clube, cabeçalho do teu clube, Ficha do
  // Clube) — nunca em listas/tabelas com vários clubes lado a lado (classificações, plantéis).
  const CLUB_CREST_IDS = new Set([
    "barcelos","pacense","viana","braga","porto","candelaria","valongo","sanjoanense","oeiras","benfica","oliveirense","sporting","tomar","ribadave",
    "igualada-hc","hc-liceo","cp-voltrega","cp-vilafranca","cp-calafell","ch-lloret","ch-caldes","ce-noia","fc-barcelona","ce-lleida","shum-macanet","cp-rivas","reus-deportiu","pas-alcoi",
    // Versão 0.2 (2026-10-22): 18 logótipos novos da 2.ª Divisão portuguesa. Os 5 que eram de
    // clubes do Placard (UDO, OCB, FC Porto, Discóbolo/Valongo, Sporting) foram atribuídos às
    // respetivas equipas B, que não tinham escudo (os principais já o tinham); as B do Benfica e
    // das 4 equipas espanholas (Barcelona, Reus, Igualada, Noia) usam o escudo do clube principal.
    // TOC → Termas OC (sigla); FAC → Famalicense; CHC → Carvalhos; AJS → Salesiana; SCM → Marinhense.
    // Académica e Espinho têm o desenho preto sobre transparente — levam um fundo branco no próprio PNG.
    "ud-oliveirense-b","oc-barcelos-b","fc-porto-b","ad-valongo-b","sporting-cp-b","sl-benfica-b",
    "fc-barcelona-b","reus-deportiu-b","igualada-hc-b","ce-noia-b",
    "termas-oc","hc-mealhada","ha-cambra","famalicense-ac","crpf-lavra","ch-carvalhos","cd-povoa","adj-vila-praia",
    "ass-academica-coimbra","ass-academica-espinho","sc-marinhense","parede-fc","aj-salesiana",
    // Mais 10 (2026-10-22): HCT → Turquel; HCPG → Grândola; Murches GRF; CRIAR-T; CD PA → Paço de Arcos;
    // SAB → Sp. Alenquer e Benfica; Alcobacense; AEFD → AE Física D (Torres Vedras). O escudo "Atlético"
    // com T foi atribuído ao APAC Tojal por eliminação. O novo escudo do Benfica (3 estrelas) substitui o
    // anterior no Benfica e na respetiva equipa B.
    "hc-turquel","hcp-grandola","grf-murches","gd-criar-t","cd-paco-de-arcos","apac-tojal","sp-alenquer-e-benfica","a-alcobacense-cd","ae-fisica-d",
    // 3.ª Divisão (2026-10-22): HCVG → HC Vasco da Gama (Sines); HC 5 castelo → HC Sintra; HCS → Santiago; PDL → Ponta Delgada;
    // escudo coroado com torre/ondas/cruz → GDS Cascais (assumido); Sesimbra; Boliqueime; UDV → Vilafranquense; SHCM → A Stuart Massamá;
    // Corujas; JA → J. Azeitonense. PDL, UDV e SHCM levam fundo branco (desenho escuro sobre transparente).
    "hc-vasco-da-gama-j-ascencao","hc-sintra-planta-livre","hc-santiago","hc-ponta-delgada","gds-cascais","gd-sesimbra","cd-boliqueime","ud-vilafranquense","a-stuart-hc-massama","gcc-os-corujas","j-azeitonense",
    // Mais 10 da 3.ª Divisão: ACR Santa Cita; UTE → UF Entroncamento; SC Torres; JO → Juventude Ouriense; Os Tigres (Almeirim);
    // HC Madeira; GDE → GD Estreito; Biblioteca IR (Valado dos Frades); Os Águias (Memória); OH Sports.
    // UTE, Juventude Ouriense e HC Madeira levam fundo branco no PNG.
    "acr-santa-cita","uf-entroncamento-entrosegur","sc-torres","juventude-ouriense","hc-os-tigres-work-permit","hc-madeira","gd-estreito","biblioteca-ir","crc-os-aguias","oh-sports",
    // Mais 11 da 3.ª Divisão: AD Barcelos (Campo); AFC → Académico FC; V → VizelaSkating (fundo branco no PNG); Valença; USC Paredes;
    // Penafiel; Marco; Maia; Fão; Fânzeres; CART → CAR Taipense.
    "ad-barcelos","academico-fc","vizelaskating","valenca-hc","usc-paredes","hc-penafiel","hc-marco","hc-maia","hc-fao","gdc-fanzeres","car-taipense",
    // Últimos 10 da 3.ª Divisão: CAF → CA Feira; "e" laranja → ACDCP Vila Boa Bispo (por eliminação); ACD Gulpilhares; ACRPV;
    // CIS → CI Sagres; HCPR → Paço de Rei; Escola Livre de Azeméis; Casa do Povo de Sobreira; CENAP; bola com "CD" → CD Cucujães.
    // Gulpilhares e Paço de Rei levam fundo branco no PNG.
    "ca-feira","acdcp-vila-boa-bispo","acd-gulpilhares","acr-pessegueiro-vouga","ci-sagres","hc-paco-de-rei","escola-livre-a","cp-sobreira","cenap","cd-cucujaes",
    // Equipas B da 3.ª Divisão: o mesmo escudo do clube principal.
    "riba-dave-hc-b","hc-braga-b","j-pacense-b","ad-sanjoanense-b","ch-carvalhos-b","aa-espinho-b","ha-cambra-b","a-academica-c-b","hc-turquel-b","hc-mealhada-b","s-alenquer-b-b","ae-fisica-d-b","cd-paco-de-arcos-b",
  ]);
  function clubCrestUrl(clubId){
    return clubId && CLUB_CREST_IDS.has(clubId) ? `img/badges/${clubId}.png` : null;
  }
  // Miniatura junto ao nome do clube no cartão "Próximo jogo" do Resumo (pedido do utilizador,
  // 2026-09-26: "por o logotipos aqui", apontando exatamente para este cartão) — mesmo padrão do
  // badge já usado na Ficha do Clube (fichaBadgeHtml, 05-ui-navegacao.js): escudo real quando
  // existe, senão uma amostra da cor do clube.
  function clubMiniBadgeHtml(teamId){
    const team = state.teams && state.teams[teamId];
    if(!team) return "";
    const crestUrl = clubCrestUrl(teamId);
    return crestUrl
      ? `<span class="dot has-crest" style="width:24px;height:24px;display:inline-block;vertical-align:middle;margin-right:6px;"><img src="${crestUrl}" alt="" class="crest-img"></span>`
      : `<span class="swatch" style="width:13px;height:13px;border-radius:3px;background:${clubDisplayColor(team)};display:inline-block;margin-right:6px;vertical-align:middle;"></span>`;
  }
  // Logótipos de competição (pedido do utilizador, 2026-09-25: enviou o logo real do Campeonato
  // Placard, "tem de aparecer na competição" e "nas partidas que forem placard"). Mesmo padrão de
  // CLUB_CREST_IDS/clubCrestUrl acima, mas por competição.
  //
  // Alargado (pedido do utilizador, 2026-10-02: "símbolos das federações... da liga dos campeões
  // e de outras ligas") às restantes competições e às Seleções Nacionais (Mundial/Europeu).
  // Numa primeira fase foram criados emblemas SVG originais (não cópias de logótipos reais) para
  // todos estes ids. Nesse mesmo dia o utilizador enviou os ficheiros PNG reais de 7 deles (OK
  // Liga, Serie A1, Supertaça, Elite Cup, WSE Champions League, WSE Cup, WSE Trophy) mais o da FPP
  // — substituíram os SVGs originais correspondentes (ver COMPETITION_LOGO_EXT abaixo). Ficam como
  // emblema original (SVG) apenas a Taça de Portugal e o Mundial/Europeu de Seleções, por não
  // terem sido fornecidos ficheiros reais para esses.
  //
  // Correção embutida na criação deste mapeamento: o mapeamento antigo guardava os ids COM sufixo
  // de época ("placard-2026-27") no próprio Set, e só tratava esse um caso como especial (->
  // "placard.png"). Isso tinha um bug adormecido, nunca notado por o Placard ser até agora o único
  // caso: assim que a época muda, o id de qualquer competição com sufixo de ano muda com ela (ex.
  // "ok-liga-2026-27" -> "ok-liga-2027-28" na época seguinte) e deixaria de bater certo com o Set,
  // "perdendo" o logótipo todos os anos. Agora o Set guarda só a base SEM sufixo de ano
  // (competitionLogoFileBase remove sempre "-AAAA-AA" antes de verificar/montar o caminho), por
  // isso o logótipo de uma competição anual nunca depende do ano actual.
  const COMPETITION_LOGO_BASE_IDS = new Set([
    "placard", "ok-liga", "serie-a1",
    "supertaca", "taca-portugal", "elite-cup",
    "europa-champions", "europa-cup", "europa-trophy",
    "selecoes-mundial", "selecoes-europeu", "selecoes-mundial-s19", "selecoes-europeu-s19",
  ]);
  // Ficheiros reais (fornecidos pelo utilizador) são PNG; os que ainda não têm ficheiro real
  // continuam como o emblema SVG original (ext por omissão, ver competitionLogoUrl). Os 3 emblemas
  // WSE (brancos no original) foram compostos sobre um fundo azul-marinho arredondado antes de
  // gravados, para se manterem legíveis sobre o fundo claro da vista de competição.
  const COMPETITION_LOGO_EXT = {
    "placard": "png", "ok-liga": "png", "serie-a1": "png", "supertaca": "png",
    "elite-cup": "png", "europa-champions": "png", "europa-cup": "png", "europa-trophy": "png",
  };
  function competitionLogoFileBase(competitionId){
    return String(competitionId).replace(/-\d{4}-\d{2}$/, "");
  }
  function competitionLogoUrl(competitionId){
    if(!competitionId) return null;
    const base = competitionLogoFileBase(competitionId);
    if(!COMPETITION_LOGO_BASE_IDS.has(base)) return null;
    const ext = COMPETITION_LOGO_EXT[base] || "svg";
    return `img/competitions/${base}.${ext}`;
  }
  // Emblemas das federações (distintos de uma competição concreta — ex. a FPP não é "uma prova",
  // é quem tutela a Seleção). Por agora só a FPP (a única relevante dentro do âmbito pedido),
  // mostrado junto da Seleção de Portugal (openSelecaoModal, 05-ui-navegacao.js). Ficheiro real
  // (fornecido pelo utilizador, 2026-10-02): branco sobre transparente, por isso só é usado em
  // fundos escuros (o modal retro da Seleção, #0A1E4D) — nunca sobre fundo claro.
  const FEDERATION_LOGO_IDS = new Set(["fpp"]);
  const FEDERATION_LOGO_EXT = { "fpp": "png" };
  function federationLogoUrl(federationId){
    if(!federationId || !FEDERATION_LOGO_IDS.has(federationId)) return null;
    const ext = FEDERATION_LOGO_EXT[federationId] || "svg";
    return `img/federacoes/${federationId}.${ext}`;
  }
  // Equipas B (secundárias) dos 6 clubes que as têm — usado em vários sítios (seleção de
  // clube, finanças, mercado) para lhes aplicar regras diferentes das de um clube normal.
  // Correção: B_TEAM_IDS era uma lista fixa com só os 6 clubes originais — passou a verificar a
  // ligação de dados diretamente (equipaPrincipalId), para funcionar automaticamente com
  // qualquer equipa B ligada formalmente a um clube principal, sem precisar de manter duas
  // listas em sincronia.
  const B_TEAM_IDS = ["fc-porto-b","ad-valongo-b","oc-barcelos-b","ud-oliveirense-b","sporting-cp-b","sl-benfica-b"];
  function isBTeamId(id){ return !!(state.teams && state.teams[id] && state.teams[id].equipaPrincipalId); }
  // Equipas B "por nome": os 6 clubes originais (equipaPrincipalId, com finanças partilhadas e
  // as restantes regras completas) têm uma equipa principal formalmente ligada — mas há muitas
  // outras equipas B reais (sobretudo na 3ª Divisão, mas também nalgumas da 2ª) sem essa ligação
  // modelada, porque a equipa principal delas nem sequer faz parte deste jogo. Para essas, só se
  // aplica a regra pedida — não pedem jogadores emprestados nem compram — detetada pelo nome
  // real do clube (termina em "B", com ou sem aspas). Continuam a poder ser fonte de
  // empréstimo/compra para outros clubes, tal como as equipas B originais.
  function looksLikeReserveTeamName(name){
    const cleaned = String(name||"").replace(/["\u201c\u201d\u2018\u2019]/g,"").trim();
    const words = cleaned.split(/\s+/);
    return words[words.length-1]==="B";
  }
  // Correção (verificação pedida pelo utilizador: "a IA nem o utilizador podem comprar jogadores
  // da nuvem"): os clubes da "nuvem europeia" (França/Alemanha/Suíça/Inglaterra/Áustria,
  // ensureEuropaNuvemClubes em 07g-europa.js) são explicitamente definidos para nunca evoluir e
  // nunca entrar no mercado de transferências. Esta função já era o filtro central usado por
  // quase toda a lógica de mercado da IA (ofertas da IA ao utilizador, mercado IA-a-IA, upgrades
  // de agentes livres, recuperação de inativos) — bastava não incluir os clubes da nuvem para que
  // todos esses sistemas os tratassem como participantes normais do mercado.
  // Correção (bug reportado pelo utilizador, 2026-09-27: "comecei um jogo e a selecção de itália
  // contratou um jogador por empréstimo. as seleções não são clubes") — desde a revelação diária
  // das Seleções (07h-selecoes.js), as equipas virtuais "selecaoNacional-*" persistem em
  // state.teams durante vários dias reais (a duração do torneio), em vez de existirem só dentro
  // de uma única chamada síncrona — o que as expôs, sem querer, a esta mesma lógica de mercado
  // IA-a-IA que já tratava a nuvem europeia como participante normal. Uma seleção nacional nunca
  // pode comprar, vender, emprestar nem pedir emprestado ninguém — é apenas um agrupamento
  // temporário de jogadores de outros clubes, nunca um clube real.
  function isMarketPassiveTeam(team){ return !!team.equipaPrincipalId || looksLikeReserveTeamName(team.name) || !!team.nuvemEuropeia || !!team.selecaoNacional; }
  const STRUCTURAL_MIN_GOALKEEPERS = 2;
  // Piso ABSOLUTO de jogadores de campo (só existe para nunca deixar um clube sem equipa mínima em
  // pista): NÃO é uma regra de negócio. Pedido do utilizador (2026-10-05, depois de este piso estar
  // a 9 e a bloquear compras: "não pode bloquear mesmo na IA, essa correção correu mal. Os clubes
  // têm é de ir ao mercado, equipas B. Podem é recusar propostas quando o plantel está muito
  // curto..."): a proteção contra plantéis a esvaziar passou a ser a decisão do próprio clube
  // vendedor (clubSaleRefusal, 04-financas.js — plantel muito curto, rival ao preço de mercado,
  // jogador imprescindível), e a reposição é feita pelo mercado/equipa B (aiSquadNeed: j<9).
  const STRUCTURAL_MIN_OUTFIELD = 4;
  // Abaixo deste nº de jogadores de campo (contando também a equipa B), o clube vendedor faz contas
  // antes de vender (clubCanReplaceSale): só aceita se tiver margem financeira/salarial para repor.
  const SQUAD_REPLACEMENT_CHECK_OUTFIELD = 9;
  // 0.4.18: resultado em cache (era recalculado a cada chamada — O(equipas²) — e dominava o tempo
  // da pré-época: ~28 s numa máquina lenta). A chave é (estado, equipa do utilizador, mapa de equipas);
  // as ligações principal/B só mudam em 07-playoff (extinção/recriação da B) e no carregamento,
  // que chamam invalidateUserControlledCache().
  var _ucCache={st:null,uid:null,teams:null,ids:null};
  var _loanIdx={st:null,date:null,list:null}; // 0.4.18: ver loanedPlayersIndex (04-financas.js)
  function invalidateUserControlledCache(){_ucCache.ids=null;}
  function userControlledTeamIds(){
    if(_ucCache.ids&&_ucCache.st===state&&_ucCache.uid===state.userTeamId&&_ucCache.teams===state.teams) return _ucCache.ids.slice();
    const r=userControlledTeamIdsCompute();
    _ucCache={st:state,uid:state.userTeamId,teams:state.teams,ids:r};
    return r.slice();
  }
  function userControlledTeamIdsCompute(){
    const ids=new Set(),teams=state.teams||{};
    const add=id=>{if(id&&teams[id])ids.add(id);}; add(state.userTeamId);
    let changed=true;
    while(changed){changed=false;Array.from(ids).forEach(id=>{const t=teams[id];if(!t)return;[t.equipaPrincipalId,t.equipaBId].forEach(link=>{const n=ids.size;add(link);if(ids.size!==n)changed=true;});Object.values(teams).forEach(o=>{if(o.equipaPrincipalId===id||o.equipaBId===id){const n=ids.size;add(o.id);if(ids.size!==n)changed=true;}});});}
    return Array.from(ids);
  }
  function isUserControlledTeam(teamOrId){const id=teamOrId&&typeof teamOrId==="object"?teamOrId.id:teamOrId;if(!id)return false;userControlledTeamIds();return _ucCache.ids.includes(id);}
  // Correção (pedido do utilizador): as transferências/empréstimos/contratações resolvidas
  // entre clubes de IA (runAiToAiMarketPass/tryFillAiSquadNeed, ver 04-financas.js) só geravam
  // uma única notícia agregada ("Mercado de verão entre clubes: N movimento(s) registados fora
  // do teu clube.") — nunca dizia quem contratou quem, nem sequer para clubes da própria
  // divisão do utilizador. Usado para decidir, negócio a negócio, se vale a pena gerar também
  // uma notícia individual (mesmo critério de relevância já usado para notícias de resultados
  // de outras competições, ver processCompetitionRoundFullyAI em 06-motor-jogo.js): pelo menos
  // um dos clubes envolvidos tem de pertencer à própria competição do utilizador nesta carreira.
  function marketDealRelevantToUser(...teams){
    const comp = state.competitions && state.competitions[state.userCompetitionId];
    if(!comp || !Array.isArray(comp.teamIds)) return false;
    return teams.some(t=>t && comp.teamIds.includes(t.id));
  }
  function realGoalkeeperCount(team){return team&&Array.isArray(team.players)?team.players.filter(p=>p.pos==="GR"&&!p.__provisional).length:0;}
  function canAutomaticallyMovePlayer(origin,destination,player){return !!(origin&&destination&&player)&&!isUserControlledTeam(origin)&&!isUserControlledTeam(destination)&&!(player.pos==="GR"&&realGoalkeeperCount(origin)<=STRUCTURAL_MIN_GOALKEEPERS);}

  const TREINO_RECOVERY_MULT = { "Excelentes":1.25, "Muito boas":1.12, "Boas":1.0, "Razoáveis":0.9 };
  // =================================================================
  // Sistema numérico de reputação dos clubes (especificação v1.2, 04/09/2026)
  // =================================================================
  // Decisão principal do documento: club.reputacao passa a guardar um inteiro 0-100 (escala
  // global, igual para todas as divisões e países) em vez de uma das quatro categorias antigas
  // ("Local"/"Nacional"/"Internacional"/"Classe Mundial"). As categorias deixam de ser o formato
  // canónico mas continuam a ser aceites na leitura (normalizeClubReputation), migradas de forma
  // idempotente. REPUTATION_POINTS guarda agora só os valores de conversão legada (secção 9 do
  // documento) — nunca mais representa um sistema em uso, só a ponte para saves antigos.
  const REPUTATION_POINTS = { "Local":55, "Nacional":70, "Internacional":85, "Classe Mundial":95 };
  // Valores explícitos propostos no documento (secções 6 e 15.4) para os 14 clubes do Placard e
  // os 28 da 2ª Divisão 2026/27 — sobrepõem-se sempre à conversão categórica legada, porque
  // corrigem precisamente a falta de granularidade que motivou a mudança (ex.: HC Braga, AD
  // Oeiras, Juventude de Viana, Riba d'Ave e Candelária eram todos "Local", a categoria mais
  // baixa, apesar de serem clubes competitivos do Placard — o novo valor numérico reflete-os
  // corretamente, mesmo ficando acima de alguns clubes antes "Nacional").
  const REPUTATION_EXPLICIT_OVERRIDES = {
    // Placard 2026/27 (secção 15.4)
    porto:97, benfica:96, sporting:96, barcelos:93, oliveirense:89, valongo:87, tomar:84,
    braga:81, sanjoanense:81, candelaria:80, viana:79, ribadave:77, pacense:75, oeiras:74,
    // 2ª Divisão 2026/27 · Zona Norte (secção 6)
    "cd-povoa":78, "ch-carvalhos":73, "ass-academica-coimbra":71, "ass-academica-espinho":69,
    "ha-cambra":67, "fc-porto-b":66, "famalicense-ac":65, "ud-oliveirense-b":64,
    "oc-barcelos-b":63, "ad-valongo-b":62, "termas-oc":62, "adj-vila-praia":60,
    "hc-mealhada":59, "crpf-lavra":58,
    // 2ª Divisão 2026/27 · Zona Sul (secção 6)
    "hc-turquel":79, "cd-paco-de-arcos":74, "parede-fc":72, "sp-alenquer-e-benfica":70,
    "sc-marinhense":70, "a-alcobacense-cd":66, "gd-criar-t":66, "sl-benfica-b":65,
    "ae-fisica-d":64, "aj-salesiana":63, "grf-murches":63, "sporting-cp-b":63,
    "hcp-grandola":60, "apac-tojal":58,
  };
  // 3ª Divisão: o documento não fornece tabela própria (só Placard e 2ª Divisão têm evidência
  // competitiva consolidada) — usa-se uma pequena variação determinística entre 40 e 50 (banda
  // "clube pequeno" da escala global, secção 3), decisão do utilizador, em vez de um único valor
  // fixo para os 55 clubes: cada clube fica sempre com o mesmo valor (mesma semente = mesmo
  // clube), mas os valores diferem ligeiramente entre si, tal como o resto do gerador
  // determinístico do jogo (ver hashStringToSeed/seededRnd, mais abaixo).
  // Correção (Serie A1, 2026-09-06): todos os clubes da OK Liga e da Serie A1 já têm reputação
  // explícita no database.json, por isso este ramo nunca chegou a ser exercitado por eles — mas
  // sem uma entrada própria, um clube estrangeiro sem reputação explícita cairia na banda 40-50
  // pensada para a 3ª Divisão portuguesa, claramente errado para uma 1ª divisão de outro país.
  // Escalado a partir do valor por omissão do Placard (70), na mesma proporção já usada em
  // reputacaoCompeticao/DIVISION_SALARY_PROFILE (OK Liga -15%, Serie A1 -15% sobre a OK Liga).
  function reputationDefaultForClub(club){
    const id = club && club.id;
    if(id!=null && REPUTATION_EXPLICIT_OVERRIDES[id]!=null) return REPUTATION_EXPLICIT_OVERRIDES[id];
    const divisao = club && (club.divisaoAtual || club.divisao);
    if(divisao==="placard") return 70;
    if(divisao==="ok-liga") return 60;
    if(divisao==="serie-a1") return 51;
    if(divisao==="2div") return 63;
    if(divisao==="ok-liga-plata") return 55;
    return seededRnd(hashStringToSeed(String(id||"clube")+"|reputacao-3div"), 40, 50);
  }
  // Ponto único de normalização (secção 4.2/9 do documento): aceita um número (novo formato,
  // devolvido tal e qual — idempotente, AC-03: chamar duas vezes com o mesmo número dá sempre o
  // mesmo número), ou qualquer outra coisa (uma das quatro categorias antigas, string vazia,
  // null/undefined) — nesse caso usa sempre reputationDefaultForClub, NUNCA a conversão genérica
  // categoria->pontos (REPUTATION_POINTS[value]). Isto é essencial, não cosmético: a migração de
  // um save antigo tem o clube guardado exatamente como a categoria antiga ("Local", etc.) — se
  // esta função convertesse diretamente para REPUTATION_POINTS["Local"]=55, os 42 valores
  // explícitos do documento (secções 6/15.4) e a variação aleatória 40-50 da 3ª Divisão
  // (decisão do utilizador) NUNCA chegariam a aplicar-se, porque a maioria dos clubes tinha
  // precisamente "Local" gravado. reputationDefaultForClub já sabe resolver isto pela ordem
  // certa: override explícito por id, senão a omissão por divisão.
  function normalizeClubReputation(value, club){
    if(value!=null){
      if(typeof value==="number" && Number.isFinite(value)) return clamp(Math.round(value), 0, 100);
      if(typeof value==="string" && value.trim()!==""){
        const n = Number(value);
        if(Number.isFinite(n)) return clamp(Math.round(n), 0, 100);
      }
    }
    return reputationDefaultForClub(club||{});
  }
  // Rótulo contextual da escala global (secção 3 do documento) — só para apresentação (ex.: "78
  // • Candidato ao título nacional"); nunca usado para decisões de código (essas usam sempre o
  // número diretamente, ou reputationLerp/reputationTierFinanceira abaixo).
  const REPUTATION_BAND_LABELS = [
    [95,"Elite mundial"], [90,"Potência europeia"], [85,"Grande nacional"],
    [80,"Candidato ao título nacional"], [75,"Candidato europeu / favorito à subida"],
    [70,"Clube forte"], [65,"Meio superior"], [60,"Meio da tabela"],
    [55,"Luta pela manutenção"], [0,"Clube pequeno ou de escalão inferior"],
  ];
  function reputationBandLabel(rep){
    const r = clamp(Math.round(Number(rep)||0), 0, 100);
    for(const [min,label] of REPUTATION_BAND_LABELS) if(r>=min) return label;
    return REPUTATION_BAND_LABELS[REPUTATION_BAND_LABELS.length-1][1];
  }
  // Correção (pedido do utilizador, ecrã de escolha de clube): reputationBandLabel usa uma
  // escala GLOBAL fixa, pensada para todas as divisões ao mesmo tempo — no Campeonato Placard
  // (divisão de topo, sem nenhuma divisão acima) isso produzia dois problemas reais: (1)
  // "favorito à subida" aparecia mesmo não havendo subida possível; (2) clubes abaixo do
  // patamar de "Grande nacional" (85) eram comparados com clubes de divisões muito mais fracas
  // (2ª/3ª Divisão) que também caem nessa mesma faixa da escala 0-100, em vez de serem
  // comparados com os outros 13 clubes do próprio Placard nesta carreira.
  // Os três patamares de topo (Elite mundial/Potência europeia/Grande nacional) mantêm-se pela
  // escala global — são clubes genuinamente desse nível, com ou sem contexto. Só os restantes
  // (abaixo de 85) são reclassificados relativamente aos outros clubes do Placard: melhores
  // ~15% "Candidato ao título nacional", ~30% seguintes "Candidato europeu", resto (a maioria)
  // "Luta pela manutenção" — nunca "favorito à subida". Sem faixa intermédia de "meio da
  // tabela": numa divisão de topo com poucos clubes verdadeiramente grandes, quem não é sério
  // candidato ao título nem à Europa está, de facto, envolvido na luta pela manutenção (pedido
  // do utilizador, depois de confirmar o resultado com um caso real de 14 clubes).
  // pool: lista [{id, rep}] de todos os clubes selecionáveis do Campeonato Placard nesta
  // carreira (resolvida pelo chamador, ver renderTeamSelect em 05-ui-navegacao.js).
  function placardContextualReputationLabel(clubId, pool){
    const entry = pool.find(x=>x.id===clubId);
    const rep = entry ? entry.rep : 0;
    if(rep>=95) return "Elite mundial";
    if(rep>=90) return "Potência europeia";
    if(rep>=85) return "Grande nacional";
    const rest = pool.filter(x=>x.rep<85).sort((a,b)=>b.rep-a.rep);
    const idx = rest.findIndex(x=>x.id===clubId);
    if(idx<0) return reputationBandLabel(rep); // salvaguarda: nunca devia acontecer
    const n = rest.length;
    const b1 = Math.max(1, Math.round(n*0.15));
    const b2 = b1 + Math.max(1, Math.round(n*0.30));
    if(idx<b1) return "Candidato ao título nacional";
    if(idx<b2) return "Candidato europeu";
    return "Luta pela manutenção";
  }
  // 0.2.8 (pedido do utilizador: "o Turquel aparece como candidato europeu mas está na segunda divisão"):
  // na 2.ª e 3.ª Divisões o rótulo da escala global ("Candidato europeu / favorito à subida") não faz
  // sentido — não há Europa e o que está em jogo é a subida. Passam a ser classificadas relativamente aos
  // outros clubes (não-B) da própria divisão: melhores ~15% "Favorito à subida", ~30% seguintes
  // "Candidato à subida", ~30% "Meio da tabela", resto "Luta pela manutenção".
  function lowerDivisionContextualReputationLabel(clubId, pool, div){
    const rest = pool.slice().sort((a,b)=>b.rep-a.rep);
    const idx = rest.findIndex(x=>x.id===clubId);
    if(idx<0) return "Meio da tabela";
    const n = rest.length;
    const b1 = Math.max(1, Math.round(n*0.15));
    const b2 = b1 + Math.max(1, Math.round(n*0.30));
    const b3 = b2 + Math.max(1, Math.round(n*0.30));
    if(idx<b1) return "Favorito à subida";
    if(idx<b2) return "Candidato à subida";
    if(idx<b3) return "Meio da tabela";
    // 0.2.12: na 3.ª Divisão não há descida — nunca "luta pela manutenção".
    return div==="3div" ? "Clube em construção" : "Luta pela manutenção";
  }
  // Rótulo de reputação de um clube em jogo, coerente com a sua divisão (Placard / 2.ª / 3.ª Divisão).
  function clubReputationLabel(team){
    if(!team) return "";
    const div = team.divisaoAtual;
    if(!["placard","2div","3div"].includes(div) || !state.teams) return reputationBandLabel(team.reputacao);
    const pool = Object.values(state.teams)
      .filter(t=>t.divisaoAtual===div && !t.equipaPrincipalId && !t.nuvemEuropeia)
      .map(t=>({ id:t.id, rep:Number(t.reputacao)||0 }));
    return div==="placard" ? placardContextualReputationLabel(team.id, pool) : lowerDivisionContextualReputationLabel(team.id, pool, div);
  }
  // Interpolação linear genérica entre pontos de ancoragem (reputação -> valor), sempre presa
  // (clamp) fora do intervalo definido. Substitui as antigas tabelas categóricas (4 valores
  // fixos, um "degrau" por categoria) por uma escala contínua, coerente com a granularidade que
  // é todo o objetivo deste documento — os 4 pontos de ancoragem mais usados no jogo coincidem
  // exatamente com os valores legados de REPUTATION_POINTS (55/70/85/95), pelo que qualquer
  // clube que ainda não tenha uma reputação explícita (2ª/3ª Divisão sem tabela, ou uma
  // categoria antiga migrada tal e qual) obtém sempre o mesmo valor de sempre — só os clubes com
  // reputação explícita nova (secção 6/15.4) passam a ter valores interpolados entre eles.
  function reputationLerp(rep, points){
    const r = clamp(Number(rep)||0, 0, 100);
    const pts = points.slice().sort((a,b)=>a[0]-b[0]);
    if(r<=pts[0][0]) return pts[0][1];
    if(r>=pts[pts.length-1][0]) return pts[pts.length-1][1];
    for(let i=0;i<pts.length-1;i++){
      const [r0,v0]=pts[i], [r1,v1]=pts[i+1];
      if(r>=r0 && r<=r1) return v0 + (v1-v0)*(r-r0)/(r1-r0);
    }
    return pts[pts.length-1][1];
  }
  // reputationFromPoints: mantém o nome (chamado em todos os pontos que recalculam a reputação
  // de um clube a partir de reputacaoPontos — prémios de título, avaliação de objetivos, etc.)
  // mas o significado muda: já não converte para uma categoria, devolve o próprio número
  // (inteiro, 0-100). club.reputacao e club.reputacaoPontos ficam assim sempre sincronizados,
  // sem duas representações a divergir.
  function reputationFromPoints(pts){
    return clamp(Math.round(Number(pts)||0), 0, 100);
  }
  // ---- Fase 12: contratos e mercado regulamentado ----
  // Papel prometido no plantel: influencia a satisfação do jogador quando a utilização real
  // (jogos como titular) não corresponde ao que lhe foi prometido no momento da contratação.
  const PLAYER_ROLES = ["Titular","Rotacao","Desenvolvimento"];
  const ROLE_LABELS = { Titular:"Titular", Rotacao:"Rotação", Desenvolvimento:"Desenvolvimento" };
  // 2026-10-16: as datas do jogo são meia-noite LOCAL (Europe/Lisbon). toISOString() formata em UTC,
  // pelo que de março a outubro (UTC+1) a chave saía com o dia anterior ("amanhã" no próprio dia,
  // amigáveis mostrados 1 dia antes). Passa a formatar com os componentes locais.
  function isoDate(date){
    const d = date instanceof Date ? date : new Date(date);
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
  }
  function addYearsIso(dateStr, years){
    const d = new Date(dateStr+"T00:00:00Z");
    d.setUTCFullYear(d.getUTCFullYear()+years);
    return d.toISOString().slice(0,10);
  }
  // Janela real do mercado de hóquei em patins português: mercado fechado durante a época
  // (setembro a março, sem transferências imediatas entre clubes portugueses), pré-contratos
  // disponíveis a partir de abril para jogadores em final de contrato, e defeso (junho a
  // agosto) com ativação de pré-acordos e transferências livres entre clubes.
  function marketPeriodForDate(date){
    const d = date instanceof Date ? date : new Date(date);
    const m = d.getMonth(); // 0=Janeiro
    if(m===5||m===6||m===7) return "defeso";
    if(m===3||m===4) return "pre-contratos";
    return "epoca";
  }
  function marketPeriodLabel(period){
    // Correção (pedido do utilizador, 2026-09-14: "o defeso como antigamente deixou de fazer
    // sentido"): esta etiqueta não descreve o ecrã de fim de época (esse já deixou de se chamar
    // "Defeso" — ver defesoModalTitle) mas sim o período jun-ago usado por marketPeriodForDate
    // para a elegibilidade de pré-contratos, que continua a existir tal como antes. Deixa de
    // usar a palavra "Defeso" para não voltar a confundir os dois conceitos.
    return period==="defeso" ? "Verão — mercado aberto a transferências"
      : period==="pre-contratos" ? "Pré-contratos — só para jogadores em final de contrato"
      : "Mercado fechado — em época";
  }
  // Janelas reais de inscrição de transferências (RGHP Art.15º, pedido do utilizador 2026-09-14):
  // negociar é possível o ano inteiro (ver marketPeriodForDate acima, que continua a servir só a
  // elegibilidade de pré-contratos), mas um negócio de transferência definitiva entre clubes só
  // produz efeito — o jogador só pode de facto alinhar pelo novo clube — dentro de uma destas duas
  // janelas por época. Fora delas, o jogador fica "etiquetado TRF" no clube de origem até a
  // próxima janela abrir (ver player.pendingTransferHold e resolvePendingTransferHolds,
  // 04-financas.js/09-fluxo-epoca.js). Aplica-se por igual a todas as competições/países do jogo
  // (Portugal, OK Liga, Serie A1) — decisão explícita do utilizador, sem diferenciação por
  // regulamento federativo de cada país nesta versão. Jogadores livres (sem clube) e
  // pré-contratos não são afetados por esta regra — só transferências entre clubes.
  const REGISTRATION_WINDOWS = [
    {id:"reg-aug", startMonth:7, startDay:1, endMonth:9, endDay:15},  // 1 Ago – 15 Out
    {id:"reg-jan", startMonth:0, startDay:2, endMonth:0, endDay:15},  // 2 – 15 Jan
  ];
  function dateInMonthDayRange(date, startMonth, startDay, endMonth, endDay){
    const m=date.getMonth(), d=date.getDate();
    const val=m*100+d, start=startMonth*100+startDay, end=endMonth*100+endDay;
    return val>=start && val<=end;
  }
  function registrationWindowOpenFor(date){
    const d = date instanceof Date ? date : new Date(date);
    const w = REGISTRATION_WINDOWS.find(w=>dateInMonthDayRange(d,w.startMonth,w.startDay,w.endMonth,w.endDay));
    return w ? w.id : null;
  }
  // Próxima data (a partir de `date`, exclusive) em que uma janela de inscrição abre — usada para
  // avisar o utilizador e para definir quando um jogador etiquetado TRF finalmente se muda.
  function nextRegistrationWindowOpenDate(date){
    let d = addDays(date instanceof Date ? date : new Date(date), 1);
    for(let i=0;i<400;i++){
      if(registrationWindowOpenFor(d)) return d;
      d = addDays(d,1);
    }
    return null;
  }
  // Data de fecho da janela de inscrição aplicável a partir de `date` (pedido do utilizador
  // 2026-09-14: "se um acordo é alcançado com um clube, o jogador tem de responder até ao
  // limite do prazo final das inscrições"): se uma janela já está aberta em `date`, devolve o
  // fecho dessa MESMA janela; caso contrário, devolve o fecho da PRÓXIMA janela que vai abrir.
  // Usada para impor um prazo real à negociação de termos pessoais depois de um fee acordado —
  // sem isto, um acordo com o clube vendedor podia ficar pendente indefinidamente à espera de
  // uma proposta ao jogador, sem qualquer pressão de tempo (ver applyAcceptedOffer/
  // resolveExpiredClubAgreements, 04-financas.js).
  function registrationWindowCloseDate(date){
    const d = date instanceof Date ? date : new Date(date);
    const openId = registrationWindowOpenFor(d);
    if(openId){
      let close = d;
      for(let i=0;i<200;i++){
        const next = addDays(close,1);
        if(registrationWindowOpenFor(next)!==openId) return close;
        close = next;
      }
      return close;
    }
    const opens = nextRegistrationWindowOpenDate(d);
    return opens ? registrationWindowCloseDate(opens) : null;
  }
  function registrationWindowStatusLabel(date){
    const d = date instanceof Date ? date : new Date(date);
    if(registrationWindowOpenFor(d)) return "Janela de inscrição aberta — uma transferência acordada agora produz efeito imediato.";
    const next = nextRegistrationWindowOpenDate(d);
    return next ? `Janela de inscrição fechada — uma transferência acordada agora só é efetivada a partir de ${fmtDateShort(next)} (etiqueta TRF).` : "Janela de inscrição fechada.";
  }
  function assignInitialRole(ovr, age, potential, titular){
    if(titular || ovr>=15) return "Titular";
    if(age<=21 && (potential-ovr)>=3) return "Desenvolvimento";
    return "Rotacao";
  }
  // Distribuição inicial dos contratos: 70% por 1 ano, 27% por 2 anos e 3% por 3 anos.
  // Distribuição inicial dos contratos: 70% por 1 ano, 27% por 2 anos e 3% por 3 anos. Usada
  // apenas na criação do plantel de uma carreira nova (ou na importação de um plantel sem
  // salários reais) — nunca em renovações.
  function randomContractYears(rng){
    const r = rng ? rng() : Math.random();
    if(r<0.70) return 1;
    if(r<0.97) return 2;
    return 3;
  }
  // Calibração (encontrada numa simulação longa: 96% da liga sincronizada no mesmo ano de
  // renovação, todas as épocas): reaplicar a distribuição inicial (70% 1 ano) em TODAS as
  // renovações fazia praticamente toda a gente voltar a expirar no mesmo dia, todas as épocas,
  // para sempre — a liga nunca desincronizava. Distribuição própria e mais equilibrada só para
  // renovações e assinaturas de jogadores livres (não para a criação inicial do plantel, que
  // continua a usar randomContractYears tal como sempre).
  function randomRenewalContractYears(rng){
    const r = rng ? rng() : Math.random();
    if(r<0.35) return 1;
    if(r<0.75) return 2;
    return 3;
  }
  const TEMPERAMENTS = ["Profissional","Ambicioso","Calmo","Volátil"];
  const TEMPERAMENT_RATES = {
    "Profissional": { decayBenched:1.2, gainPlayed:1.6, sensitivity:0.5 },
    "Ambicioso":    { decayBenched:2.2, gainPlayed:2.0, sensitivity:0.8 },
    "Calmo":        { decayBenched:0.8, gainPlayed:1.0, sensitivity:0.4 },
    "Volátil":      { decayBenched:2.8, gainPlayed:2.6, sensitivity:1.2 },
  };

  function rnd(min,max){ return Math.floor(Math.random()*(max-min+1))+min; }
  function rndFloat(min,max){ return Math.random()*(max-min)+min; }
  function clamp(v,min,max){ return Math.max(min, Math.min(max, v)); }

  // Gerador determinístico: a "base de dados" de cada jogador passa a ser fixa — o mesmo
  // jogador (identificado pelo clube + nome + número) tem sempre os mesmos atributos, em vez
  // de serem sorteados de novo sempre que se começa um jogo novo.
  function hashStringToSeed(str){
    let h = 1779033703 ^ str.length;
    for(let i=0;i<str.length;i++){
      h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
      h = (h << 13) | (h >>> 19);
    }
    return () => {
      h = Math.imul(h ^ (h >>> 16), 2246822507);
      h = Math.imul(h ^ (h >>> 13), 3266489909);
      h ^= h >>> 16;
      return (h >>> 0) / 4294967296;
    };
  }
  function makeSeededRng(seedStr){ return hashStringToSeed(seedStr); }
  function seededRnd(rng, min, max){ return Math.floor(rng()*(max-min+1))+min; }
  function seededRndFloat(rng, min, max){ return rng()*(max-min)+min; }

  // Data de referência para as idades geradas dos jogadores (a idade "rnd(...)" é a idade que o
  // jogador tem nesta data — a partir daqui a idade real passa a calcular-se a partir da data
  // de nascimento, avançando exatamente no dia certo).
  const REFERENCE_AGE_DATE = new Date(Date.UTC(2026, 7, 1));
  // referenceDate (opcional): por omissão usa a data de referência fixa do arranque do jogo —
  // correta para a criação do plantel inicial, quando ainda não há data de jogo em curso. A
  // geração de jovens da formação (mais abaixo) passa sempre a data atual real, para o jovem
  // nascer no ano certo independentemente de estarmos na 1ª ou na 15ª época da carreira.
  function makeBirthDate(rng, age, referenceDate){
    const ref = referenceDate || REFERENCE_AGE_DATE;
    const year = ref.getUTCFullYear() - age;
    const month = seededRnd(rng, 0, 11);
    const day = seededRnd(rng, 1, 28);
    return new Date(Date.UTC(year, month, day)).toISOString().slice(0,10);
  }
  function computeAge(dataNascimento, currentDate){
    if(!dataNascimento) return null;
    const bd = new Date(dataNascimento+"T00:00:00Z");
    const cd = currentDate instanceof Date ? currentDate : new Date(currentDate);
    let age = cd.getUTCFullYear() - bd.getUTCFullYear();
    const m = cd.getUTCMonth() - bd.getUTCMonth();
    if(m < 0 || (m===0 && cd.getUTCDate() < bd.getUTCDate())) age--;
    return age;
  }
  function refreshPlayerAge(p, currentDate){
    if(!p.dataNascimento) return;
    const realAge = computeAge(p.dataNascimento, currentDate);
    if(realAge!=null) p.age = realAge;
  }
  function clampAttr(v){ return clamp(Math.round(v), 0, 20); }
  function clampAttrPrecise(v){ return clamp(v, 0, 20); }
  function avg(arr){ return arr.length ? arr.reduce((a,b)=>a+b,0)/arr.length : 0; }
  function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
  // Fase 16: ponto único de impressão do nome de um jogador — garante que um jogador emprestado
  // aparece sempre a azul (com etiqueta "EMPR."), em qualquer lista, ficha ou ecrã de jogo, sem
  // ter de replicar a verificação em cada sítio onde o nome é impresso.
  function playerNameHtml(player, opts){
    const safe = escapeHtml(player && player.name != null ? player.name : "");
    // Nas listas do clube dono, o jogador cedido a outro clube aparece a azul mais escuro (o azul claro
    // fica para quem está a receber o empréstimo).
    // Etiqueta: ♀ rapariga ainda na formação (não pode passar a sénior). Wonderkids não têm etiqueta (o utilizador tem de os encontrar).
    const tags = (player && player.genero==="F" && player.academyBracket ? `<span class="pl-tag pl-tag-f" title="Não pode passar a sénior">♀</span>` : "");
    if(player && player.emprestimo && opts && opts.cedido){
      return `<span class="player-loaned-out">${safe}</span><span class="loan-badge loan-badge-out">CEDIDO</span>${tags}`;
    }
    if(player && player.emprestimo){
      return `<span class="player-loaned">${safe}</span><span class="loan-badge">EMPR.</span>${tags}`;
    }
    return safe + tags;
  }
  // Correção (2026-09-14, pedido do utilizador: "os jogadores e as competições devem ser sempre
  // clicaveis, mesmo nas noticias"): a classe "playername-btn" já existe e já abre a ficha do
  // jogador (openPlayerModal) em várias listas do jogo (plantel, ficha de clube, estatísticas,
  // scouting) — mas cada uma dessas listas regista o seu próprio listener local depois de
  // desenhar o ecrã, e o feed de notícias nunca fez isso, por isso um nome de jogador dentro de
  // uma notícia nunca foi clicável. playerLinkHtml é o ponto único a usar sempre que o nome de um
  // jogador aparece dentro de texto de notícia (ou qualquer sítio novo): produz o mesmo botão
  // "playername-btn", com data-team+data-id, que agora tem também um listener GLOBAL delegado
  // (05-ui-navegacao.js) — funciona onde quer que apareça, mesmo em conteúdo reconstruído a cada
  // dia como o feed de notícias.
  function playerLinkHtml(teamId, player){
    if(!player) return "";
    return `<button class="playername-btn" data-team="${teamId}" data-id="${player.id}">${playerNameHtml(player)}</button>`;
  }
  function uid(){ return Math.random().toString(36).slice(2,9); }

  function overallFromAttrs(pos, attrs){
    if(pos==="GR") return Math.round(attrs.reflexos*0.29 + attrs.umParaUm*0.20 + attrs.agilidade*0.15 + attrs.concentracao*0.13 + attrs.meiaDistancia*0.08 + attrs.forca*0.05 + attrs.determinacao*0.05 + attrs.lideranca*0.05);
    return Math.round(attrs.habilidade*0.15 + attrs.finalizacao*0.12 + attrs.criatividade*0.12 + attrs.posicionamento*0.11 + attrs.desarme*0.12 + attrs.drible*0.10 + attrs.meiaDistancia*0.07 + attrs.velocidade*0.05 + attrs.forca*0.05 + attrs.determinacao*0.06 + attrs.lideranca*0.03 + attrs.agressividade*0.02);
  }
  function overall(p){ return overallFromAttrs(p.pos, p.attrs); }

  // Liga espanhola/italiana (2026-09-06, alargado 2026-09-06 à Serie A1): país do clube.
  // Correcção (auditoria externa, 2026-09-17): a decisão original desta função era nunca guardar
  // um campo "pais" no próprio objeto team, derivando sempre de divisaoAtual (OK Liga -> "es",
  // Serie A1 -> "it", resto -> "pt") — mas isso torna o país frágil a qualquer competição nova
  // (exactamente o mesmo tipo de problema já corrigido hoje no DIVISION_TIER, que também só tinha
  // entradas para as divisões existentes). team.pais é agora um atributo institucional próprio do
  // clube, guardado desde a criação (02-estado.js, a partir de def.pais, já usado há muito para o
  // país de origem dos jogadores) — a derivação por divisão fica só como recurso para clubes
  // antigos, gravados antes desta correcção, ainda sem o campo (normalizeLoadedTeams trata de os
  // migrar; este fallback é só uma rede de segurança extra).
  function teamCountry(team){
    if(team && team.pais) return team.pais;
    return team && (team.divisaoAtual==="ok-liga"||team.divisaoAtual==="ok-liga-plata") ? "es" : team && team.divisaoAtual==="serie-a1" ? "it" : "pt";
  }
  // País de origem do jogador — fixo desde a criação (nunca muda com uma transferência: é onde
  // nasceu/formou, não onde joga agora). Saves antigos (antes da OK Liga/Serie A1 existirem) não
  // têm este campo — assume-se "pt" por omissão (ver migração em 11-guardar-carregar.js).
  function playerHomeCountry(player){ return player && (player.paisOrigem==="es"||player.paisOrigem==="it") ? player.paisOrigem : "pt"; }
  // Nacionalidade/país de origem por código de país — usado sempre que se cria um jogador
  // (profissional importado, placeholder, jovem da formação ou candidato) para nunca haver mais
  // do que um sítio a decidir "que nacionalidade dou a este jogador". Um país novo só precisa de
  // uma entrada aqui.
  const COUNTRY_NATIONALITY_LABEL = { es: "Espanhola", it: "Italiana", pt: "Portuguesa", fr: "Francesa", de: "Alemã", ch: "Suíça", en: "Inglesa", at: "Austríaca" };
  function nationalityForCountry(pais){ return COUNTRY_NATIONALITY_LABEL[pais] || COUNTRY_NATIONALITY_LABEL.pt; }
  // Correção (nuvem europeia, 2026-09-12): normalizeCountryCode só reconhecia "es"/"it" — um
  // jogador de um clube nuvem francês/alemão/suíço/inglês/austríaco ficava com paisOrigem "pt"
  // (nunca usado para nada além de nacionalidade/deslocamento, que não se aplicam a estes clubes
  // sem mercado nem evolução, mas mantido correto por consistência com o nome/nacionalidade).
  function normalizeCountryCode(pais){ return ["es","it","fr","de","ch","en","at"].includes(pais) ? pais : "pt"; }
  // Bandeirinha de nacionalidade (pedido do utilizador, 2026-09-26: "quero uma bandeirinha a
  // dizer qual a nacionalidade") — inicialmente um emoji por código de país, os mesmos 8 códigos
  // reconhecidos por normalizeCountryCode acima (nunca chega nenhum outro a paisOrigem).
  // Correção (pergunta do utilizador, 2026-09-26: "não aparecem as bandeirinhas") — os emojis de
  // bandeira (pares de "regional indicator symbols", ex. 🇵🇹) dependem de o sistema operativo/
  // navegador ter uma fonte de emoji a cores com esses glifos; fora do macOS/iOS isto é
  // inconsistente (Windows em particular mostra frequentemente só o código do país em texto, ou
  // nada). Passa a usar imagens reais (SVG, mesmo princípio dos escudos dos clubes em
  // img/badges/) em vez de depender da fonte do sistema — ver flagImgHtml/nationalityFlagHtml
  // mais abaixo. "en" (Inglaterra) usa a bandeira de Inglaterra (cruz de S. Jorge), não a do
  // Reino Unido.
  const COUNTRY_FLAG_CODE = { pt:"pt", es:"es", it:"it", fr:"fr", de:"de", ch:"ch", en:"gb-eng", at:"at" };
  function countryFlagCode(pais){ return COUNTRY_FLAG_CODE[normalizeCountryCode(pais)]; }
  // Correção (pergunta do utilizador, 2026-09-26: "não tens as nacionalidades nas bases de
  // dados?"): a bandeirinha acima usava paisOrigem, que só reconhece 8 países (normalizeCountryCode,
  // usado no cálculo do prémio de deslocação/alojamento — ver isPlayerDisplaced) e, para planteis
  // importados da base de dados (database/database.json), cai sempre no país do CLUBE quando
  // raw.paisOrigem não existe (nunca existe — a BD só tem "nacionalidade" como texto), ignorando a
  // nacionalidade real e variada que a própria BD já tem por jogador (ex.: "Argentina", "Chile",
  // "Angola", "Angola / Portugal" para jogadores com dupla nacionalidade). Esta função lê
  // directamente p.nacionalidade (o texto real, sempre preenchido — ver criação do jogador,
  // playerFromRawRoster) em vez de paisOrigem, só para escolher a bandeira a mostrar — não mexe em
  // paisOrigem nem no cálculo de deslocação/salário, que continuam exactamente como estavam (mudar
  // isso teria impacto na economia do jogo, já calibrada, e não foi pedido).
  const NATIONALITY_NAME_TO_FLAG_CODE = {
    "portugal":"pt", "espanha":"es", "itália":"it", "italia":"it", "italiana":"it",
    "argentina":"ar", "frança":"fr", "franca":"fr", "chile":"cl", "angola":"ao",
    "inglaterra":"gb-eng", "moçambique":"mz", "mocambique":"mz", "colômbia":"co", "colombia":"co",
    "alemanha":"de", "países baixos":"nl", "paises baixos":"nl", "suíça":"ch", "suica":"ch",
    "áustria":"at", "austria":"at", "brasil":"br",
  };
  function nationalityFlagCode(p){
    const raw = p && p.nacionalidade ? String(p.nacionalidade) : "";
    const primeira = raw.split("/")[0].trim().toLowerCase();
    return NATIONALITY_NAME_TO_FLAG_CODE[primeira] || countryFlagCode(p && p.paisOrigem);
  }
  // HTML da bandeirinha junto ao nome do jogador — imagem real (ver comentário acima de
  // COUNTRY_FLAG_CODE), com o nome do país completo no title (tooltip) tal como antes.
  function nationalityFlagHtml(p){
    const code = nationalityFlagCode(p);
    if(!code) return "";
    return `<img class="nat-flag" src="img/flags/${code}.svg" alt="" title="${escapeHtml(p&&p.nacionalidade||"")}">`;
  }
  // Um jogador está "deslocado" quando joga num país diferente do seu país de origem — pedido do
  // utilizador (2026-09-06): "um jogador que muda de país tem de ir receber mais, pois vai estar
  // deslocado da sua família e isso paga-se... para além de ter de se pagar casa". Ver
  // DISPLACEMENT_WAGE_PREMIUM/playerHousingCost em 04-financas.js.
  function isPlayerDisplaced(player, team){ return !!team && playerHomeCountry(player)!==teamCountry(team); }

  // Disponibilidade para convocatória/escalação (2026-09-14): um jogador fica indisponível por
  // suspensão (cartão vermelho, suspensoJogos) OU por lesão grave em recuperação (diasLesao) —
  // mesmo padrão para as duas causas, para não duplicar o filtro em cada um dos muitos sítios
  // (convocatória, escalação, seleção de lineup da IA, Elite Cup) que decidem quem pode jogar.
  // Uma lesão ligeira NUNCA torna o jogador indisponível — só lhe custa condição física (ver
  // applyInjuryOutcome, 06-motor-jogo.js) — por isso não entra aqui.
  // Seleções Nacionais (2026-09-26): um jogador convocado fica indisponível para o clube até à
  // última data fixa do torneio (convocadoSelecaoAte, escrita em pickNationalSquad/Fase 2) —
  // mesmo padrão de "critério de indisponibilidade" que suspensão/lesão, só que por data fixa em
  // vez de contador decrescente (o torneio inteiro resolve-se de uma vez, com datas conhecidas à
  // partida — ver runSelecoesTournamentForNewSeason).
  function playerAvailableForMatch(p){
    return (p.suspensoJogos||0)<=0 && (p.diasLesao||0)<=0 &&
      !(p.convocadoSelecaoAte && state.currentDate <= p.convocadoSelecaoAte) &&
      !(p.bxJogouB && p.bxJogouB === Math.floor(new Date(state.currentDate).getTime()/86400000)) &&
      !(p.scint && p.scint.registoAte && new Date(state.currentDate).getTime() <= p.scint.registoAte);
  }

  function tierBaseLevel(tier){ return tier===1 ? 16 : tier===2 ? 14 : 13; }
  function seasonLabel(n){ const startYear = 2025+n; return startYear + "/" + String(startYear+1).slice(-2); }
  function seasonSortValue(epoca){ const m=String(epoca||"").match(/(19|20)\d{2}/); return m ? parseInt(m[0],10) : 0; }

  // ---- Calendar / dates ----
  const WEEKDAYS = ["Domingo","Segunda-feira","Terça-feira","Quarta-feira","Quinta-feira","Sexta-feira","Sábado"];
  const MONTHS = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
  function addDays(date, n){ const d = new Date(date); d.setDate(d.getDate()+n); return d; }
  function sameDay(a,b){ return a.getFullYear()===b.getFullYear() && a.getMonth()===b.getMonth() && a.getDate()===b.getDate(); }
  function fmtDateLong(d){ return `${WEEKDAYS[d.getDay()]}, ${d.getDate()} de ${MONTHS[d.getMonth()]} de ${d.getFullYear()}`; }
  // Correção (2026-09-16, reportado pelo utilizador: "às vezes as datas aparece undefined"):
  // esta função assumia sempre receber um Date válido — um jogo ainda por marcar (ex.: uma
  // eliminatória cujo sorteio ainda não aconteceu) guarda date:null até ser agendado, e um valor
  // desses a chegar aqui produzia "undefined/NaN/undefined" em vez de rebentar de forma óbvia.
  // Agora devolve sempre um traço em vez de propagar o valor em falta.
  function fmtDateShort(d){
    if(!d) return "—";
    const dt = (d instanceof Date) ? d : new Date(d);
    if(isNaN(dt.getTime())) return "—";
    return `${String(dt.getDate()).padStart(2,"0")}/${String(dt.getMonth()+1).padStart(2,"0")}/${dt.getFullYear()}`;
  }
  function isChristmasBreak(date){
    const month = date.getMonth(), day = date.getDate();
    return (month===11 && day>=24) || (month===0 && day<=1);
  }
  function nextFixtureDateOutsideChristmasBreak(date){
    let d = new Date(date);
    while(isChristmasBreak(d)) d = addDays(d, 7);
    return d;
  }
  function assignFixtureDates(){
    assignFixtureDatesFor(state.competitions[state.userCompetitionId]);
  }
  // Supertaça António Livramento (roteiro de implementação): a época passa a ancorar-se em
  // outubro, não em novembro. A Supertaça disputa-se sempre no 2.º sábado de outubro, em campo
  // neutro, e a 1.ª jornada do Campeonato Placard no domingo seguinte — ver 07c-supertaca.js.
  function firstWeekdayOfMonth(year, month, weekday){
    // weekday: 0=domingo .. 6=sábado
    const d = new Date(year, month, 1);
    const diff = (weekday - d.getDay() + 7) % 7;
    d.setDate(1 + diff);
    return d;
  }
  function getSecondSaturdayOfOctober(year){
    return addDays(firstWeekdayOfMonth(year, 9, 6), 7); // outubro=9 (0-indexado), sábado=6
  }
  function getPlacardOpeningSunday(year){
    return addDays(getSecondSaturdayOfOctober(year), 1);
  }
  // Correção (calendário sem saltos, pedido do utilizador 2026-09-14): "lastWeekdayOfMonth" é o
  // espelho de firstWeekdayOfMonth, a recuar a partir do último dia do mês em vez de avançar a
  // partir do 1º — necessário para agendar a Elite Cup na última sexta-feira de Setembro (ver
  // eliteCupFaseDates, 07d-elite-cup.js), tal como firstWeekdayOfMonth já serve o 2º sábado de
  // outubro acima.
  function lastWeekdayOfMonth(year, month, weekday){
    const d = new Date(year, month+1, 0); // último dia do mês
    const diff = (d.getDay() - weekday + 7) % 7;
    d.setDate(d.getDate() - diff);
    return d;
  }
  // Início real da época (pedido explícito do utilizador, 2026-09-14: "o jogo deve começar no
  // dia 1 de Setembro"). Antes, o "relógio" da carreira arrancava "1 semana antes dos quartos de
  // final da Elite Cup" — uma data sem significado próprio, e que só fazia sentido porque, logo a
  // seguir à Elite Cup terminar, o calendário SALTAVA de qualquer forma até 5 dias antes da 1ª
  // jornada (ver a remoção desse salto em finalizePreSeasonLeagueStart/finalizeNewSeasonTail).
  // Agora que esse salto desapareceu e o tempo passa sempre dia a dia (incluindo à volta da Elite
  // Cup, já agendada para o fim de Setembro — ver eliteCupFaseDates), a época pode começar mesmo
  // no dia 1 de Setembro, sem qualquer relação de cálculo com a Elite Cup.
  function seasonStartDate(season){
    return new Date(2026 + (season - 1), 8, 1); // setembro=8 (0-indexado)
  }
  // Versão genérica, para poder atribuir datas a qualquer competição (não só a do utilizador) —
  // usa a mesma cadência semanal a partir da mesma data-base, para as jornadas de todas as
  // competições caírem na mesma semana.
  // Correção/Supertaça: a data-base deixa de ser um "8 de novembro" fixo e passa a ser calculada
  // — o domingo a seguir ao 2.º sábado de outubro dessa época (ver getPlacardOpeningSunday) —
  // para a 1.ª jornada do Placard vir sempre imediatamente depois da Supertaça António Livramento.
  function assignFixtureDatesFor(competition){
    const base = getPlacardOpeningSunday(2025 + state.season);
    let date = nextFixtureDateOutsideChristmasBreak(base);
    competition.fixtures.forEach((round, idx) => {
      if(idx>0) date = nextFixtureDateOutsideChristmasBreak(addDays(date, 7));
      round.date = new Date(date);
    });
  }

  // ---- News feed ----
  function deriveNewsTitle(html){
    const plain = String(html).replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim();
    return plain.length>72 ? plain.slice(0,70)+"…" : plain;
  }
  function newsIsFromUserDivision(text){
    const mine=state.teams&&state.teams[state.userTeamId]; if(!mine)return true;
    const plain=String(text||"").replace(/<[^>]+>/g," ").toLocaleLowerCase("pt-PT");
    return Object.values(state.teams).some(team=>team.divisaoAtual===mine.divisaoAtual&&plain.includes(String(team.name||"").toLocaleLowerCase("pt-PT")));
  }
  // ---- Caixa de correio (2026-09-16, pedido do utilizador: reformular as notícias como uma
  // caixa de e-mail, com remetentes por departamento e endereço por país do clube) ----
  // Cada "kind" de notícia já existente mapeia para um departamento/remetente fixo. "mercado"
  // pode ainda apontar para o endereço do clube específico do outro lado do negócio, quando
  // conhecido (opts.teamId) — ex.: mercado@benfica.pt em vez do genérico mercado@clube.pt.
  const NEWS_SENDER_META = {
    mercado:   { icon:"💼", dept:"mercado" },
    // Correção (pedido do utilizador, 2026-09-17: "tem de haver um endereço de email de mercado
    // (como está) para informações sobre transferencias de outro clubes, e outro endereço para as
    // minhas propostas"): mercado@ mantém-se para notícias gerais do mercado (negócios fechados
    // entre clubes de IA, boletins) — "proposta" é um endereço à parte, específico da
    // correspondência de uma negociação em que o utilizador é diretamente parte (proposta
    // enviada, resposta, contraproposta, aceite/recusa), tanto para fee entre clubes como para
    // termos pessoais e empréstimos.
    proposta:  { icon:"🤝", dept:"propostas" },
    direcao:   { icon:"📊", dept:"direccao" },
    gestor:    { icon:"📊", dept:"direccao" },
    // Mercado de treinadores (2026-09-23): despedimentos/contratações de treinadores de OUTROS
    // clubes (na mesma divisão do utilizador, ver pushTreinadorMercadoNews) — mesmo departamento
    // visual de "direcao"/"gestor" (é, no fundo, a mesma área), ícone próprio.
    staff:     { icon:"👔", dept:"direccao" },
    scouting:  { icon:"🔎", dept:"scouting" },
    tatica:    { icon:"📋", dept:"deptecnico" },
    juventude: { icon:"🌱", dept:"academia" },
    clinico:   { icon:"🩺", dept:"depclinico" },
    jogo:      { icon:"🏆", dept:"competicao" },
    // Motor de Eventos Narrativos (2026-09-28, 09b-eventos-narrativos.js): departamento próprio
    // para não se confundir com nenhum dos existentes — a raridade (comum/raro/épico/lendário)
    // aparece como badge dentro do próprio título da notícia, não no estilo do remetente.
    evento:    { icon:"🎬", dept:"narrativa" },
    // Correção (pedido do utilizador, 2026-09-17: "sistema@clube muda para geral@clube") — o
    // endereço genérico do clube passa de sistema@ para geral@, mais natural para um clube real.
    // Conselho de Disciplina e Televisão (2026-10-12): emails da federação (remetente passado por opts.sender).
    disciplina:{ icon:"⚖️", dept:"disciplina" },
    tv:        { icon:"📺", dept:"televisao" },
    patrocinio:{ icon:"🤝", dept:"comercial" },
    personalidade:{ icon:"🧠", dept:"balneario" },
    arbitragem:{ icon:"🟨", dept:"arbitragem" },
    // Clássicos (08ze-classicos.js, 2026-10-22): imprensa desportiva à volta dos grandes jogos.
    classico:  { icon:"🔥", dept:"classicos" },
    sistema:   { icon:"⚙️", dept:"geral" },
    geral:     { icon:"⚙️", dept:"geral" },
  };
  function newsSenderMeta(kind){ return NEWS_SENDER_META[kind] || NEWS_SENDER_META.sistema; }
  function newsSenderIcon(kind){ return newsSenderMeta(kind).icon; }
  // Avatar do remetente (2026-09-17, pedido do utilizador: caixa de e-mail "mais parecida com o
  // Outlook") — círculo colorido com duas iniciais, uma cor fixa por departamento (não por kind,
  // porque "gestor"/"direcao" e "sistema"/"geral" partilham departamento e devem ter o mesmo
  // visual).
  const NEWS_DEPT_STYLE = {
    mercado:    { color:"#2f7dd1", initials:"ME" },
    propostas:  { color:"#1f9e6d", initials:"PR" },
    direccao:   { color:"#b8860b", initials:"DI" },
    scouting:   { color:"#3f8f5f", initials:"SC" },
    deptecnico: { color:"#7a5cc9", initials:"DT" },
    academia:   { color:"#4fa3a3", initials:"AC" },
    depclinico: { color:"#d9534f", initials:"DC" },
    competicao: { color:"#c77c1f", initials:"CO" },
    narrativa:  { color:"#9b59b6", initials:"EV" },
    disciplina: { color:"#8a2be2", initials:"CD" },
    televisao:  { color:"#0e7490", initials:"TV" },
    comercial:  { color:"#0f766e", initials:"CO" },
    balneario:  { color:"#b45309", initials:"BA" },
    arbitragem: { color:"#4b5563", initials:"AR" },
    classicos:  { color:"#c0392b", initials:"CL" },
    geral:      { color:"#6b7280", initials:"GE" },
  };
  function newsSenderStyle(kind){ return NEWS_DEPT_STYLE[newsSenderMeta(kind).dept] || NEWS_DEPT_STYLE.geral; }
  // País (→ TLD do endereço) de um clube: reaproveita teamCountry (clubes nacionais, por
  // divisão) e o campo pais dos clubes da nuvem europeia; cai em CLUB_DEFS/"pt" por defeito.
  function newsCountryForTeam(teamId){
    const team = teamId && state.teams && state.teams[teamId];
    if(team && team.nuvemEuropeia) return team.pais || "pt";
    if(team) return teamCountry(team);
    const def = (typeof CLUB_DEFS!=="undefined" ? CLUB_DEFS : []).find(d=>d.id===teamId);
    return (def && def.pais) || "pt";
  }
  // Correção (2026-09-16, apontada pelo utilizador): passar opts.teamId só mudava o TLD — o
  // domínio continuava sempre o literal "clube", nunca o nome do clube em questão.
  // Correção (2026-09-17, apontada pelo utilizador): a correção acima ainda deixava o literal
  // "clube" sempre que o clube de referência era o do PRÓPRIO utilizador (ex.: sistema@clube.pt
  // em vez de sistema@ocbarcelos.pt) — decisão errada, revertida agora. O domínio usa sempre o
  // slug real do clube (o próprio ou outro, tanto faz); só cai no genérico "clube" quando não há
  // mesmo nenhum clube válido para consultar (ex.: antes de escolher clube no arranque do jogo).
  function resolveNewsSender(kind, opts){
    opts = opts || {};
    if(opts.sender) return opts.sender;
    const meta = newsSenderMeta(kind);
    const refTeamId = opts.teamId || state.userTeamId;
    const tld = newsCountryForTeam(refTeamId) || "pt";
    const domain = (refTeamId && state.teams && state.teams[refTeamId]) ? refTeamId : "clube";
    return `${meta.dept}@${domain}.${tld}`;
  }
  // Endereço pessoal do treinador (2026-09-16, pedido do utilizador): primeiro e último nome de
  // state.managerName, sem acentos/cedilhas, "nome.apelido@clube.<tld>" — usado como remetente
  // das notícias de mercado/direção que representam algo enviado PELO utilizador (propostas,
  // pedidos), em vez do endereço genérico do departamento.
  function slugifyNamePart(s){
    return String(s||"").normalize("NFD").replace(/[̀-ͯ]/g,"").toLowerCase().replace(/[^a-z]/g,"");
  }
  function managerEmailAddress(teamId){
    // Mesma correção (2026-09-17) de resolveNewsSender: o domínio usa o slug real do clube, não
    // o literal "clube" — o e-mail pessoal do treinador é joao.dias@ocbarcelos.pt, não
    // joao.dias@clube.pt.
    const refTeamId = teamId || state.userTeamId;
    const tld = newsCountryForTeam(refTeamId) || "pt";
    const domain = (refTeamId && state.teams && state.teams[refTeamId]) ? refTeamId : "clube";
    const parts = String(state.managerName||"").trim().split(/\s+/).filter(Boolean);
    if(!parts.length) return `treinador@${domain}.${tld}`;
    const first = slugifyNamePart(parts[0]);
    const last = parts.length>1 ? slugifyNamePart(parts[parts.length-1]) : "";
    const local = (first && last && last!==first) ? `${first}.${last}` : (first||last||"treinador");
    return `${local}@${domain}.${tld}`;
  }
  // Avanço automático de vários dias (2026-09-16, pedido do utilizador: "não quero ter de
  // carregar no botão todos os dias"): cada notícia pode marcar-se a si própria como motivo para
  // parar esse avanço (autoAdvanceStop, 5º argumento opcional) — ver runContinuarAutoAdvance,
  // 09-fluxo-epoca.js. Só um punhado de sítios de chamada passam esta opção; todos os outros
  // continuam exatamente como antes (news.autoAdvanceStop fica undefined/false).
  // Prémios de fim de época (2026-09-21): auxiliar de uso geral — "esta competição envolve o
  // clube do utilizador?" — usado para só gerar notícia de prémios nas competições em que o
  // utilizador realmente participa, mesmo os prémios em si sendo atribuídos em todas as
  // competições. Não existia nenhum auxiliar geral equivalente (o único precedente, em
  // 07g-europa.js, comparava manualmente teamIds em cada ponto de chamada).
  function competitionIsRelevantToUser(competitionId){
    const comp = state.competitions && state.competitions[competitionId];
    if(comp && Array.isArray(comp.teamIds)) return comp.teamIds.includes(state.userTeamId);
    // Competições que não vivem em state.competitions (Europa: grupos de qualificação/Champions e
    // eliminatórias da Champions/Cup/Trophy) — reaproveita os localizadores já existentes em
    // 07g-europa.js (europaGroupById/europaBracketById) em vez de duplicar a estrutura de dados.
    if(typeof europaGroupById==="function"){
      const grupo = europaGroupById(competitionId);
      if(grupo) return Array.isArray(grupo.teamIds) && grupo.teamIds.includes(state.userTeamId);
    }
    if(typeof europaBracketById==="function"){
      const bracket = europaBracketById(competitionId);
      if(bracket){
        const ed = state.europa && state.europa.edicao;
        const tier = ed && ed.participantes && ed.participantes[state.userTeamId];
        return tier === competitionId;
      }
    }
    return false;
  }
  // Correção (bug reportado pelo utilizador, 2026-09-27: "as notícias lêem-se de baixo para
  // cima") — pushNews sempre inseriu cada notícia nova no TOPO absoluto (unshift), para que o
  // dia mais recente apareça sempre primeiro. Isso funciona bem entre dias diferentes, mas
  // quando várias notícias nascem no MESMO dia (ex.: antevisão de uma jornada e, a seguir, os
  // seus resultados — ou, nas Seleções, sorteio + convocatória + antevisão + resultados de uma
  // jornada, tudo na mesma data), cada nova inserção no topo empurra as anteriores do MESMO dia
  // para baixo — o resultado acaba a aparecer ACIMA da antevisão, obrigando a ler a lista de
  // baixo para cima para acompanhar a história pela ordem certa. Em vez de inserir sempre no
  // índice 0, insere a seguir a todas as notícias já existentes com a MESMA data (mas sempre
  // antes de qualquer notícia de um dia mais antigo) — o dia mais recente continua sempre no
  // topo da lista, mas dentro desse dia a ordem de criação (a ordem da história) é preservada.
  function pushNews(date, text, kind, title, opts){
    kind = kind || "geral";
    if(kind==="mercado"&&!newsIsFromUserDivision(`${title||""} ${text||""}`))return;
    const sender = resolveNewsSender(kind, opts);
    const entry = { date: new Date(date), text, kind, title: title || deriveNewsTitle(text), autoAdvanceStop: !!(opts&&opts.autoAdvanceStop), sender, archived:false, read:false };
    const dateTime = entry.date.getTime();
    // Correção (pedido do utilizador, 2026-10-01: "a ordem das notícias está errada... a mais
    // recente é o Martim a mudar-se e a mais antiga são os termos pessoais aceites" — mas a
    // lista mostrava os termos pessoais em cima): a condição antiga (===) avançava insertAt para
    // LÁ DE TODAS as notícias já existentes com a MESMA data, inserindo a nova sempre a seguir a
    // essas — ou seja, entre duas notícias do mesmo dia, a que foi criada PRIMEIRO ficava sempre
    // acima da que foi criada depois (ordem invertida face ao resto da lista, que é sempre "mais
    // recente no topo"). A condição correta só avança enquanto a notícia já existente for
    // ESTRITAMENTE mais recente (>) — assim a nova notícia entra sempre à frente de qualquer
    // notícia já existente com a mesma data (ou mais antiga), mantendo "mais recente no topo"
    // também dentro do mesmo dia.
    let insertAt = 0;
    while(insertAt < state.news.length && state.news[insertAt].date.getTime()>dateTime) insertAt++;
    state.news.splice(insertAt, 0, entry);
    // Correção (pedido do utilizador, 2026-10-05: "os emails novos não estão com cor diferente"):
    // newsSelectedIdx é um ÍNDICE em state.news; ao inserir uma mensagem antes da selecionada, o
    // índice passava a apontar para outra mensagem (a mais recente), que renderNews marcava logo
    // como lida e mostrava no painel de leitura — os e-mails novos nunca chegavam a aparecer como
    // não lidos com a caixa de entrada aberta. A seleção acompanha a mensagem que já estava aberta.
    if(newsSelectedIdx!=null && insertAt<=newsSelectedIdx) newsSelectedIdx++;
    if(state.news.length > 320) state.news.length = 320;
    if(newsSelectedIdx!=null && newsSelectedIdx>=state.news.length) newsSelectedIdx=null;
    if(state.activeView==="noticias") renderNews();
    updateEmailNavBadge();
  }
  // Indicador de e-mails por ler (2026-09-25, pedido do utilizador: "indicador encarnado de
  // número de e-mails por ler") — badge vermelho junto ao botão "E-mail" da barra lateral, com a
  // contagem de mensagens ativas (não arquivadas) e não lidas. Chamado sempre que o conjunto de
  // notícias muda (pushNews, arquivar/reabrir, marcar como lida) e em renderAll() para garantir
  // que aparece mesmo antes de o separador E-mail alguma vez ter sido aberto nesta sessão.
  function updateEmailNavBadge(){
    const btn = document.querySelector('.hub-nav-btn[data-view="noticias"]');
    if(!btn) return;
    const unread = (state.news||[]).filter(n=>!n.archived && !n.read).length;
    let badge = btn.querySelector(".nav-unread-badge");
    if(unread>0){
      if(!badge){
        badge = document.createElement("span");
        badge.className = "nav-unread-badge";
        btn.appendChild(badge);
      }
      badge.textContent = unread>99 ? "99+" : String(unread);
    } else if(badge){
      badge.remove();
    }
  }
  // Ordem de LEITURA (2026-09-25, pedido do utilizador: "a ordem de leitura é do mais antigo
  // para o mais novo") — distinta da ordem de EXIBIÇÃO da lista (que se mantém do mais novo para
  // o mais antigo, "deixar a ordem como está"). Usada só para decidir qual mensagem abre
  // primeiro/a seguir, nunca para reordenar o que aparece na coluna esquerda.
  function emailsByReadingOrder(list){
    // Empate de data: a lista guarda a mais recente primeiro, por isso a que está mais abaixo (índice maior) é mais antiga.
    return list.slice().sort((a,b)=> (new Date(a.date) - new Date(b.date)) || (state.news.indexOf(b) - state.news.indexOf(a)));
  }
  // Próxima mensagem não lida, pela ordem de leitura (mais antiga primeiro), entre as mensagens
  // ativas (não arquivadas). Usada tanto para escolher a seleção inicial da caixa de entrada como
  // para o botão "Ler seguinte".
  function nextUnreadNews(){
    const unread = (state.news||[]).filter(n=>!n.archived && !n.read);
    return unread.length ? emailsByReadingOrder(unread)[0] : null;
  }
  let newsInboxFilterKind = null;
  // Estado de UI da caixa de e-mail (2026-09-17, pedido do utilizador: "mais parecido com o
  // Outlook") — nunca persiste no save, é só a mensagem atualmente aberta no painel de leitura,
  // tal como o filtro de categoria acima. Guarda o índice real em state.news.
  let newsSelectedIdx = null;
  // Linha compacta da lista (coluna esquerda) — em vez do antigo <details> que expandia o corpo
  // inline, cada linha só mostra remetente, assunto e uma pré-visualização de uma linha; clicar
  // seleciona a mensagem e mostra o corpo completo na coluna da direita (email-reading-pane).
  function emailRowHtml(n, realIdx, isSelected){
    const style = newsSenderStyle(n.kind);
    const sender = n.sender || resolveNewsSender(n.kind);
    // Relatórios em formato de documento (08u-relatorios.js) trazem o resumo em texto simples.
    const repPrev = /<span class="rep-prev">([\s\S]*?)<\/span>/.exec(String(n.text||""));
    const plainBody = repPrev ? repPrev[1].replace(/&amp;/g,"&").replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&quot;/g,'"').replace(/&#39;/g,"'") : String(n.text||"").replace(/<[^>]+>/g," ").replace(/\s+/g," ").trim();
    const preview = plainBody.length>90 ? plainBody.slice(0,88)+"…" : plainBody;
    return `<div class="email-row${n.read?"":" email-unread"}${isSelected?" email-row-selected":""}"${realIdx==null?"":` data-news-row="${realIdx}"`}>
        <span class="email-avatar" style="background:${style.color};" aria-hidden="true">${style.initials}</span>
        <div class="email-row-main">
          <div class="email-row-top"><span class="email-row-sender">${escapeHtml(sender)}</span><span class="email-row-date">${fmtDateShort(n.date)}</span></div>
          <div class="email-row-subject">${escapeHtml(n.title||"")}</div>
          <div class="email-row-preview">${escapeHtml(preview)}</div>
        </div>
      </div>`;
  }
  // Painel de leitura (coluna direita) — corpo completo da mensagem selecionada, com o mesmo
  // botão de arquivar/reabrir que a lista já tinha. n.text é HTML de confiança (gerado só por
  // pushNews, nunca por texto livre do utilizador) — inserido tal como já acontecia no antigo
  // ".email-body", incluindo os botões "news-open-contract"/"news-open-freeagent".
  function emailReadingPaneHtml(n, realIdx){
    if(!n) return `<div class="email-reading-empty">Seleciona uma mensagem para ler.</div>`;
    const style = newsSenderStyle(n.kind);
    const sender = n.sender || resolveNewsSender(n.kind);
    const archiveBtn = `<button type="button" class="btn btn-ghost email-archive-btn" data-news-archive="${realIdx}">${n.archived?"↩ Reabrir":"🗄 Arquivar"}</button>`;
    // Botão "Ler seguinte" (2026-09-25, pedido do utilizador: "acrescentar botão para ler
    // próximo") — avança para a próxima mensagem não lida pela ordem de leitura (mais antiga
    // primeiro), sem o utilizador ter de voltar à lista. A mensagem atual já foi marcada como
    // lida por renderNews antes de este HTML ser gerado, por isso nextUnreadNews() já não a
    // inclui e devolve mesmo a mensagem seguinte a abrir.
    // Correção (2026-10-15): "Ler seguinte" sobe para a mensagem imediatamente mais recente (a que está
    // logo acima na lista), pela ordem em que a lista é mostrada — não salta para a não lida mais antiga.
    const visiveis = (newsInboxFilterKind ? state.news.filter(x=>x.kind===newsInboxFilterKind) : state.news).filter(x=>!x.archived);
    const pos = visiveis.indexOf(n);
    const nextNews = pos>0 ? visiveis[pos-1] : null;
    const nextIdx = nextNews ? state.news.indexOf(nextNews) : null;
    const nextBtn = nextIdx!=null
      ? `<button type="button" class="btn btn-primary email-next-btn" data-news-next="${nextIdx}">Ler seguinte ›</button>`
      : `<button type="button" class="btn btn-primary email-next-btn" disabled title="Já estás na mensagem mais recente">Ler seguinte ›</button>`;
    return `<div class="email-reading-header">
        <span class="email-avatar email-avatar-lg" style="background:${style.color};" aria-hidden="true">${style.initials}</span>
        <div class="email-reading-header-main">
          <div class="email-reading-subject">${escapeHtml(n.title||"")}</div>
          <div class="email-reading-meta"><b>${escapeHtml(sender)}</b> · ${fmtDateShort(n.date)}</div>
        </div>
        <div class="email-reading-actions">${nextBtn}${archiveBtn}</div>
      </div>
      <div class="email-reading-body${/sorteio|jornada/i.test(n.title||"")?" email-no-underline":""}">${n.text}</div>`;
  }
  function renderNews(){
    const box = document.getElementById("newsList");
    // Correção (2026-09-17, apontada pelo utilizador): clicar numa mensagem mais antiga
    // recriava todo o innerHTML e a lista lateral voltava sempre ao topo. Guarda a posição de
    // scroll da coluna esquerda antes de re-renderizar e repõe-na no fim.
    const prevListPane = box.querySelector(".email-list-pane");
    const prevScrollTop = prevListPane ? prevListPane.scrollTop : 0;
    if(!state.news.length){
      box.innerHTML = '<div class="feed-empty" style="color:var(--texto-mute);font-style:italic;">Ainda não há notícias — carrega em "Continuar" para avançar a época.</div>';
      updateEmailNavBadge();
      return;
    }
    const kinds = Array.from(new Set(state.news.map(n=>n.kind)));
    const filterHtml = `<div class="inbox-toolbar"><select id="newsFilterSelect" class="inbox-filter">
      <option value="">Todas as categorias</option>
      ${kinds.map(k=>`<option value="${k}"${newsInboxFilterKind===k?" selected":""}>${newsSenderIcon(k)} ${newsSenderMeta(k).dept}</option>`).join("")}
    </select></div>`;
    const visible = newsInboxFilterKind ? state.news.filter(n=>n.kind===newsInboxFilterKind) : state.news;
    const active = visible.filter(n=>!n.archived);
    const archived = visible.filter(n=>n.archived);
    // A seleção pode deixar de existir na lista visível (filtro de categoria mudou, ou a própria
    // mensagem foi arquivada) — cai sempre para a primeira mensagem ativa disponível, nunca para
    // um painel de leitura "órfão".
    const activeIdxs = active.map(n=>state.news.indexOf(n));
    if(newsSelectedIdx==null || !activeIdxs.includes(newsSelectedIdx)){
      // Ordem de leitura (2026-09-25, pedido do utilizador: "começar sempre a ler os e-mails
      // mais antigos"; reconfirmado a 2026-09-27: "ler da mais antiga, em baixo, para a mais
      // nova, no topo") — ao (re)entrar na caixa de entrada, ou sempre que a seleção anterior
      // deixa de ser válida (filtro de categoria mudou, mensagem arquivada), salta para a
      // mensagem não lida mais antiga em vez da mais recente. A ORDEM DE EXIBIÇÃO da lista
      // (mais nova no topo, mais antiga no fundo) não muda — só a ordem de leitura.
      const unreadActive = active.filter(n=>!n.read);
      const oldestUnread = unreadActive.length ? emailsByReadingOrder(unreadActive)[0] : null;
      newsSelectedIdx = oldestUnread ? state.news.indexOf(oldestUnread) : (activeIdxs.length ? activeIdxs[0] : null);
    }
    // Abrir uma mensagem no painel de leitura marca-a como lida, quer a seleção venha de um
    // clique explícito na lista, do botão "Ler seguinte", ou desta seleção automática acima.
    if(newsSelectedIdx!=null && state.news[newsSelectedIdx] && !state.news[newsSelectedIdx].read){
      state.news[newsSelectedIdx].read = true;
    }
    const selectedNews = newsSelectedIdx!=null ? state.news[newsSelectedIdx] : null;
    // Correção (esclarecimento do utilizador, 2026-09-27, depois de uma primeira tentativa
    // trocada: "eu quero a mais nova no topo e ler da mais antiga, em baixo, para a mais nova
    // (no topo)") — a lista mostra-se sempre por ordem de CHEGADA (state.news, mais nova no
    // topo, mais antiga no fundo — nunca por ordem de leitura); é só a SELEÇÃO inicial e o botão
    // "Ler seguinte" que seguem a ordem de leitura (mais antiga primeiro, emailsByReadingOrder/
    // nextUnreadNews, acima), o que faz o painel de leitura "subir" a lista à medida que se lê —
    // exatamente o comportamento pretendido.
    const listHtml = active.length
      ? active.map(n=>emailRowHtml(n, state.news.indexOf(n), state.news.indexOf(n)===newsSelectedIdx)).join("")
      : '<div class="feed-empty" style="color:var(--texto-mute);font-style:italic;">Sem mensagens nesta categoria.</div>';
    let archivedHtml = "";
    if(archived.length){
      archivedHtml = `<details class="email-archive-section"><summary>${archived.length} arquivado(s)</summary>${archived.map(n=>emailRowHtml(n, state.news.indexOf(n), state.news.indexOf(n)===newsSelectedIdx)).join("")}</details>`;
    }
    box.innerHTML = `${filterHtml}
      <div class="email-app">
        <div class="email-list-pane">
          <div class="email-list">${listHtml}</div>
          ${archivedHtml}
        </div>
        <div class="email-reading-pane" id="emailReadingPane">${emailReadingPaneHtml(selectedNews, newsSelectedIdx)}</div>
      </div>`;
    const newListPane = box.querySelector(".email-list-pane");
    if(newListPane) newListPane.scrollTop = prevScrollTop;
    const sel = document.getElementById("newsFilterSelect");
    if(sel) sel.addEventListener("change", () => { newsInboxFilterKind = sel.value || null; newsSelectedIdx = null; renderNews(); });
    box.querySelectorAll("[data-news-row]").forEach(row => {
      row.addEventListener("click", () => {
        const idx = Number(row.getAttribute("data-news-row"));
        newsSelectedIdx = idx;
        if(state.news[idx] && !state.news[idx].read) state.news[idx].read = true;
        renderNews();
      });
    });
    box.querySelectorAll("[data-news-archive]").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        const idx = Number(btn.getAttribute("data-news-archive"));
        if(state.news[idx]){ state.news[idx].archived = !state.news[idx].archived; renderNews(); }
      });
    });
    box.querySelectorAll("[data-news-next]").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.preventDefault(); e.stopPropagation();
        const idx = Number(btn.getAttribute("data-news-next"));
        if(state.news[idx]){ newsSelectedIdx = idx; renderNews(); }
      });
    });
    updateEmailNavBadge();
  }

  // ---- View navigation ----
  function setView(view, _isBack){
    // Correção (pedido do utilizador: "quero um botão de voltar atrás para poder navegar mais
    // naturalmente no jogo... saio da carreira para o calendário, devo ter um botão com seta para
    // a esquerda para voltar à carreira"): state.previousView guardava sempre o PRÓPRIO `view`
    // novo (não o antigo), ficando sempre igual a state.activeView — nunca foi lido em lado
    // nenhum, era código morto. Passa a existir um histórico real (state.viewHistory) empilhado a
    // cada navegação genuína (nunca quando se entra/sai de "jogo", nem quando é o próprio
    // goBackView a chamar setView, para não criar um ciclo infinito ida-e-volta entre as duas
    // últimas vistas).
    if(!_isBack && view!==state.activeView && state.activeView!=="jogo" && view!=="jogo"){
      if(!Array.isArray(state.viewHistory)) state.viewHistory=[];
      state.viewHistory.push(state.activeView);
      if(state.viewHistory.length>20) state.viewHistory.shift();
    }
    if(view!=="jogo") state.previousView = view;
    state.activeView = view;
    document.querySelectorAll(".hub-view").forEach(v => v.classList.add("hidden"));
    const map = { staff:"viewStaff", jogador:"viewJogador", clube:"viewClube", plantel:"viewPlantel", taticas:"viewTaticas", competicoes:"viewCompeticoes", calendario:"viewCalendario", noticias:"viewNoticias", historico:"viewHistorico", financas:"viewFinancas", mercado:"viewMercado", direcao:"viewDirecao", carreira:"viewCarreira", jogo:"viewJogo", ficha:"viewFicha" };
    document.getElementById(map[view]).classList.remove("hidden");
    document.querySelectorAll(".hub-nav-btn").forEach(b => b.classList.toggle("active", b.getAttribute("data-view")===view));
    document.querySelector(".hub-bar").classList.toggle("hidden", view==="jogo");
    document.querySelector(".hub-nav").classList.toggle("hidden", view==="jogo");
    document.querySelector(".topbar").classList.toggle("hidden", view==="jogo");
    document.body.classList.toggle("match-view-active", view==="jogo");
    const contextTitles = { staff:"Staff Técnico", jogador:"Ficha de Jogador", clube:"Centro do Clube", plantel:"Plantel", taticas:"Táticas", competicoes:"Competições", calendario:"Calendário", noticias:"E-mail", historico:"Histórico de Eventos", financas:"Finanças e Informação", mercado:"Mercado", direcao:"Direção", carreira:"Carreira do Treinador", jogo:"Dia de Jogo", ficha:"Ficha do Clube" };
    const contextTitleEl = document.getElementById("cm3ContextTitle");
    const contextMetaEl = document.getElementById("cm3ContextMeta");
    if(contextTitleEl) contextTitleEl.textContent = contextTitles[view] || "Hóquei Manager";
    if(contextMetaEl) contextMetaEl.textContent = state.userTeamId && state.teams[state.userTeamId] ? `${state.teams[state.userTeamId].name} · ${competitionLabel(state.userCompetitionId)} · Época ${seasonLabel(state.season)}` : "Competições Nacionais";
    if(view==="noticias") renderNews();
    if(view==="historico") renderEventosHistorico();
    if(view==="clube") renderClubeView();
    if(view==="plantel"){ resetRosterSort(); renderRoster(); }
    if(view==="financas") renderFinances();
    if(view==="mercado") renderTransferMarket();
    if(view==="direcao") renderDirectionPanel();
    if(view==="taticas") renderTaticasView();
    if(view==="competicoes") renderCompetitionView();
    if(view==="calendario") renderCalendarioView();
    if(view==="carreira") renderManagerCareerPanel();
    if(view==="staff" && typeof renderStaffPanel==="function") renderStaffPanel();
    if(view==="ficha") renderClubFichaView();
    syncBackButtonVisibility();
  }
  function syncBackButtonVisibility(){
    const btn = document.getElementById("backViewBtn");
    const innerBack = state.activeView==="jogador" && typeof playerModalHistory!=="undefined" && playerModalHistory.length;
    if(btn) btn.classList.toggle("hidden", !((state.viewHistory||[]).length || innerBack));
  }
  function goBackView(){
    // Ficha de jogador: primeiro volta ao jogador anterior (navegação entre colegas), só depois à vista anterior.
    if(state.activeView==="jogador" && typeof playerModalHistory!=="undefined" && playerModalHistory.length){ goBackPlayerModal(); return; }
    const prev = (state.viewHistory||[]).pop();
    if(prev) setView(prev, true);
  }
  document.querySelectorAll(".hub-nav-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const view = btn.getAttribute("data-view");
      // Correção (2026-09-09): sempre que o menu "Competições" é aberto a partir da navegação
      // principal (em vez de um salto direto para a competição de um clube específico, que já
      // define viewedCompetitionId antes de chamar setView), repõe-se para null — renderCompetitionView
      // cai de volta no país e na competição onde o utilizador está a jogar, tal como pedido.
      if(view==="competicoes") { state.viewedCompetitionId = null; state.viewedArchive = null; }
      setView(view); document.body.classList.remove("cm3-nav-open");
    });
  });
  const cm3NavToggle = document.getElementById("cm3NavToggle");
  if(cm3NavToggle){
    cm3NavToggle.addEventListener("click", () => document.body.classList.toggle("cm3-nav-open"));
  }
  const backViewBtn = document.getElementById("backViewBtn");
  if(backViewBtn){
    backViewBtn.addEventListener("click", () => goBackView());
  }
  // Academia e Juvenis (Fase 6, 2026-09-22, decisão 6 do utilizador): o ecrã "Resumo" mantém-se
  // tal como está, ganhando só este botão para a nova Ficha do Clube em página inteira.
  const verFichaCompletaBtn = document.getElementById("verFichaCompletaBtn");
  if(verFichaCompletaBtn){
    verFichaCompletaBtn.addEventListener("click", () => openClubFicha(state.userTeamId));
  }

  function renderClubeView(){
    const club = myTeam();
    if(!club) return;
    document.getElementById("clubeSeasonLabel").textContent = `Época ${seasonLabel(state.season)}`;
    if(state.activeView==="clube") state.resumoVisitaData = state.currentDate ? new Date(state.currentDate).getTime() : null;
    if(typeof renderResumoDashboard==="function") renderResumoDashboard(club);
    syncTaticasUI();
  }

  // Fase 16: Resumo passa a mostrar informação e notícias (posição, forma, condição do
  // plantel, situação financeira e alertas), em vez de configuração tática — essa mudou-se
  // para o Plantel (predefinição) e para a Escalação (decisão jogo a jogo).
  function renderClubeSummaryExtras(club){
    const box = document.getElementById("clubeSummaryExtras");
    if(!box) return;
    const userComp = club.id===state.userTeamId ? state.competitions[state.userCompetitionId] : null;
    const comp = (userComp && userComp.teamIds.includes(club.id)) ? userComp : Object.values(state.competitions).find(c=>c.teamIds.includes(club.id));
    const table = comp ? standingsForCompetition(comp.id) : [];
    const pos = table.findIndex(t=>t.id===club.id);
    const posLabel = pos>=0 ? `${pos+1}.º lugar · ${table[pos].stats.Pts} pts` : "—";
    const form = (club.recentResults||[]).slice(-5);
    const formHtml = form.length
      ? form.map(r=>`<span class="form-pill form-${r==='V'?'win':r==='E'?'draw':'loss'}">${r}</span>`).join("")
      : '<span class="helptext">Sem jogos ainda</span>';
    const avgCondicao = club.players.length ? Math.round(club.players.reduce((s,p)=>s+(p.condicao!=null?p.condicao:100),0)/club.players.length) : 100;
    initClubFinance(club);
    const saldo = club.financeiro.saldo;
    const orcamentoTransf = club.financeiro.orcamentoTransferencias||0;

    const alerts = [];
    const expiringContracts = club.players.filter(p=>p.contrato && isFinalContractYear(p)).length;
    if(expiringContracts) alerts.push(`${expiringContracts} contrato${expiringContracts>1?'s':''} a terminar esta época`);
    const pendingOffers = (state.aiOffers||[]).filter(o=>o.toTeamId===club.id && o.status==="pendente").length;
    if(pendingOffers) alerts.push(`${pendingOffers} proposta${pendingOffers>1?'s':''} recebida${pendingOffers>1?'s':''} no mercado`);
    const suspended = club.players.filter(p=>(p.suspensoJogos||0)>0).length;
    if(suspended) alerts.push(`${suspended} jogador${suspended>1?'es':''} suspenso${suspended>1?'s':''}`);
    const injured = club.players.filter(p=>(p.diasLesao||0)>0).length;
    if(injured) alerts.push(`${injured} jogador${injured>1?'es':''} lesionado${injured>1?'s':''}`);
    const unhappy = club.players.filter(p=>(p.satisfacao!=null?p.satisfacao:70)<40).length;
    if(unhappy) alerts.push(`${unhappy} jogador${unhappy>1?'es':''} descontente${unhappy>1?'s':''}`);
    const loansEnding = club.players.filter(p=>p.emprestimo && p.emprestimo.returnSeason<=state.season+1).length;
    if(loansEnding) alerts.push(`${loansEnding} empréstimo${loansEnding>1?'s':''} a terminar no fim da época`);

    box.innerHTML = `
      <div class="stat-row stat-row-5">
        <div class="stat-mini"><div class="eyebrow">Posição</div><div class="stat-mini-value">${posLabel}</div></div>
        <div class="stat-mini"><div class="eyebrow">Forma recente</div><div class="stat-mini-form">${formHtml}</div></div>
        <div class="stat-mini"><div class="eyebrow">Condição do plantel</div><div class="stat-mini-value">${avgCondicao}%</div></div>
        <div class="stat-mini"><div class="eyebrow">Saldo do clube</div><div class="stat-mini-value">${fmtMoney(saldo)}</div></div>
        <div class="stat-mini"><div class="eyebrow">Orçamento de transferências</div><div class="stat-mini-value">${fmtMoney(orcamentoTransf)}</div></div>
      </div>
      ${alerts.length ? `<div class="eyebrow section-label">Alertas</div><ul class="alert-list">${alerts.map(a=>`<li>${a}</li>`).join("")}</ul>` : ''}
      <div class="eyebrow section-label">Últimas mensagens</div>
      <div id="clubeSummaryNews" class="email-list email-list-compact"></div>
      <button class="btn btn-ghost" id="clubeSeeAllNewsBtn" style="margin-top:10px;">Abrir caixa de e-mail</button>
    `;
    document.getElementById("clubeSummaryNews").innerHTML = state.news.slice(0,5).map(n => emailRowHtml(n, null, false)).join("") || '<div class="feed-empty" style="font-style:italic;">Ainda sem notícias.</div>';
    const seeAllBtn = document.getElementById("clubeSeeAllNewsBtn");
    if(seeAllBtn) seeAllBtn.addEventListener("click", () => setView("noticias"));
  }

  // Ponto único de sincronização visual das táticas (Fase A: Sistema/Mentalidade/Pressão) —
  // como as mesmas classes e atributos (data-sistema/data-mentalidade/data-pressao) são
  // partilhadas pelo separador Táticas e pelo painel ao vivo, uma única passagem por todo o
  // documento mantém as duas cópias sempre coerentes com myTeam().sistema/mentalidade/pressao.
  function syncTaticasUI(){
    const team = myTeam();
    if(!team) return;
    document.querySelectorAll("[data-sistema]").forEach(b=>b.classList.toggle("active", b.getAttribute("data-sistema")===team.sistema));
    document.querySelectorAll("[data-mentalidade]").forEach(b=>b.classList.toggle("active", b.getAttribute("data-mentalidade")===team.mentalidade));
    document.querySelectorAll("[data-pressao]").forEach(b=>b.classList.toggle("active", b.getAttribute("data-pressao")===team.pressao));
    const defesaAtual = typeof defesaTipo==="function" ? defesaTipo(team) : "zona";
    document.querySelectorAll("[data-defesa]").forEach(b=>b.classList.toggle("active", b.getAttribute("data-defesa")===defesaAtual));
    if(typeof defesaSyncHelp==="function") defesaSyncHelp();
    const transAtual = typeof transicaoTipo==="function" ? transicaoTipo(team) : "equilibrada";
    document.querySelectorAll("[data-transicao]").forEach(b=>b.classList.toggle("active", b.getAttribute("data-transicao")===transAtual));
    if(typeof transicaoSyncHelp==="function") transicaoSyncHelp();
    document.querySelectorAll("[data-treino]").forEach(b=>b.classList.toggle("active", b.getAttribute("data-treino")===(team.treinoTaticoEscolhido||"nenhum")));
    liveTacSyncHints(team, defesaAtual, transAtual);
  }
  // 0.4.6: separador Táticas da partida — uma linha de ajuda por grupo, a explicar a opção activa.
  const LIVE_TAC_HINTS = {
    sistema:{"3-1":"Três atrás e um avançado de referência.","2-2":"Dois defesas e dois avançados.","1-2-1":"Losango: um fixo, dois alas e um pivot."},
    mentalidade:{defensivo:"Prioriza não sofrer: menos risco, menos remates.",equilibrado:"Equilíbrio entre atacar e defender.",ofensivo:"Mais gente no ataque: mais remates, mais espaço atrás."},
    pressao:{baixa:"Poupa energia e espera o adversário.",media:"Pressão moderada, desgaste normal.",alta:"Pressiona alto: recupera mais bolas, cansa mais."},
    defesa:{zona:"Cada jogador cobre uma zona.",individual:"Marcação homem-a-homem: mais agressiva.",mista:"Combina zona e marcação individual."},
    transicao:{direta:"Contra-ataque rápido, poucos passes.",equilibrada:"Mistura ataque rápido e construção.",apoiada:"Constrói com calma, mais passes."}
  };
  function liveTacSyncHints(team, defesaAtual, transAtual){
    const cur = { sistema:team.sistema, mentalidade:team.mentalidade, pressao:team.pressao, defesa:defesaAtual, transicao:transAtual };
    document.querySelectorAll(".lt-hint[data-hint-for]").forEach(el=>{
      const k = el.getAttribute("data-hint-for");
      el.textContent = (LIVE_TAC_HINTS[k] && LIVE_TAC_HINTS[k][cur[k]]) || "";
    });
  }
  function setTeamTreino(escolha){
    const team = myTeam(); if(!team) return;
    team.treinoTaticoEscolhido = escolha==="nenhum" ? null : escolha;
    syncTaticasUI();
  }
  function setTeamSistema(sistema){
    const team = myTeam(); if(!team) return;
    team.sistema = sistema;
    syncTaticasUI();
    if(typeof tacPistaRefresh === "function") tacPistaRefresh();
    if(typeof tacLiveRefresh === "function") tacLiveRefresh();
  }
  function setTeamMentalidade(mentalidade){
    const team = myTeam(); if(!team) return;
    team.mentalidade = mentalidade;
    syncTaticasUI();
  }
  function setTeamDefesa(defesa){
    const team = myTeam(); if(!team) return;
    team.defesa = defesa;
    syncTaticasUI();
  }
  function setTeamTransicao(transicao){
    const team = myTeam(); if(!team) return;
    team.transicao = transicao;
    syncTaticasUI();
  }
  function setTeamPressao(pressao){
    const team = myTeam(); if(!team) return;
    team.pressao = pressao;
    syncTaticasUI();
  }

  // Fase A: separador Táticas — Sistema (3-1/2-2), Mentalidade e Pressão num único sítio,
  // com a adequação do plantel a cada sistema (secção 7 do documento) calculada a partir de
  // posições, atributos, condição e satisfação dos jogadores disponíveis — nunca um valor
  // manual nem aleatório.
  function renderTaticasView(){
    const team = myTeam();
    const box = document.getElementById("taticasContent");
    if(!box || !team) return;
    document.getElementById("taticasSeasonLabel").textContent = `Época ${seasonLabel(state.season)}`;
    const fit31 = Math.round(systemFitScore(team, "3-1"));
    const fit22 = Math.round(systemFitScore(team, "2-2"));
    const fit121 = Math.round(systemFitScore(team, "1-2-1"));
    box.innerHTML = `
      ${typeof tacPistaHtml === "function" ? tacPistaHtml(team) : `<div class="eyebrow" style="margin-bottom:8px;">Sistema</div>
      <div class="tactic-row" id="sistemaRow">
        <button class="tactic-btn" data-sistema="3-1">3-1</button>
        <button class="tactic-btn" data-sistema="2-2">2-2</button>
      </div>`}

      <div class="eyebrow" style="margin-bottom:8px;">Mentalidade</div>
      <div class="tactic-row" id="mentalidadeRow">
        <button class="tactic-btn" data-mentalidade="defensivo">Defensiva</button>
        <button class="tactic-btn" data-mentalidade="equilibrado">Equilibrada</button>
        <button class="tactic-btn" data-mentalidade="ofensivo">Ofensiva</button>
      </div>
      <p class="helptext" style="margin:6px 0 16px;">Defensiva: menos risco, menos remates, menor exposição a transições. Ofensiva: mais participação e remates, mais risco e desgaste. Independente do sistema — um 3-1 pode ser ofensivo, um 2-2 pode ser defensivo.</p>

      <div class="eyebrow" style="margin-bottom:8px;">Pressão</div>
      <div class="tactic-row" id="pressaoRow">
        <button class="tactic-btn" data-pressao="baixa">Baixa</button>
        <button class="tactic-btn" data-pressao="media">Média</button>
        <button class="tactic-btn" data-pressao="alta">Alta</button>
      </div>
      <p class="helptext" style="margin-top:6px;">Alta: mais recuperações em zonas avançadas, mais transições, mas mais desgaste e mais risco de faltas/cartões. Baixa: menos desgaste, mas mais espaço concedido ao adversário para construir.</p>

      <div class="eyebrow" style="margin:16px 0 8px;">Defesa</div>
      <div class="tactic-row" id="defesaRow">
        <button class="tactic-btn" data-defesa="zona">Zona</button>
        <button class="tactic-btn" data-defesa="individual">Individual</button>
        <button class="tactic-btn" data-defesa="mista">Mista</button>
      </div>
      <p class="helptext" id="defesaHelp" style="margin-top:6px;"></p>

      <div class="eyebrow" style="margin:16px 0 8px;">Transição</div>
      <div class="tactic-row" id="transicaoRow">
        <button class="tactic-btn" data-transicao="direta">Contra-ataque direto</button>
        <button class="tactic-btn" data-transicao="equilibrada">Equilibrado</button>
        <button class="tactic-btn" data-transicao="apoiada">Construção apoiada</button>
      </div>
      <p class="helptext" id="transicaoHelp" style="margin-top:6px;"></p>

      <div class="eyebrow" style="margin:20px 0 8px;">Identidade tática do clube</div>
      <p class="helptext" style="margin-bottom:16px;">Sistema principal: <b>${team.identidadeSistemaPrincipal||'—'}</b> · secundário: <b>${team.identidadeSistemaSecundario||'—'}</b> · pressão preferencial: <b>${{baixa:'Baixa',media:'Média',alta:'Alta'}[team.identidadePressaoPreferencial]||'—'}</b> · mentalidade preferencial: <b>${{defensivo:'Defensiva',equilibrado:'Equilibrada',ofensivo:'Ofensiva'}[team.identidadeMentalidadePreferencial]||'—'}</b>. É a filosofia histórica do clube — a IA usa-a como âncora estável, só se desviando por lesões, suspensões, resultado ou adversário.</p>

      <div class="eyebrow" style="margin-bottom:8px;">Familiaridade tática</div>
      <div class="tactic-fit-grid" style="margin-bottom:10px;">
        <div class="tactic-fit-box"><div class="eyebrow">Familiaridade 3-1</div><div class="tactic-fit-value">${Math.round(team.familiaridade31!=null?team.familiaridade31:50)}/100</div></div>
        <div class="tactic-fit-box"><div class="eyebrow">Familiaridade 2-2</div><div class="tactic-fit-value">${Math.round(team.familiaridade22!=null?team.familiaridade22:50)}/100</div></div>
        <div class="tactic-fit-box"><div class="eyebrow">Familiaridade 1-2-1</div><div class="tactic-fit-value">${Math.round(famOf(team,"1-2-1"))}/100</div></div>
      </div>
      <p class="helptext" style="margin-bottom:16px;">80+: bónus de organização, circulação e cobertura defensiva. Abaixo de 50: mais perdas de bola, erros posicionais e menor eficácia ofensiva/defensiva. Entre os dois, sem efeito.</p>

      <div class="eyebrow" style="margin-bottom:8px;">Treino tático desta semana</div>
      <div class="tactic-row" id="treinoRow">
        <button class="tactic-btn" data-treino="nenhum">Nenhum</button>
        <button class="tactic-btn" data-treino="3-1">Treinar 3-1</button>
        <button class="tactic-btn" data-treino="2-2">Treinar 2-2</button>
        <button class="tactic-btn" data-treino="1-2-1">Treinar 1-2-1</button>
      </div>
      <p class="helptext" style="margin-top:6px;">A escolha mantém-se até a mudares. Reforça o sistema treinado (+0,5/semana) e reduz ligeiramente os outros (-0,1/semana cada). Sem escolha, a familiaridade não muda.</p>
      ${renderMarcadoresHtml(team)}
    `;
    if(typeof tacPistaRefresh === "function") tacPistaRefresh();
    syncTaticasUI();
  }

  // Calibração salarial por divisão (dados reais do hóquei em patins português, pedido do
  // utilizador 2026-09-05): a realidade financeira entre divisões é muito mais díspar do que o
  // nível dos jogadores por si só sugere — o mesmo jogador ganha ordens de grandeza menos numa
  // divisão amadora do que no escalão principal, porque é a divisão (audiência, patrocínio,
  // bilheteira), não só a qualidade do jogador, que determina o que um clube pode pagar. As
  // gamas de OVR por divisão ancoram-se na gama REAL observada em jogo (não na escala teórica
  // de atributos 0-20, que quase nenhum jogador chega sequer a metade): Placard ~8-17,
  // 2ª Divisão ~6-13, 3ª Divisão ~3-9.
  // Correção (pedido do utilizador 2026-09-05, a jogar com o HC Turquel): "os salários da segunda
  // divisão estão altos. ganhar 1.500 já é bom... há jogadores a 3.000." O teto da 2ª Divisão
  // (span, já que base=0 aqui) desce de 3.000€ para 1.800€ — a mesma curva (1.3), só mais
  // comprimida: um jogador muito bom, perto do topo do escalão, ronda agora os 1.400€-1.500€; só
  // o OVR máximo absoluto do escalão chega aos 1.800€.
  const DIVISION_SALARY_PROFILE = Object.freeze({
    placard: { ovrLo:8, ovrHi:17, base:500, span:4500, curve:1.3, repFloor:45, repSpan:55, repBonusMax:15000, repCurve:1.3 },
    // OK Liga (2026-09-06): sem esta entrada, divisionSalaryProfile caía no valor por omissão
    // ("2div", 0-1.800€) para uma 1ª divisão estrangeira — claramente errado. Usa a mesma curva
    // do Placard, escalada a -15%, o mesmo diferencial de reputação de liga que o utilizador
    // indicou (ver reputacaoCompeticao da OK Liga, 02-estado.js).
    "ok-liga": { ovrLo:8, ovrHi:17, base:425, span:3825, curve:1.3, repFloor:45, repSpan:55, repBonusMax:12750, repCurve:1.3 },
    // Serie A1 (2026-09-06, italiana): sem esta entrada, cairia no mesmo valor por omissão errado
    // que a OK Liga caía antes de ter a sua própria entrada. Mesma curva do Placard, escalada a
    // -15% sobre a OK Liga (0.85 x 0.85 = 0.7225), o mesmo diferencial que o utilizador indicou
    // para a reputação da liga (ver reputacaoCompeticao da Serie A1, 02-estado.js).
    "serie-a1": { ovrLo:8, ovrHi:17, base:361, span:3251, curve:1.3, repFloor:45, repSpan:55, repBonusMax:10838, repCurve:1.3 },
    "2div":  { ovrLo:6, ovrHi:13, base:0,   span:1800, curve:1.3, repFloor:0,  repSpan:0,  repBonusMax:0,     repCurve:1 },
    // freeThreshold: na 3ª divisão a esmagadora maioria dos jogadores joga sem remuneração
    // (amadorismo real) — só quem se destaca claramente acima da média do escalão (OVR na
    // metade superior da gama observada) chega sequer a receber uma ajuda de custo. Sem este
    // corte, uma curva contínua a partir de OVR mínimo dava sempre algum valor a quase todos,
    // o que não reflecte a realidade "grande parte 0€" pedida.
    "3div":  { ovrLo:3, ovrHi:12, base:0, span:600, curve:1.3, freeThreshold:0.55, repFloor:0, repSpan:0, repBonusMax:0, repCurve:1 },
  });
  function divisionSalaryProfile(divisao){ return DIVISION_SALARY_PROFILE[divisao] || DIVISION_SALARY_PROFILE["2div"]; }
  // Estimativa de salário "justo" para um jogador com este OVR/reputação/idade, na divisão dada.
  // Só o Placard tem bandas "Internacional"/"Estrela mundial" (5000-20000€+) — inatingíveis só
  // pelo OVR (que na prática nunca passa de ~17 nesta divisão); exigem reputação de jogador já
  // distinta (títulos, internacionalizações, jogos disputados) — um jogador só se torna
  // verdadeiramente reconhecido ao longo de uma carreira, não à nascença de uma nova carreira de
  // gestor. É por isto normal (e realista) uma carreira nova não ter ainda nenhum jogador nessas
  // duas bandas superiores — vão aparecendo à medida que jogadores se destacam em jogo.
  function divisionSalaryEstimate(ovr, reputacaoJogador, age, divisao){
    const profile = divisionSalaryProfile(divisao);
    const t = clamp((ovr-profile.ovrLo)/Math.max(1,profile.ovrHi-profile.ovrLo), 0, 1);
    let salary;
    if(profile.freeThreshold && t<=profile.freeThreshold){
      salary = profile.base;
    } else {
      const tt = profile.freeThreshold ? (t-profile.freeThreshold)/(1-profile.freeThreshold) : t;
      salary = profile.base + Math.pow(tt, profile.curve)*profile.span;
    }
    if(profile.repBonusMax){
      const repT = clamp(((reputacaoJogador||0)-profile.repFloor)/Math.max(1,profile.repSpan), 0, 1);
      salary += Math.pow(repT, profile.repCurve)*profile.repBonusMax;
    }
    if(age>31) salary = Math.max(0, salary-(age-31)*40);
    return Math.max(0, Math.round(salary/50)*50);
  }
  // Contrato completo (Fase 12): salário mensal, duração, datas de início/fim e papel
  // prometido no plantel. opts permite personalizar qualquer campo (ex.: negociação,
  // renovação, pré-contrato) mantendo o mesmo gerador como fonte única da verdade.
  function generateContract(ovr, age, opts){
    opts = opts || {};
    // opts.divisao (nova): usa a tabela salarial por divisão acima. Sem ele (chamadas antigas
    // não tocadas nesta calibração), mantém a fórmula original — só ligada ao OVR, sem qualquer
    // noção de divisão. opts.salarioMensal (negociação/importação explícita) continua sempre a
    // ganhar a ambas.
    const salarioMensal = opts.salarioMensal!=null ? Math.max(0,Math.round(opts.salarioMensal))   // 0.4.9: 0 € é válido (3.ª divisão); o piso por divisão já é aplicado em contractDemand/expectedSalary
      : opts.divisao ? divisionSalaryEstimate(ovr, opts.reputacaoJogador||0, age, opts.divisao)
      : Math.max(450, Math.round((ovr-8)*545 - (age>31 ? (age-31)*40 : 0)));
    const anos = opts.anos!=null ? opts.anos : randomContractYears(opts.rng);
    const dataInicio = opts.dataInicio || (state.currentDate ? isoDate(state.currentDate) : "2026-08-01");
    const dataFim = addYearsIso(dataInicio, anos);
    const papel = opts.papel || assignInitialRole(ovr, age, opts.potential!=null?opts.potential:ovr, !!opts.titular);
    return { salarioMensal, anos, dataInicio, dataFim, papel };
  }
  // Linha (Avançado / Defesa-Médio): não muda a lista de atributos, só desvia os valores
  // gerados — Avançados pendem para os atributos ofensivos, Defesas/Médios para os defensivos.
  const LINHA_BIAS = {
    Avancado: { finalizacao:3, aceleracao:3, velocidade:3, drible:2, criatividade:2, habilidade:2,
                desarme:-3, agressividade:-1, posicionamento:-2, forca:-1, meiaDistancia:-1 },
    DefesaMedio: { desarme:3, agressividade:2, posicionamento:3, forca:2, meiaDistancia:2,
                finalizacao:-3, aceleracao:-2, velocidade:-2, drible:-1, criatividade:-1 },
  };
  function applyLinhaBias(attrs, linha){
    const bias = LINHA_BIAS[linha];
    if(!bias) return attrs;
    Object.keys(bias).forEach(k=>{ if(attrs[k]!=null) attrs[k] = clampAttr(attrs[k]+bias[k]); });
    return attrs;
  }

  function makeOutfieldPlayer(id, num, name, base, divisao, pais){
    const rng = makeSeededRng(id+"|"+name);
    const linha = seededRnd(rng,0,1)===0 ? "Avancado" : "DefesaMedio";
    const attrs = applyLinhaBias({
      habilidade: clampAttr(base+seededRnd(rng,-2,2)),
      drible: clampAttr(base+seededRnd(rng,-2,2)),
      criatividade: clampAttr(base+seededRnd(rng,-2,2)),
      finalizacao: clampAttr(base+seededRnd(rng,-3,3)),
      bolasParadas: clampAttr(base+seededRnd(rng,-3,3)),
      meiaDistancia: clampAttr(base+seededRnd(rng,-3,3)),
      posicionamento: clampAttr(base+seededRnd(rng,-2,2)),
      desarme: clampAttr(base+seededRnd(rng,-3,3)),
      forca: clampAttr(base+seededRnd(rng,-2,2)),
      velocidade: clampAttr(base+seededRnd(rng,-3,3)),
      aceleracao: clampAttr(base+seededRnd(rng,-3,3)),
      agressividade: clampAttr(seededRnd(rng,4,18)),
      determinacao: clampAttr(seededRnd(rng,6,18)),
      lideranca: clampAttr(seededRnd(rng,4,17)),
      resistencia: clampAttr(base+seededRnd(rng,-2,2)),
    }, linha);
    const age = seededRnd(rng,18,34);
    const dataNascimento = makeBirthDate(rng, age);
    const ovr = overallFromAttrs("J", attrs);
    const potential = age<=22 ? clampAttr(ovr+seededRnd(rng,1,4)) : age<=27 ? clampAttr(ovr+seededRnd(rng,0,2)) : clampAttr(ovr+seededRnd(rng,0,1));
    return {
      id, num, name, pos:"J", linha, age, dataNascimento, nacionalidade: nationalityForCountry(pais), paisOrigem: normalizeCountryCode(pais), attrs, potential,
      contrato: generateContract(ovr, age, { rng, potential, divisao }),
      preContrato: null,
      temperamento: TEMPERAMENTS[seededRnd(rng,0,TEMPERAMENTS.length-1)],
      moral: seededRnd(rng,55,80), satisfacao: seededRnd(rng,55,80), reputacaoJogador: 0,
      titular:false, suspensoJogos:0, diasLesao:0, condicao:100,
      season: createEmptyStats("season"),
      career: createEmptyStats("career"),
      historico: [], titulos: [], internacionalizacoes: 0, golosInternacional: 0,
    };
  }
  function makeGoalkeeper(id, num, name, base, divisao, pais){
    const rng = makeSeededRng(id+"|"+name);
    const attrs = {
      reflexos: clampAttr(base+seededRnd(rng,-2,2)),
      umParaUm: clampAttr(base+seededRnd(rng,-2,2)),
      agilidade: clampAttr(base+seededRnd(rng,-2,2)),
      concentracao: clampAttr(base+seededRnd(rng,-2,2)),
      meiaDistancia: clampAttr(base+seededRnd(rng,-3,3)),
      forca: clampAttr(base+seededRnd(rng,-2,2)),
      agressividade: clampAttr(seededRnd(rng,4,16)),
      determinacao: clampAttr(seededRnd(rng,6,18)),
      lideranca: clampAttr(seededRnd(rng,4,17)),
      resistencia: clampAttr(base+seededRnd(rng,-2,2)),
    };
    const age = seededRnd(rng,19,36);
    const dataNascimento = makeBirthDate(rng, age);
    const ovr = overallFromAttrs("GR", attrs);
    const potential = age<=23 ? clampAttr(ovr+seededRnd(rng,1,3)) : age<=29 ? clampAttr(ovr+seededRnd(rng,0,1)) : clampAttr(ovr+seededRnd(rng,0,1));
    return {
      id, num, name, pos:"GR", age, dataNascimento, nacionalidade: nationalityForCountry(pais), paisOrigem: normalizeCountryCode(pais), attrs, potential,
      contrato: generateContract(ovr, age, { rng, potential, divisao }),
      preContrato: null,
      temperamento: TEMPERAMENTS[seededRnd(rng,0,TEMPERAMENTS.length-1)],
      moral: seededRnd(rng,55,80), satisfacao: seededRnd(rng,55,80), reputacaoJogador: 0,
      titular:false, suspensoJogos:0, diasLesao:0, condicao:100,
      season: createEmptyStats("season"),
      career: createEmptyStats("career"),
      historico: [], titulos: [], internacionalizacoes: 0, golosInternacional: 0,
    };
  }

  // ============================= Reformas + Novas Gerações =============================
  // Nomes portugueses aleatórios para os jovens da formação — nunca clones de jogadores
  // existentes ("regens"), sempre gente nova.
  const PT_FIRST_NAMES = ["João","Diogo","Miguel","Pedro","Rodrigo","Tiago","André","Bruno","Carlos","Daniel","Duarte","Eduardo","Filipe","Francisco","Gonçalo","Guilherme","Henrique","Hugo","Ivo","Leonardo","Lourenço","Luís","Manuel","Marco","Mário","Martim","Mateus","Nuno","Rafael","Ricardo","Rui","Salvador","Samuel","Sérgio","Simão","Tomás","Vasco","Vicente","Alexandre","Bernardo"];
  const PT_LAST_NAMES = ["Silva","Santos","Ferreira","Pereira","Oliveira","Costa","Rodrigues","Martins","Jesus","Sousa","Fernandes","Gonçalves","Gomes","Lopes","Marques","Alves","Almeida","Ribeiro","Pinto","Carvalho","Teixeira","Moreira","Correia","Mendes","Nunes","Soares","Vieira","Monteiro","Cardoso","Rocha","Neves","Coelho","Cruz","Cunha","Pires","Ramos","Reis","Simões","Antunes","Matos","Machado","Barbosa","Tavares","Araújo"];
  function randomPortugueseName(rng){
    const r = () => rng ? rng() : Math.random();
    const first = PT_FIRST_NAMES[Math.floor(r()*PT_FIRST_NAMES.length)];
    let last1 = PT_LAST_NAMES[Math.floor(r()*PT_LAST_NAMES.length)];
    if(r()<0.4){
      let last2 = PT_LAST_NAMES[Math.floor(r()*PT_LAST_NAMES.length)];
      let guard=0; while(last2===last1 && guard<5){ last2 = PT_LAST_NAMES[Math.floor(r()*PT_LAST_NAMES.length)]; guard++; }
      return `${first} ${last1} ${last2}`;
    }
    return `${first} ${last1}`;
  }
  // Nomes espanhóis para os jovens da formação dos clubes da OK Liga (2026-09-06) — antes desta
  // correção, todos os clubes (incluindo os espanhóis) geravam sempre jovens com nomes e
  // nacionalidade portugueses, mesmo formados na própria academia de um clube de Espanha.
  const ES_FIRST_NAMES = ["Pol","Marc","Àlex","Iker","Pau","Martí","Adrià","Bruno","Gerard","Oriol","Nil","Guillem","Arnau","Roger","Jordi","Sergi","David","Xavi","Carles","Marçal","Enric","Ferran","Aleix","Biel","Eloi","Ivan","Joel","Lluc","Max","Neil"];
  const ES_LAST_NAMES = ["García","Martínez","López","Sánchez","Pérez","Gómez","Fernández","Ruiz","Díaz","Álvarez","Moreno","Muñoz","Romero","Navarro","Torres","Domínguez","Vázquez","Serrano","Blanco","Molina","Suárez","Ortiz","Delgado","Castro","Ortega","Rubio","Marín","Sanz","Iglesias","Medina"];
  function randomSpanishName(rng){
    const r = () => rng ? rng() : Math.random();
    const first = ES_FIRST_NAMES[Math.floor(r()*ES_FIRST_NAMES.length)];
    let last1 = ES_LAST_NAMES[Math.floor(r()*ES_LAST_NAMES.length)];
    let last2 = ES_LAST_NAMES[Math.floor(r()*ES_LAST_NAMES.length)];
    let guard=0; while(last2===last1 && guard<5){ last2 = ES_LAST_NAMES[Math.floor(r()*ES_LAST_NAMES.length)]; guard++; }
    return `${first} ${last1} ${last2}`;
  }
  // Nomes italianos para os jovens da formação/candidatos dos clubes da Serie A1 (2026-09-06) —
  // mesmo princípio já aplicado à OK Liga: um clube italiano forma jovens italianos, nunca
  // portugueses por omissão.
  const IT_FIRST_NAMES = ["Marco","Luca","Matteo","Andrea","Alessandro","Davide","Simone","Federico","Riccardo","Lorenzo","Gabriele","Nicolò","Francesco","Giacomo","Tommaso","Leonardo","Edoardo","Filippo","Stefano","Michele","Emanuele","Giulio","Samuele","Pietro","Enrico","Cristian","Fabio","Manuel","Daniele","Alberto"];
  const IT_LAST_NAMES = ["Rossi","Russo","Ferrari","Esposito","Bianchi","Romano","Colombo","Ricci","Marino","Greco","Bruno","Gallo","Conti","Costa","Giordano","Mancini","Rizzo","Lombardi","Moretti","Barbieri","Fontana","Santoro","Mariani","Rinaldi","Caruso","Ferrara","Galli","Martini","Leone","Longo"];
  function randomItalianName(rng){
    const r = () => rng ? rng() : Math.random();
    const first = IT_FIRST_NAMES[Math.floor(r()*IT_FIRST_NAMES.length)];
    let last1 = IT_LAST_NAMES[Math.floor(r()*IT_LAST_NAMES.length)];
    let last2 = IT_LAST_NAMES[Math.floor(r()*IT_LAST_NAMES.length)];
    let guard=0; while(last2===last1 && guard<5){ last2 = IT_LAST_NAMES[Math.floor(r()*IT_LAST_NAMES.length)]; guard++; }
    return `${first} ${last1} ${last2}`;
  }
  // Nomes franceses/alemães/ingleses para os clubes "nuvem" europeus (França/Alemanha/Suíça/
  // Inglaterra/Áustria — ver generatePlaceholderRoster, ensureEuropaNuvemClubes em 07g-europa.js).
  // Correção (pedido do utilizador, 2026-09-12): antes destes 3 países, randomNameForCountry caía
  // sempre no valor por omissão (nomes portugueses) para qualquer país que não fosse "es"/"it" —
  // um clube francês da nuvem tinha jogadores com nomes portugueses. Suíça/Áustria (sem língua
  // única própria nesta lista) reaproveitam alemão, o mais comum nos clubes reais destes dois
  // países na nuvem (ver EUROPA_NUVEM_CLUBES_REAIS).
  const FR_FIRST_NAMES = ["Lucas","Hugo","Léo","Nathan","Louis","Enzo","Gabriel","Raphaël","Arthur","Jules","Maxime","Théo","Antoine","Baptiste","Clément","Émile","Mathis","Noah","Valentin","Adrien","Rémi","Kevin","Yanis","Bastien","Julien","Thibault","Quentin","Florian","Romain","Alexis"];
  const FR_LAST_NAMES = ["Martin","Bernard","Dubois","Thomas","Robert","Richard","Petit","Durand","Leroy","Moreau","Simon","Laurent","Lefebvre","Michel","Garcia","David","Bertrand","Roux","Vincent","Fournier","Morel","Girard","André","Mercier","Blanc","Guerin","Boyer","Garnier","Chevalier","Francois"];
  function randomFrenchName(rng){
    const r = () => rng ? rng() : Math.random();
    const first = FR_FIRST_NAMES[Math.floor(r()*FR_FIRST_NAMES.length)];
    let last1 = FR_LAST_NAMES[Math.floor(r()*FR_LAST_NAMES.length)];
    let last2 = FR_LAST_NAMES[Math.floor(r()*FR_LAST_NAMES.length)];
    let guard=0; while(last2===last1 && guard<5){ last2 = FR_LAST_NAMES[Math.floor(r()*FR_LAST_NAMES.length)]; guard++; }
    return `${first} ${last1} ${last2}`;
  }
  const DE_FIRST_NAMES = ["Lukas","Leon","Finn","Paul","Felix","Jonas","Max","Tim","Niklas","Julian","Moritz","David","Jan","Tobias","Simon","Fabian","Sebastian","Florian","Daniel","Christian","Philipp","Markus","Stefan","Andreas","Michael","Matthias","Alexander","Benjamin","Dominik","Marcel"];
  const DE_LAST_NAMES = ["Müller","Schmidt","Schneider","Fischer","Weber","Meyer","Wagner","Becker","Schulz","Hoffmann","Koch","Bauer","Richter","Klein","Wolf","Schröder","Neumann","Schwarz","Zimmermann","Braun","Krüger","Hofmann","Lange","Schmitt","Werner","Krause","Meier","Lehmann","Huber","Mayer"];
  function randomGermanName(rng){
    const r = () => rng ? rng() : Math.random();
    const first = DE_FIRST_NAMES[Math.floor(r()*DE_FIRST_NAMES.length)];
    const last = DE_LAST_NAMES[Math.floor(r()*DE_LAST_NAMES.length)];
    return `${first} ${last}`;
  }
  const EN_FIRST_NAMES = ["James","Oliver","Jack","Harry","George","Noah","Charlie","Jacob","Thomas","Oscar","William","Henry","Leo","Alfie","Joshua","Freddie","Archie","Ethan","Joseph","Samuel","Daniel","Adam","Ryan","Matthew","Lewis","Callum","Connor","Liam","Dylan","Owen"];
  const EN_LAST_NAMES = ["Smith","Jones","Taylor","Brown","Williams","Wilson","Johnson","Davies","Robinson","Wright","Thompson","Evans","Walker","White","Roberts","Green","Hall","Wood","Jackson","Clarke","Harris","Cooper","King","Baker","Turner","Mitchell","Scott","Bell","Ward","Murphy"];
  function randomEnglishName(rng){
    const r = () => rng ? rng() : Math.random();
    const first = EN_FIRST_NAMES[Math.floor(r()*EN_FIRST_NAMES.length)];
    const last = EN_LAST_NAMES[Math.floor(r()*EN_LAST_NAMES.length)];
    return `${first} ${last}`;
  }
  // Nome aleatório por país — usado sempre que se gera um jovem da formação ou candidato, para
  // nunca haver mais do que um sítio a decidir "que nomes uso para este país".
  function randomNameForCountry(pais, rng){
    if(pais==="es") return randomSpanishName(rng);
    if(pais==="it") return randomItalianName(rng);
    if(pais==="fr") return randomFrenchName(rng);
    if(pais==="de" || pais==="ch" || pais==="at") return randomGermanName(rng);
    if(pais==="en") return randomEnglishName(rng);
    return randomPortugueseName(rng);
  }
  function findFreeNumber(team){
    const used = new Set(team.players.map(p=>p.num));
    for(let n=1;n<=99;n++) if(!used.has(n)) return n;
    return rnd(1,99);
  }
  // Academia e Juvenis (Fase 5, 2026-09-22): CLUB_FORMATION_QUALITY/initFormationQuality/
  // youthCountForFormation/generateYouthOutfield/generateYouthGoalkeeper/candidatePositionForNeed/
  // youthIntegrationLimit/recordYouthDecision/annualYouthReview/generateNewGeneration foram
  // removidas daqui — substituídas por completo por initAcademyLevel/academyIntakeCount/
  // generateAcademyOutfield/GK/academyPromotionLimit/runAcademySub19ExitPass/
  // runAcademyAnnualIntake em 08b-academia-juvenis.js. combinedStructureSnapshot fica aqui: é um
  // snapshot genérico do plantel A+B combinado, sem lógica de juvenis, reutilizado tal e qual
  // pelo governador de promoção da Academia (academyPromotionLimit/runAcademySub19ExitPass).
  function combinedStructureSnapshot(club){
    const b=club.equipaBId&&state.teams[club.equipaBId],players=club.players.concat(b?b.players:[]);
    const byPos={GR:players.filter(p=>p.pos==="GR").length,Avancado:players.filter(p=>p.linha==="Avancado").length,DefesaMedio:players.filter(p=>p.pos==="J"&&p.linha!=="Avancado").length};
    return {players,b,total:players.length,byPos,u18:players.filter(p=>p.age<=18).length,u21:players.filter(p=>p.age<=21).length,youngNoMinutes:players.filter(p=>p.age<=21&&(p.season?.jogos||0)===0).length,expiring:players.filter(p=>p.contrato&&isFinalContractYear(p)).length,financialSpace:club.financeiro?Math.max(0,(club.financeiro.limiteSalarial||0)-monthlyWageBill(club)):0};
  }
  // Probabilidade de reforma (secção 1): só avaliada a partir dos 34 anos. Combina utilização,
  // titularidade, forma recente, condição física, títulos conquistados e duração de contrato —
  // nunca uma idade fixa a decidir sozinha.
  // Estatísticas da época para decisões de fim de época (2026-10-16): closeCompletedSeasonPlayerStats
  // reinicia player.season ANTES das renovações, reformas e avaliação da direção (beginDefeso) —
  // essas decisões liam sempre 0 jogos. Durante essa janela usa-se a cópia da época fechada.
  function seasonStatsForDecision(p){
    if(p && p.__seasonFechada && p.__seasonFechadaEpoca===state.season) return p.__seasonFechada;
    return (p && p.season) || {};
  }
  function retirementProbability(player){
    if(player.age<34) return 0;
    const gamesSoFar = Math.max(1, state.currentRound||state.fixtures.length||26);
    const ss = seasonStatsForDecision(player);
    const usageRate = clamp((ss.jogos||0)/gamesSoFar,0,1);
    const ageFactor = clamp((player.age-34)*0.07,0,0.55);
    const usageFactor = (1-usageRate)*0.28;
    const titularFactor = player.titular ? -0.12 : 0.08;
    const formAvg = ss.notas&&ss.notas.length ? avg(ss.notas.slice(-8)) : 6;
    const formFactor = clamp((6-formAvg)*0.05,-0.10,0.18);
    const condicaoFactor = (player.condicao!=null && player.condicao<55) ? 0.08 : 0;
    const titulosFactor = -Math.min((player.titulos||[]).length*0.02, 0.10);
    const contratoLongoFactor = player.contrato && player.contrato.anos>=2 ? -0.05 : 0;
    return clamp(0.04+ageFactor+usageFactor+titularFactor+formFactor+condicaoFactor+titulosFactor+contratoLongoFactor, 0.01, 0.92);
  }
  function archiveRetiredPlayer(player, team){
    if(!Array.isArray(state.retiredPlayers)) state.retiredPlayers=[];
    const t=team||{id:null,name:"Sem clube"}, career=player.career||{}, season=player.season||{};
    const id=player.id||`legacy:${String(player.name||"jogador").toLowerCase().replace(/\s+/g,"-")}:${player.dataNascimento||seasonLabel(state.season)}`;
    const clubes=new Set((player.historico||[]).map(h=>h.clube).filter(Boolean));clubes.add(t.name||"Sem clube");
    const record={id,name:player.name,age:player.age,dataNascimento:player.dataNascimento||null,overallFinal:overall(player),reputacaoFinal:player.reputacaoJogador||0,clubeFinalId:t.id||null,clubeFinalNome:t.name||"Sem clube",pos:player.pos,linha:player.linha||null,clubes:Array.from(clubes),jogos:(career.jogos||0)+(season.jogos||0),golos:(career.golos||0)+(season.golos||0),assistencias:(career.assistencias||0)+(season.assistencias||0),titulos:Array.isArray(player.titulos)?player.titulos.slice():[],internacionalizacoes:player.internacionalizacoes||0,golosInternacional:player.golosInternacional||0,epocaReforma:seasonLabel(state.season)};
    const idx=state.retiredPlayers.findIndex(r=>r.id===id);if(idx>=0)state.retiredPlayers[idx]={...state.retiredPlayers[idx],...record};else state.retiredPlayers.unshift(record);
    if(Array.isArray(state.freeAgents))state.freeAgents=state.freeAgents.filter(x=>x.id!==id);
    if(state.contractNegotiations)delete state.contractNegotiations[id];if(state.transferNegotiations)delete state.transferNegotiations[id];
    if(Array.isArray(state.aiOffers))state.aiOffers=state.aiOffers.filter(o=>o.playerId!==id);return record;
  }
  // Fluxo de reformas (secções 1-4): primeiro efetiva as reformas já anunciadas para esta época
  // (retiringSeason===state.season, marcado no fim da época anterior), depois avalia novas
  // decisões de reforma para jogadores 34+ que ainda não têm nenhuma decisão tomada — essas só
  // produzem efeito no início da PRÓXIMA época (retiringSeason = state.season+1), continuando o
  // jogador a competir normalmente durante toda a época em que a reforma foi anunciada.
  // Correção (auditoria, bug alto #4): jogadores livres nunca eram avaliados para reforma nem
  // removidos por qualquer outro motivo — o array crescia indefinidamente (quase mil jogadores
  // ao fim de 20 épocas na simulação da auditoria). Reforma automática por idade/tempo sem
  // clube, mais um limite técnico ativo (mantém sempre os mais interessantes, arquiva o resto).
  const FREE_AGENT_CAP = 90;
  function archiveInactivePlayer(player, reason="excesso-mercado"){
    if(!Array.isArray(state.inactivePlayers)) state.inactivePlayers=[];
    const snapshot=JSON.parse(JSON.stringify(player));
    const id=player.id||`inactive:${String(player.name||"jogador").toLowerCase().replace(/\s+/g,"-")}:${player.dataNascimento||seasonLabel(state.season)}`;
    const ctx=player.freeAgentContext||{};
    const record={...snapshot,id,status:"inativo",inactiveReason:reason,inactiveSeason:seasonLabel(state.season),inactiveDate:isoDate(state.currentDate||new Date()),seasonsUnsigned:player.__seasonsUnsigned||0,lastClubId:ctx.formerTeamId||null,lastClubName:ctx.formerTeamName||"Sem clube",careerContext:JSON.parse(JSON.stringify(ctx)),contractPrevious:player.contrato?JSON.parse(JSON.stringify(player.contrato)):null};
    const idx=state.inactivePlayers.findIndex(x=>x.id===id);
    if(idx>=0) state.inactivePlayers[idx]={...state.inactivePlayers[idx],...record}; else state.inactivePlayers.unshift(record);
    if(Array.isArray(state.freeAgents)) state.freeAgents=state.freeAgents.filter(x=>x.id!==id);
    if(state.contractNegotiations) delete state.contractNegotiations[id];
    if(state.transferNegotiations) delete state.transferNegotiations[id];
    if(Array.isArray(state.aiOffers)) state.aiOffers=state.aiOffers.filter(o=>o.playerId!==id);
    return record;
  }
  function cleanupFreeAgentPool(){
    if(!Array.isArray(state.freeAgents)){ state.freeAgents=[]; return; }
    const kept=[]; let reformados=0;
    state.freeAgents.slice().forEach(p=>{
      p.__seasonsUnsigned=(p.__seasonsUnsigned||0)+1;
      const realRetirement=p.age>=34&&Math.random()<retirementProbability(p);
      if(realRetirement){archiveRetiredPlayer(p,{id:null,name:"Sem clube"});reformados++;}else kept.push(p);
    });
    // talentos de missões internacionais (08z) ficam protegidos até à época seguinte à descoberta
    const protegidos=kept.filter(p=>p.scint&&!p.scint.assinado&&(p.scint.protegidoAteEpoca||0)>=state.season);
    const restantes=kept.filter(p=>!protegidos.includes(p));
    restantes.sort((a,b)=>overall(b)-overall(a)||a.age-b.age);
    const activos=protegidos.concat(restantes.slice(0,Math.max(0,FREE_AGENT_CAP-protegidos.length))),excedentes=restantes.slice(Math.max(0,FREE_AGENT_CAP-protegidos.length));
    excedentes.forEach(p=>archiveInactivePlayer(p,"excesso-mercado"));
    state.freeAgents=activos;
    if(reformados||excedentes.length) pushNews(state.currentDate,`Mercado de jogadores livres: ${reformados} reforma(s) real(is), ${excedentes.length} jogador(es) passaram a inativos por excesso de mercado. Restam ${activos.length} jogadores livres.`,"sistema");
  }
  function processRetirements(){
    if(state.retirementsProcessedSeason===state.season) return;
    Object.values(state.teams).forEach(team=>{
      // Correção (2026-10-16): as seleções virtuais partilham os objetos dos jogadores dos clubes —
      // um convocado que se reforma era arquivado duas vezes (o 2.º arquivo trocava o clube final
      // pela seleção) e sorteado duas vezes para anunciar a reforma. Na seleção só sai da lista.
      if(team.selecaoNacional){ team.players = team.players.filter(p=>p.retiringSeason!==state.season); return; }
      team.players.slice().forEach(player=>{
        if(player.retiringSeason!==state.season) return;
        archiveRetiredPlayer(player, team);
        if(typeof staffFromRetiredPlayer==="function") staffFromRetiredPlayer(player, team);   // 0.4.26: ex-jogador pode virar treinador
        // Eventos Narrativos — Fase 3 ("A Lenda", 09b-eventos-narrativos.js): se quem se reforma
        // é a lenda do clube do utilizador, fecha o arco com uma retrospectiva antes de o remover
        // do plantel (archiveRetiredPlayer já correu, mas não remove — a remoção é já a seguir).
        if(team.id===state.userTeamId && state.lendaJogadorId===player.id) narrativeLendaReforma(team, player);
        team.players = team.players.filter(p=>p.id!==player.id);
        team.marketNeedDirty=true; // abriu uma lacuna real (reforma) — ver AI_MARKET_COOLDOWN_DAYS em runAiToAiMarketPass (04-financas.js)
        // Correção (pedido do utilizador, 2026-09-17: notícias com clubes/jogadores devem ser
        // clicáveis): o jogador já foi removido do plantel (linha acima) — playerLinkHtml
        // apontaria para um jogador inexistente, por isso só o clube fica clicável aqui.
        // Correção (pedido do utilizador, 2026-10-03: "recebi centenas de emails com informação
        // desnecessária: jogadores que vão terminar a carreira e nem estão na minha divisão") —
        // tal como já acontecia para "mercado" (newsIsFromUserDivision, mais abaixo), uma reforma
        // só é relevante para o utilizador se o clube em causa partilhar a sua divisão; caso
        // contrário são só ruído, sem nenhum jogador/clube do interesse direto do utilizador.
        if(newsIsFromUserDivision(team.name)) pushNews(state.currentDate, `${escapeHtml(player.name)} reforma-se, depois de ${(player.career.jogos||0)+(player.season.jogos||0)} jogos e ${(player.career.golos||0)+(player.season.golos||0)} golos ao serviço de ${teamLinkHtml(team.id)}.`, "juventude");
      });
    });
    Object.values(state.teams).forEach(team=>{
      if(team.selecaoNacional) return;
      team.players.forEach(player=>{
        if((player.pos!=="J" && player.pos!=="GR") || player.age<34 || player.retiringSeason!=null) return;
        if(Math.random()<retirementProbability(player)){
          player.retiringSeason = state.season+1;
          // Mesma filtragem por divisão do anúncio de reforma efetiva, acima.
          if(newsIsFromUserDivision(team.name)) pushNews(state.currentDate, `${playerLinkHtml(team.id,player)} (${teamLinkHtml(team.id)}) anuncia que vai terminar a carreira no final da próxima época.`, "juventude");
        }
      });
    });
    state.retirementsProcessedSeason = state.season;
  }

  // Nível-base de um plantel gerado por omissão (0-20, mesma escala dos atributos), para clubes
  // reais sem plantel importado. Correção (nuvem europeia, pedido do utilizador 2026-09-12): esta
  // mesma função também gera os planteis dos clubes "nuvem" europeus (França/Alemanha/Suíça/
  // Inglaterra/Áustria — ver ensureEuropaNuvemClubes, 07g-europa.js), que usavam sempre o mesmo
  // tier (2 ou 3, derivado da banda de reputação do país) e por isso o mesmo nível-base 13-14 — um
  // OVR de 13-15/20 é nível profissional sólido, claramente exagerado para uma prova cujas próprias
  // bandas de reputação (EUROPA_REP_BANDS) nunca chegam a "candidato europeu" e vão até aos 40 nos
  // países mais fracos. Substituído por uma escala contínua a partir da reputação real de CADA
  // clube da nuvem (nunca só duas categorias), claramente mais baixa em toda a banda.
  function nuvemPlaceholderBase(reputacao){
    const r = clamp(Number(reputacao)||40, 40, 80);
    return 4 + (r-40)/40*8; // 40 rep -> base 4 (claramente amador); 80 rep -> base 12 (modesto, nunca profissional)
  }
  // Nível-base dos 14 clubes da Serie A1 (Itália), gerados por omissão (sem plantel real
  // importado — ver REAL_ROSTERS/generatePlaceholderRoster). Correção (pedido do utilizador
  // 2026-09-14: "os jogadores da liga italiana estao absurdamente bons"): os 14 clubes tinham
  // TODOS tier=1 na base de dados, apesar de terem reputações reais e bem distintas (50 a 84) —
  // por isso geravam todos o mesmo nível-base fixo (tierBaseLevel(1)=16, qualidade de estrela),
  // sem qualquer relação com a reputação de cada clube (confirmado: média de OVR de 15.1, acima
  // do Placard [12.9] e da OK Liga [13.6]). Substituído por uma escala contínua a partir da
  // reputação real de cada clube, tal como já acontece para a nuvem europeia (nuvemPlaceholderBase,
  // acima) — mas calibrada para um nível claramente inferior ao Placard e à OK Liga em geral
  // (pedido explícito do utilizador), não ao nível "amador" da nuvem: o pior clube (rep. ~50) fica
  // acima da 2ª Divisão portuguesa, o melhor (rep. ~84) fica perto do fundo da tabela do Placard —
  // nunca a ultrapassar claramente.
  function serieA1PlaceholderBase(reputacao){
    const r = clamp(Number(reputacao)||50, 50, 84);
    return 9.5 + (r-50)/(84-50)*4.5; // rep 50 -> base 9,5; rep 84 -> base 14
  }
  // Nível-base dos clubes da OK Liga (Espanha) SEM plantel real importado (pedido do utilizador,
  // 2026-09-17: "os jogadores de algumas equipas da liga espanhola estao demasiado bons, tipo
  // noia, maçanet, voltrega") — mesmo bug já corrigido para a Serie A1 (ver serieA1PlaceholderBase,
  // acima), nunca estendido à OK Liga. O campo "tier" da base de dados não acompanha a reputação
  // real de cada clube (ex.: CE Noia rep.76 e CP Voltregà rep.74 têm tier=1, o mesmo de clubes de
  // elite, gerando o nível-base fixo de "qualidade de estrela" tierBaseLevel(1)=16 — confirmado:
  // média de OVR ~15,4-15,5, ACIMA do próprio FC Barcelona, o único clube da OK Liga com plantel
  // real, que fica nos 12,7). Substituído por uma escala contínua a partir da reputação real de
  // cada clube (mesmo princípio da Serie A1), calibrada para nunca ultrapassar claramente o FC
  // Barcelona real: o pior clube (rep. ~55) fica ligeiramente abaixo da 2ª Divisão portuguesa, o
  // melhor (rep. ~92, HC Liceo) fica perto mas sempre abaixo do nível do Barcelona.
  function okLigaPlaceholderBase(reputacao){
    const r = clamp(Number(reputacao)||55, 55, 92);
    return 9 + (r-55)/(92-55)*3; // rep 55 -> base 9; rep 92 -> base 12
  }
  // Nível-base dos clubes da OK Liga Plata (2.ª divisão espanhola, 2026-10-21) SEM plantel real
  // importado — plantéis provisórios até o utilizador importar os reais. Escala contínua a partir
  // da reputação, abaixo do pior clube da OK Liga (base 9): rep 46 -> base 7,5; rep 66 -> base 10.
  function platPlaceholderBase(reputacao){
    const r = clamp(Number(reputacao)||50, 46, 66);
    return 7.5 + (r-46)/(66-46)*2.5;
  }
  // 2.º escalão de cada país (2.ª Divisão portuguesa e OK Liga Plata espanhola) — o resto do jogo
  // trata os dois da mesma forma (finanças, adeptos, objetivos); só as ligações de subida/descida
  // são específicas de cada país.
  function isSecondTierDivision(divisionId){ return divisionId==="2div" || divisionId==="ok-liga-plata"; }
  function generatePlaceholderRoster(teamId, tier, divisao, pais, reputacao){
    const base = (divisao==="europa-nuvem" && reputacao!=null) ? nuvemPlaceholderBase(reputacao)
      : (divisao==="serie-a1" && reputacao!=null) ? serieA1PlaceholderBase(reputacao)
      : (divisao==="ok-liga" && reputacao!=null) ? okLigaPlaceholderBase(reputacao)
      : (divisao==="ok-liga-plata" && reputacao!=null) ? platPlaceholderBase(reputacao)
      : tierBaseLevel(tier);
    const players = [];
    // Correção (pedido do utilizador, 2026-09-12): os nomes eram literalmente "Jogador N
    // (provisório)"/"Guarda-Redes Titular (provisório)" — texto de marcador de posição a aparecer
    // dentro do próprio jogo (ficha do jogador, escalação, etc.), em vez de nomes gerados. Usa
    // sempre randomNameForCountry (a mesma função já usada para jovens da formação/candidatos),
    // com uma semente própria por posição para nunca repetir o mesmo nome dentro do plantel.
    const nameRng = (seed) => makeSeededRng(teamId+"|"+seed);
    players.push(makeGoalkeeper(teamId+"-p1", 1, randomNameForCountry(pais, nameRng("gr1")), base, divisao, pais));
    players.push(makeGoalkeeper(teamId+"-p2", 12, randomNameForCountry(pais, nameRng("gr2")), base-8, divisao, pais));
    const nums = [4,5,6,7,8,9,10,11,14,17,20,23];
    for(let i=0;i<10;i++){
      players.push(makeOutfieldPlayer(teamId+"-p"+(i+3), nums[i], randomNameForCountry(pais, nameRng("j"+i)), base, divisao, pais));
    }
    return players;
  }

  // =================================================================
