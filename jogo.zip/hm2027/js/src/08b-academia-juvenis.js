// Academia e Juvenis (2026-09-22) — substitui por completo o antigo sistema de geração de
// juvenis (generateNewGeneration/state.youthCandidates/qualidadeFormacao/youthIntegrationLimit/
// annualYouthReview, todos em 01-nucleo.js). Decisões fechadas com o utilizador (ver plano):
// escalões Sub-13/15/17/19, 4-8 jovens por escalão, sem academia na 3ª divisão nem nos clubes
// "nuvem" europeia (criada no momento da subida à 2ª divisão), contrato desde a entrada no
// escalão Sub-13, rácio de promoções a sénior preservado (governador na Fase 3), sem cortes
// antes da saída do Sub-19 (Fase 3).
//
// Fase 1 (este ficheiro nesta fase): só o modelo de dados e o arranque (bootstrap) — a admissão
// anual/cascata de escalões (Fase 2), o motor de desenvolvimento mensal (Fase 4) e o governador
// de promoção no Sub-19 (Fase 3) são acrescentados nas fases seguintes. O sistema antigo
// (generateNewGeneration, chamado em beginDefeso) continua a correr sem alterações nesta fase.

const ACADEMY_BRACKETS = ["sub13", "sub15", "sub17", "sub19"];

// Anos de nascimento por escalão — regra real da Federação de Patinagem de Portugal, confirmada
// pelo utilizador (2026-09-23) com a tabela oficial da época 2026-27: Sub-13 nasce em 2014-2015,
// Sub-15 em 2012-2013, Sub-17 em 2010-2011, Sub-19 em 2008-2009. Os deltas abaixo (12/11, 14/13,
// 16/15, 18/17) são a distância desses anos ao ano de início dessa época (2026) — substitui a
// antiga ACADEMY_BRACKET_AGE_RANGE (idade fixa 12-13/14-15/16-17/18-19, que não seguia a regra
// real da Federação) precisamente para a "regra se manter para as seguintes" épocas pedida pelo
// utilizador: como seasonStartYear (=2025+state.season, mesma fórmula de seasonLabel,
// 01-nucleo.js) avança um ano a cada época, os anos de nascimento gerados avançam com ela
// automaticamente (ex.: na época 2027-28 o Sub-13 já nasce em 2015-2016), sem precisar de
// nenhuma tabela nova por época. Ver academyBracketBirthYearRange, abaixo.
const ACADEMY_BRACKET_BIRTH_YEAR_OFFSET = {
  sub13: [12, 11],
  sub15: [14, 13],
  sub17: [16, 15],
  sub19: [18, 17],
};
// [anoMaisVelho, anoMaisNovo] de nascimento para um escalão, na época indicada (state.season).
function academyBracketBirthYearRange(bracket, season) {
  const seasonStartYear = 2025 + season;
  const [oldOffset, youngOffset] = ACADEMY_BRACKET_BIRTH_YEAR_OFFSET[bracket];
  return [seasonStartYear - oldOffset, seasonStartYear - youngOffset];
}
// Gera uma data de nascimento dentro de um ano civil exacto (mês/dia aleatórios, mesma forma de
// makeBirthDate, 01-nucleo.js, mas a partir do ano directamente em vez de uma idade-alvo — é o
// que a regra por ano de nascimento da Federação exige, ao contrário de makeBirthDate, pensada
// para "idade alvo numa data de referência").
function makeBirthDateInYear(rng, year) {
  const month = seededRnd(rng, 0, 11);
  const day = seededRnd(rng, 1, 28);
  return new Date(Date.UTC(year, month, day)).toISOString().slice(0, 10);
}

// Desvio ao "base" de atributo de partida (mesma fórmula de generateYouthOutfield/GK: base =
// clampAttr(6 + academyLevel*0.25 + seededRnd(rng,-1,1))) — nos escalões mais novos o chão de
// atributo desce um pouco, para um miúdo de 12-13 anos não aparecer com o mesmo nível visível de
// um quase-adulto; a qualidade da academia continua a marcar sobretudo o potGap (teto), não este
// nível de partida, tal como no sistema antigo.
const ACADEMY_BRACKET_BASE_OFFSET = { sub13: -3, sub15: -2, sub17: 0, sub19: 0 };

// Nível de arranque da formação RELATIVO à equipa B do próprio clube (pedido do utilizador,
// 2026-10-05: "não faz sentido as equipas B terem jogadores piores que a formação... os OVR da
// formação continuam muito altos... é normal chegar sénior com um OVR de 10, o resto evolui na
// carreira... tudo tem desvio padrão"). Medido antes desta alteração: Sub-17/Sub-19 com média
// ~8-9 contra equipas B de 5-7,5 — os jovens eram melhores do que a equipa B que os devia receber.
// A formação passa a nascer abaixo do nível da equipa B (ou, sem equipa B, de uma estimativa a
// partir da equipa A), escalão a escalão, com um desvio-padrão largo — o grosso da evolução fica
// para o desenvolvimento mensal e para a carreira sénior.
const ACADEMY_REL_OFFSET = { sub13: -4.5, sub15: -3.5, sub17: -2.5, sub19: -1.5 };
const ACADEMY_REF_NO_B_GAP = 5.5;     // sem equipa B: média da equipa A menos isto
const ACADEMY_REF_MIN = 4.5, ACADEMY_REF_MAX = 11;
const ACADEMY_START_SD = 1.3;         // desvio-padrão do nível de arranque de cada jovem
const ACADEMY_OVR_BIAS = 0.9;         // o viés de linha (applyLinhaBias) acrescenta ~0,9 ao OVR face à base
function academyReferenceLevel(club) {
  const mean = arr => arr.reduce((a, b) => a + b, 0) / arr.length;
  const bTeam = club.equipaBId ? state.teams[club.equipaBId] : null;
  let ref;
  if (bTeam && bTeam.players.length >= 5) ref = mean(bTeam.players.map(overall));
  else if (club.players && club.players.length >= 5) ref = mean(club.players.map(overall)) - ACADEMY_REF_NO_B_GAP;
  else ref = 6;
  return clamp(ref, ACADEMY_REF_MIN, ACADEMY_REF_MAX);
}
// Potencial: independente do nível de arranque do escalão. A fórmula antiga (ovr + hiato) fazia o
// potencial depender do OVR actual, que agora nasce mais baixo (formação abaixo da equipa B) —
// sem este ajuste, o potencial médio caía 2-3 pontos e os melhores prospectos deixavam de ter
// margem para a carreira sénior ("o resto evolui na carreira"). Mantém-se a escala calibrada em
// 2026-09-22 (potencial ≈ nível de um Sub-17 "clássico" da academia + hiato).
function academyPotentialFor(ovr, potGap, academyLevel, refLevel) {
  if (refLevel == null) return clampAttr(ovr + potGap);
  const legacyBase = 6 + academyLevel * 0.25 + ACADEMY_OVR_BIAS;
  return clampAttr(Math.max(ovr + 2, legacyBase + potGap));
}
function seededGauss(rng) {
  const u1 = Math.max(1e-9, rng()), u2 = rng();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}
// Base de atributo de arranque de um jovem. Sem refLevel mantém a fórmula antiga (usada na rede de
// segurança da equipa B, ensureBTeamMinimums, e em saves antigos).
function academyStartBase(rng, academyLevel, bracket, refLevel) {
  if (refLevel == null) return clampAttr(6 + academyLevel * 0.25 + (ACADEMY_BRACKET_BASE_OFFSET[bracket] || 0) + seededRnd(rng, -1, 1));
  const lvlEffect = (academyLevel - 5) * 0.15;
  const raw = refLevel + (ACADEMY_REL_OFFSET[bracket] || 0) + lvlEffect - ACADEMY_OVR_BIAS + seededGauss(rng) * ACADEMY_START_SD;
  return clamp(Math.round(raw), 1, 20);
}

// Excepção pedida explicitamente pelo utilizador (2026-09-23): nomes reais dos jogadores da
// academia do Sporting CP, tal como constam nos cartões de identificação da Federação de
// Patinagem de Portugal (apenas primeiro e último nome, por instrução do utilizador — "poe
// primeiro e ultimo nome"). Aplica-se SÓ ao arranque da primeira época de uma carreira nova
// (state.season===1) e SÓ ao clube "sporting" — decisão explícita do utilizador: "quero
// substituir os que iniciam na primeira epoca". Sem lista para o Sub-19 (o utilizador optou por
// "só estes três escalões") — esse escalão continua a usar randomNameForCountry normalmente,
// mesmo no bootstrap do Sporting. Nenhuma fotografia nem número de sócio/federação foi guardado
// ou usado — só o nome impresso nos cartões, tal como pedido.
const SPORTING_REAL_ACADEMY_ROSTER_SEASON1 = {
  sub13: ["Guilherme Antunes", "Francisco Simões", "Vicente Carvalho", "Alexandre Abrantes", "Guilherme Porfirio", "Santiago Bandeiras", "Tomás Martins", "David Monteiro", "João Reis", "Pedro Brigantim", "José Silva"],
  sub15: ["Pedro Botas", "Guilherme Alho", "Henrique Dias", "João Negrão", "Leonor Inácio", "Lourenço Lopes", "Manuel Gomes", "Martim Sousa", "Simão Henriques", "Artur Elvas", "Duarte Gonçalves"],
  sub17: ["Martim Pires", "Rafael Bologan", "Henrique Elvas", "Sebastião Valadas", "Simão Botas", "Simão Mineiro", "Simão Bandeiras"],
};
// Guarda-redes reais dentro da lista acima (2026-09-23, pedido do utilizador) — sem isto, a
// posição destes jogadores era decidida ao acaso (~1 em 6, generateAcademyPlayerForBracket),
// tal como qualquer jovem gerado aleatoriamente, o que não respeitava a posição real de quem
// joga à baliza no Sporting. Nomes confirmados com correspondência clara na lista acima; ver
// bootstrapAcademyIfEmpty para os que ainda aguardam confirmação do utilizador (nomes fornecidos
// que não batem certo com nenhuma entrada existente, ex. "Pedro Luz"/"Martim Ramalho", ou que
// parecem ser uma correcção de nome mas mudam claramente o apelido/nome próprio, ex. "Artur
// Albino" vs "Artur Elvas", "Pedro Silva" vs "José Silva" — não presumidos, para não arriscar
// atribuir mal a identidade de um menor real).
const SPORTING_REAL_ACADEMY_GOALKEEPERS = new Set([
  "Guilherme Antunes", "Pedro Brigantim", "Manuel Gomes", "Pedro Botas", "Rafael Bologan",
]);

// 0.3.11 — plantéis reais de mais clubes (pedido do utilizador, a partir de fichas de jogo da FPP):
// SL Benfica (Sub-17 e Sub-15), CD Paço de Arcos (Sub-15) e AD Oeiras (Sub-15). Tal como no Sporting,
// só se aplicam ao arranque da primeira época e só o primeiro e o último nome. Cada entrada é um
// nome ou { n: nome, gr: guarda-redes, f: rapariga, wk: wonderkid }. Os escalões sem lista (Sub-13,
// Sub-19) continuam a ser gerados ao acaso. Dinis Moreira e Rodrigo Martinho constam das fichas
// Sub-17 e Sub-15 do Benfica: são os mesmos jogadores (os mais novos jogam nos dois escalões) e
// ficam só no Sub-15.
const REAL_ACADEMY_ROSTERS = {
  benfica: {
    sub15: [{ n: "Miguel Matos", gr: true }, { n: "Filipa Gonçalves", f: true }, "José Simões", "Rodrigo Martinho", "Guilherme Gomes", "Simão Morais", "Dinis Moreira", "Mateus Bernardo", "Francisco Piçarra", { n: "Mónica Brissos", gr: true, f: true }],
    sub17: [{ n: "Hugo Pereira", gr: true }, "Afonso André", "Manuel Sousa", "Tiago Ferreira", { n: "Diogo Ataíde", wk: true }, "Santiago Valente", "Rafael Santos", { n: "Afonso Rosário", gr: true }],
  },
  "cd-paco-de-arcos": {
    sub15: [{ n: "Tiago Ferreira", gr: true }, "Afonso Helfrich", "Francisco Pascoal", "Martim Chorincas", "João Ramos", "Mário Francisco", "Afonso Pires", "Tomás Cabral", { n: "Santiago Ferreira", gr: true }],
  },
  oeiras: {
    sub15: [{ n: "Guilherme Neto", gr: true }, "Rafael Almeida", "André Lopes", { n: 'Alexandre "Xano" Farias', wk: true }, "Manuel Capela", "Gonçalo Carvalho", "Tiago Pais", "Manuel Henriques", { n: "Vasco Viegas", gr: true }],
  },
};
// Rapariga do Sporting (Sub-15) — nunca passa a sénior.
const SPORTING_REAL_ACADEMY_FEMALES = new Set(["Leonor Inácio"]);
// Wonderkid do Sporting (Sub-15) — passa sempre a sénior (sem etiqueta: o utilizador tem de o encontrar).
const SPORTING_REAL_ACADEMY_WONDERKIDS = new Set(["João Negrão", "Artur Elvas"]);

// Lista real de um clube (só na 1.ª época): devolve { escalão: [{ n, gr, f, wk }] } ou null.
function academyRealRosterFor(team) {
  if (!team || state.season !== 1) return null;
  if (team.id === "sporting") {
    const out = {};
    Object.keys(SPORTING_REAL_ACADEMY_ROSTER_SEASON1).forEach(b => {
      out[b] = SPORTING_REAL_ACADEMY_ROSTER_SEASON1[b].map(n => ({ n, gr: SPORTING_REAL_ACADEMY_GOALKEEPERS.has(n), f: SPORTING_REAL_ACADEMY_FEMALES.has(n), wk: SPORTING_REAL_ACADEMY_WONDERKIDS.has(n) }));
    });
    return out;
  }
  const raw = REAL_ACADEMY_ROSTERS[team.id];
  if (!raw) return null;
  const out = {};
  Object.keys(raw).forEach(b => { out[b] = raw[b].map(e => typeof e === "string" ? { n: e } : e); });
  return out;
}

// Regras de formação (0.3.11): as raparigas nunca passam a sénior (saem da academia como os
// restantes dispensados) e os wonderkids passam sempre.
function academyIsFemale(p) { return !!p && p.genero === "F"; }
function academyIsWonderkid(p) { return !!p && !!p.wonderkid; }
// Saves antigos: marca a rapariga e o wonderkid do Sporting (Sub-15 real) se ainda não estiver marcada.
function academyApplyKnownFlags(team) {
  if (!team || !team.academy || !team.academy.brackets) return;
  // 0.4.7: Alexandre "Xano" Farias (Sub-15 do Oeiras) é wonderkid — também em saves antigos (nome sem alcunha).
  if (team.id === "oeiras") {
    ACADEMY_BRACKETS.forEach(b => (team.academy.brackets[b].players || []).forEach(p => {
      if (p.name === "Alexandre Farias") p.name = 'Alexandre "Xano" Farias';
      if (p.name === 'Alexandre "Xano" Farias' && !p.wonderkid) p.wonderkid = true;
    }));
    return;
  }
  if (team.id !== "sporting") return;
  ACADEMY_BRACKETS.forEach(b => (team.academy.brackets[b].players || []).forEach(p => {
    if (p.genero == null && SPORTING_REAL_ACADEMY_FEMALES.has(p.name)) p.genero = "F";
    if (!p.wonderkid && SPORTING_REAL_ACADEMY_WONDERKIDS.has(p.name)) p.wonderkid = true;
  }));
}

function defaultAcademyShape() {
  return {
    level: null,
    monthlyCost: 0,
    reputation: 50,
    lastIntakeSeason: null,
    lastMonthKey: null,
    brackets: {
      sub13: { players: [] },
      sub15: { players: [] },
      sub17: { players: [] },
      sub19: { players: [] },
    },
    cohortHistory: [],
  };
}

// Elegibilidade (decisão do utilizador, 2026-09-22): nunca equipas B, nunca 3ª divisão, nunca
// clubes "nuvem" europeia (placeholders de ensureEuropaNuvemClubes, 07g-europa.js). Mesma forma
// de filtro já usada para outro fim em 04-financas.js:4037
// (`!t.equipaPrincipalId && t.divisaoAtual!=="3div" && !t.nuvemEuropeia`).
// Pedido do utilizador (2026-10-14): "quero que a B e os sub-19 sejam a mesma". Nos clubes com
// equipa B o escalão Sub-19 da academia deixa de existir: a equipa B é o Sub-19 (joga a
// competição sénior, dá experiência a jovens e roda lesionados da A). Quem acaba o Sub-17 sobe
// directamente para a B (ver runAcademyAnnualIntake); os clubes sem B mantêm o Sub-19.
function academyHasB(club) {
  return !!(club && club.equipaBId && state.teams[club.equipaBId]);
}

function academyEligible(team) {
  return !!team && !team.equipaPrincipalId && !team.nuvemEuropeia; // 0.2.3: a 3.ª Divisão passa a ter academia (jogável)
}

// Perfis reais das academias mais reconhecidas do jogo (Fase 5, 2026-09-22: movida para aqui de
// 01-nucleo.js, onde vivia como CLUB_FORMATION_QUALITY, junto de initFormationQuality — removida
// nesta fase). Os restantes clubes usam o fallback por reputação/equipa B em initAcademyLevel.
const CLUB_FORMATION_QUALITY = { sporting:10, benfica:9, porto:9, barcelos:6, valongo:5, oliveirense:4 };

// Nível da Academia (1-10) — substitui qualidadeFormacao (antiga initFormationQuality,
// 01-nucleo.js, removida na Fase 5), mesma tabela de 6 clubes com formação historicamente
// reconhecida + mesmo fallback por reputação/equipa B. Só é chamada para clubes elegíveis
// (bootstrapAcademyIfEmpty já filtra antes de chegar aqui).
function initAcademyLevel(team) {
  if (team.academy && team.academy.level != null) return;
  if (!team.academy) team.academy = defaultAcademyShape();
  if (CLUB_FORMATION_QUALITY[team.id] != null) {
    team.academy.level = CLUB_FORMATION_QUALITY[team.id];
  } else {
    const repTier = team.reputacao >= 90 ? "elite" : team.reputacao >= 75 ? "forte" : "generico";
    team.academy.level = team.equipaBId
      ? (repTier === "elite" ? rnd(7, 9) : repTier === "forte" ? rnd(5, 7) : rnd(4, 6))
      : (repTier === "elite" ? rnd(4, 6) : repTier === "forte" ? rnd(3, 5) : rnd(1, 3));
  }
  team.academy.monthlyCost = 500 + team.academy.level * 350;
}

// Quantidade de jovens por escalão (decisão do utilizador: 4-8 por escalão, substitui
// youthCountForFormation's 1-6). Só o Sub-13 recebe admissão nova todos os anos (Fase 2) — os
// outros 3 escalões só recebem gente na primeira vez que a academia é criada (bootstrap), a
// partir daí só por cascata (sobreviventes do escalão anterior a subir, Fase 2).
function academyIntakeCount(level, bracket) {
  if (bracket !== "sub13") return 0;
  if (level >= 9) return rnd(7, 8);
  if (level >= 7) return rnd(6, 7);
  if (level >= 4) return rnd(5, 6);
  return rnd(4, 5);
}

// No arranque (bootstrap), os 4 escalões são preenchidos de uma vez, usando a mesma escala de
// academyIntakeCount("sub13") para cada um (decisão 3 do utilizador: nunca à espera de vários
// anos para se encherem organicamente).
function academyBootstrapCountForBracket(level) {
  return academyIntakeCount(level, "sub13");
}

// Correcção (2026-09-23, pedido do utilizador: "os OVR estão muito altos"): a fórmula antiga
// (potGap = max(2, round(6 + academyLevel*1.4 + seededRnd(rng,-3,3)))), herdada tal e qual do
// sistema antigo (generateYouthOutfield/GK), saturava o potencial no tecto de atributo (20) para
// praticamente toda a gente em qualquer academia de nível médio-alto (nível 7+: 100% dos jovens
// gerados ficavam com potencial exactamente 20, confirmado por amostragem; nível 4, ~55%) — o que
// esvaziava por completo o sentido do "potencial" como mecânica de scouting/desenvolvimento (se
// todos são "prodígios", nenhum é). A nova fórmula soma dois lançamentos seeded independentes em
// vez de um único (aproxima uma distribuição em sino centrada, em vez de uniforme, tal como somar
// dois dados em jogos de tabuleiro evita extremos demasiado frequentes) e usa um coeficiente por
// nível bem mais pequeno, para que só uma fatia minoritária de jovens das melhores academias (ex.
// Sporting, nível 10) chegue perto do tecto, e academias médias/fracas produzam potenciais
// modestos na maioria dos casos — mantendo ainda assim uma correlação clara entre nível da
// academia e qualidade média dos prospectos gerados.
function academyPotentialGap(rng, academyLevel) {
  const roll = seededRnd(rng, 0, 6) + seededRnd(rng, 0, 6); // 0-12, distribuição em sino centrada em 6
  return Math.max(2, Math.round(2 + academyLevel * 0.55 + (roll - 6)));
}

function generateAcademyOutfield(id, num, name, academyLevel, pais, bracket, refLevel, forcedBirthYear, wonder) {
  const rng = makeSeededRng(id + "|" + name);
  const linha = seededRnd(rng, 0, 1) === 0 ? "Avancado" : "DefesaMedio";
  const base = academyStartBase(rng, academyLevel, bracket, refLevel) + (wonder ? 5 : 0); // wonderkid: arranca bem acima dos colegas
  const attrs = applyLinhaBias({
    habilidade: clampAttr(base + seededRnd(rng, -2, 2)),
    drible: clampAttr(base + seededRnd(rng, -2, 2)),
    criatividade: clampAttr(base + seededRnd(rng, -2, 2)),
    finalizacao: clampAttr(base + seededRnd(rng, -3, 3)),
    bolasParadas: clampAttr(base + seededRnd(rng, -3, 3)),
    meiaDistancia: clampAttr(base + seededRnd(rng, -3, 3)),
    posicionamento: clampAttr(base + seededRnd(rng, -2, 2)),
    desarme: clampAttr(base + seededRnd(rng, -3, 3)),
    forca: clampAttr(base + seededRnd(rng, -2, 2)),
    velocidade: clampAttr(base + seededRnd(rng, -3, 3)),
    aceleracao: clampAttr(base + seededRnd(rng, -3, 3)),
    // Correcção (ver comentário em developAcademyPlayerMonthly, acima): estes 3 atributos não
    // dependiam de "base" (logo não baixavam com o escalão) — um Sub-13 podia sair com a mesma
    // "Liderança"/"Determinação" de um adulto. academyMentalAttrRange aplica metade do desconto
    // por escalão já usado nos atributos técnicos/físicos.
    agressividade: clampAttr(seededRnd(rng, ...academyMentalAttrRange(bracket, 4, 18))),
    determinacao: clampAttr(seededRnd(rng, ...academyMentalAttrRange(bracket, 6, 18))),
    lideranca: clampAttr(seededRnd(rng, ...academyMentalAttrRange(bracket, 4, 17))),
    resistencia: clampAttr(base + seededRnd(rng, -2, 2)),
  }, linha);
  const [oldYear, youngYear] = academyBracketBirthYearRange(bracket, state.season);
  // 2026-10-16: admissão anual passa o ano de nascimento exacto (só o ano mais novo do Sub-13 da
  // época seguinte entra todos os anos); o seededRnd corre sempre para manter a sequência do rng.
  const rolledBirthYear = seededRnd(rng, oldYear, youngYear);
  const birthYear = forcedBirthYear != null ? forcedBirthYear : rolledBirthYear;
  const dataNascimento = makeBirthDateInYear(rng, birthYear);
  const age = computeAge(dataNascimento, state.currentDate || REFERENCE_AGE_DATE);
  const ovr = overallFromAttrs("J", attrs);
  const potGap = academyPotentialGap(rng, academyLevel);
  const potential = wonder ? Math.max(19, academyPotentialFor(ovr, potGap, academyLevel, refLevel)) : academyPotentialFor(ovr, potGap, academyLevel, refLevel);
  return {
    id, num, name, pos: "J", linha, age, dataNascimento,
    nacionalidade: nationalityForCountry(pais), paisOrigem: normalizeCountryCode(pais), attrs, potential,
    // Correcção (2026-09-23, pedido do utilizador: "os atletas da formação nao têm salario") —
    // atletas da Academia (Sub-13 a Sub-19) são amadores, sem remuneração real na formação
    // portuguesa de hóquei em patins; mantém-se a estrutura normal do contrato (papel/anos/datas,
    // usados por outras partes do jogo, ex. promoção/saída) só com salarioMensal forçado a 0 —
    // generateContract sozinho nunca desce abaixo do piso de 450€, por isso o campo é substituído
    // aqui em vez de passado como opção.
    contrato: { ...generateContract(ovr, age, { rng, potential, papel: "Desenvolvimento" }), salarioMensal: 0 },
    preContrato: null,
    temperamento: TEMPERAMENTS[seededRnd(rng, 0, TEMPERAMENTS.length - 1)],
    moral: seededRnd(rng, 55, 80), satisfacao: seededRnd(rng, 55, 80), reputacaoJogador: 0,
    titular: false, suspensoJogos: 0, diasLesao: 0, condicao: 100,
    season: createEmptyStats("season"), career: createEmptyStats("career"),
    historico: [], titulos: [], internacionalizacoes: 0, golosInternacional: 0,
    academyBracket: bracket, __academyGenerated: true,
  };
}

function generateAcademyGoalkeeper(id, num, name, academyLevel, pais, bracket, refLevel, forcedBirthYear, wonder) {
  const rng = makeSeededRng(id + "|" + name);
  const base = academyStartBase(rng, academyLevel, bracket, refLevel) + (wonder ? 5 : 0); // wonderkid: arranca bem acima dos colegas
  const attrs = {
    reflexos: clampAttr(base + seededRnd(rng, -2, 2)),
    umParaUm: clampAttr(base + seededRnd(rng, -2, 2)),
    agilidade: clampAttr(base + seededRnd(rng, -2, 2)),
    concentracao: clampAttr(base + seededRnd(rng, -2, 2)),
    meiaDistancia: clampAttr(base + seededRnd(rng, -3, 3)),
    forca: clampAttr(base + seededRnd(rng, -2, 2)),
    // Correcção — ver comentário equivalente em generateAcademyOutfield/developAcademyPlayerMonthly.
    agressividade: clampAttr(seededRnd(rng, ...academyMentalAttrRange(bracket, 4, 16))),
    determinacao: clampAttr(seededRnd(rng, ...academyMentalAttrRange(bracket, 6, 18))),
    lideranca: clampAttr(seededRnd(rng, ...academyMentalAttrRange(bracket, 4, 17))),
    resistencia: clampAttr(base + seededRnd(rng, -2, 2)),
  };
  const [oldYear, youngYear] = academyBracketBirthYearRange(bracket, state.season);
  // 2026-10-16: admissão anual passa o ano de nascimento exacto (só o ano mais novo do Sub-13 da
  // época seguinte entra todos os anos); o seededRnd corre sempre para manter a sequência do rng.
  const rolledBirthYear = seededRnd(rng, oldYear, youngYear);
  const birthYear = forcedBirthYear != null ? forcedBirthYear : rolledBirthYear;
  const dataNascimento = makeBirthDateInYear(rng, birthYear);
  const age = computeAge(dataNascimento, state.currentDate || REFERENCE_AGE_DATE);
  const ovr = overallFromAttrs("GR", attrs);
  const potGap = academyPotentialGap(rng, academyLevel);
  const potential = wonder ? Math.max(19, academyPotentialFor(ovr, potGap, academyLevel, refLevel)) : academyPotentialFor(ovr, potGap, academyLevel, refLevel);
  return {
    id, num, name, pos: "GR", age, dataNascimento,
    nacionalidade: nationalityForCountry(pais), paisOrigem: normalizeCountryCode(pais), attrs, potential,
    // Salário 0 — ver comentário equivalente em generateAcademyOutfield.
    contrato: { ...generateContract(ovr, age, { rng, potential, papel: "Desenvolvimento" }), salarioMensal: 0 },
    preContrato: null,
    temperamento: TEMPERAMENTS[seededRnd(rng, 0, TEMPERAMENTS.length - 1)],
    moral: seededRnd(rng, 55, 80), satisfacao: seededRnd(rng, 55, 80), reputacaoJogador: 0,
    titular: false, suspensoJogos: 0, diasLesao: 0, condicao: 100,
    season: createEmptyStats("season"), career: createEmptyStats("career"),
    historico: [], titulos: [], internacionalizacoes: 0, golosInternacional: 0,
    academyBracket: bracket, __academyGenerated: true,
  };
}

// Gera um jovem para um escalão específico da academia de um clube (usada tanto pelo bootstrap
// como, na Fase 2, pela admissão anual do Sub-13) — decide posição por uma necessidade simples
// (mais defesas/médios que avançados, um guarda-redes a cada handful, mesma proporção usada
// informalmente pelo sistema antigo via candidatePositionForNeed) e nome sempre do país do clube
// (decisão 10 do utilizador — randomNameForCountry, tal como generateNewGeneration já faz hoje).
function generateAcademyPlayerForBracket(club, bracket, index, forcedName, forcedIsGoalkeeper, forcedBirthYear, flags) {
  const pais = teamCountry(club);
  const id = `${club.id}-academia-${bracket}-${state.season}-${index}-${uid()}`;
  const rng = makeSeededRng(id);
  const name = forcedName || randomNameForCountry(pais, rng);
  const isGoalkeeper = forcedIsGoalkeeper != null ? forcedIsGoalkeeper : seededRnd(rng, 1, 6) === 1; // ~1 em 6, ordem de grandeza de um plantel normal, salvo posição real conhecida (forcedIsGoalkeeper)
  const player = isGoalkeeper
    ? generateAcademyGoalkeeper(id, 1, name, club.academy.level, pais, bracket, academyReferenceLevel(club), forcedBirthYear, !!(flags && flags.wk))
    : generateAcademyOutfield(id, 1, name, club.academy.level, pais, bracket, academyReferenceLevel(club), forcedBirthYear, !!(flags && flags.wk));
  if (flags && flags.f) player.genero = "F";
  if (flags && flags.wk) player.wonderkid = true;
  player.academyClubId = club.id;
  player.academyEntrySeason = state.season;
  return player;
}

// Arranque (bootstrap) da Academia de um clube — decisão 3 do utilizador: nunca à espera de
// vários anos para os 4 escalões se encherem organicamente. Idempotente: não faz nada se o clube
// não for elegível (decisão 9) ou se já tiver pelo menos um jovem nalgum escalão. Chamada em 3
// pontos: arranque de carreira nova e carregamento de gravação antiga (05-ui-navegacao.js /
// 11-guardar-carregar.js, ambos nesta Fase 1), e no momento da subida da 3ª para a 2ª divisão
// (07-playoff.js, Fase 2).
function bootstrapAcademyIfEmpty(team) {
  if (!academyEligible(team)) return;
  initAcademyLevel(team);
  const hasAnyPlayers = ACADEMY_BRACKETS.some(b => team.academy.brackets[b].players.length > 0);
  academyApplyKnownFlags(team);
  if (hasAnyPlayers) return;
  // Plantéis reais (Sporting, Benfica, Paço de Arcos, Oeiras — ver acima): só no arranque da
  // primeira época de uma carreira nova. Numa gravação antiga carregada já lá para a frente
  // (state.season>1) o Sporting recebe uma academia normal, gerada por nome aleatório, tal como
  // qualquer outro clube — a excepção é estritamente um bootstrap único da época 1.
  const realRoster = academyRealRosterFor(team);
  const counts = {};
  ACADEMY_BRACKETS.forEach(bracket => {
    const realEntries = realRoster && realRoster[bracket];
    const count = (bracket === "sub19" && academyHasB(team)) ? 0
      : realEntries ? realEntries.length : academyBootstrapCountForBracket(team.academy.level);
    counts[bracket] = count;
    for (let i = 0; i < count; i++) {
      const entry = realEntries ? realEntries[i] : null;
      const forcedName = entry ? entry.n : undefined;
      const forcedIsGoalkeeper = entry ? !!entry.gr : undefined;
      team.academy.brackets[bracket].players.push(generateAcademyPlayerForBracket(team, bracket, i, forcedName, forcedIsGoalkeeper, undefined, entry));
    }
    // Os wonderkids reais (ex.: Artur Elvas e João Negrão no Sub-15 do Sporting) arrancam sempre
    // como os melhores do escalão: sobem-se-lhes os atributos até ficarem acima de todos os colegas.
    const lista = team.academy.brackets[bracket].players;
    const wks = lista.filter(p => p.wonderkid && p.pos !== "GR");
    const outros = lista.filter(p => !p.wonderkid && p.pos !== "GR");
    if (wks.length && outros.length) {
      const alvo = Math.max(...outros.map(p => overall(p))) + 1;
      wks.forEach(w => { for (let k = 0; k < 10 && overall(w) < alvo; k++) Object.keys(w.attrs).forEach(a => { w.attrs[a] = Math.min(99, w.attrs[a] + 1); }); });
    }
  });
  team.academy.cohortHistory.push({ season: state.season, event: "bootstrap", counts });
}

// Governador de promoção no Sub-19 (Fase 3, 2026-09-22) — preserva o rácio de promoções a
// sénior/equipa B que o sistema antigo já produzia (decisão 4 do utilizador: "nem todos os
// jogadores chegam a seniores. O rácio de jogadores novos tem de se manter"). Fórmula e bandas
// IDÊNTICAS a youthIntegrationLimit (01-nucleo.js:1451-1454) — deliberadamente NÃO escaladas
// pelo tamanho maior da bolsa de Sub-19 (4-8, em vez do lote único de 1-6 do sistema antigo):
// o limite depende só do tamanho da estrutura de destino (A+B combinada), nunca de quantos
// candidatos existem, por isso o número de promoções por clube por época mantém-se
// estruturalmente igual ao de hoje — a melhoria é a qualidade de quem é promovido (6 anos de
// cascata + desenvolvimento), não a quantidade.
function academyPromotionLimit(snapshot) {
  if (snapshot.b && snapshot.b.players.length > 18) return 0;
  if (snapshot.total <= 20) return 3;
  if (snapshot.total <= 26) return 2;
  if (snapshot.total <= 30) return 1;
  return 0;
}

// 2026-10-16: cada escalão tem 2 anos de nascimento (ex.: Sub-17 = 2010-2011). Em cada transição
// de época só sobe/sai o ano MAIS VELHO — o mais novo fica mais um ano. Antes subia o escalão
// inteiro, e os miúdos chegavam à equipa B/sénior aos 15-17 anos (ainda Sub-17). Devolve os
// jogadores do escalão que, na época indicada, já fazem parte do ano de nascimento mais velho.
function academyCohortLeaving(club, bracketKey, season) {
  const oldYear = academyBracketBirthYearRange(bracketKey, season == null ? state.season : season)[0];
  return club.academy.brackets[bracketKey].players.filter(p => {
    const y = parseInt(String(p.dataNascimento || "").slice(0, 4), 10);
    return !Number.isFinite(y) || y <= oldYear;
  });
}

// Passagem de saída do Sub-19 (Fase 3): promove os melhores dentro do limite do governador
// acima (com a mesma excepção de "talento excecional" do sistema antigo — potential>=17 ou
// overall>=11 sobe um limite de 0 para 1), e liberta todos os restantes via
// archiveInactivePlayer (mesmo destino que annualYouthReview já usa hoje — arquivo de inactivos,
// não o mercado de agentes livres directamente, para não pressionar FREE_AGENT_CAP=90 com o
// volume maior de saídas que a escala 4-8/escalão implica). Esvazia sempre o Sub-19 no final —
// chamada antes da cascata em runAcademyAnnualIntake, para o escalão ficar livre antes de o
// Sub-17 subir.
// Registo das saídas da época (promovidos e dispensados), lido pela folha de fim de época
// (08zc-folha-formacao.js). Reiniciado por clube no início de runAcademyAnnualIntake.
function academyExitLogOf(club) {
  if (club.id !== state.userTeamId) return { promovidos: [], dispensados: [] };   // só o clube do utilizador tem folha
  if (!club.academy.exitLog || club.academy.exitLog.season !== state.season) club.academy.exitLog = { season: state.season, promovidos: [], dispensados: [] };
  return club.academy.exitLog;
}

function runAcademySub19ExitPass(club, bracketKey = "sub19") {
  // 2026-10-16: só o ano de nascimento mais velho do escalão sai; o mais novo fica.
  const sub19 = academyCohortLeaving(club, bracketKey);
  if (!sub19.length) return;
  const snapshot = combinedStructureSnapshot(club);
  let limit = academyPromotionLimit(snapshot);
  // 0.3.11: as raparigas nunca passam a sénior; os wonderkids passam sempre (contam para o limite
  // do governador, mas passam mesmo que o limite esteja esgotado).
  const elegiveis = sub19.filter(p => !academyIsFemale(p));
  const wonderkids = elegiveis.filter(academyIsWonderkid);
  const exceptional = elegiveis.filter(p => p.potential >= 17 || overall(p) >= 11);
  if (limit === 0 && exceptional.length) limit = 1;
  const restantes = elegiveis.filter(p => !academyIsWonderkid(p)).sort((a, b) => (b.potential - a.potential) || (overall(b) - overall(a)));
  const selected = wonderkids.concat(restantes.slice(0, Math.max(0, limit - wonderkids.length)));
  const selectedIds = new Set(selected.map(p => p.id));
  const destino = snapshot.b || club;
  selected.forEach(player => {
    player.num = findFreeNumber(destino);
    delete player.academyBracket;
    // Motor de Eventos Narrativos (2026-09-28, 09b-eventos-narrativos.js): "clube formador" —
    // gravado uma única vez, no momento exacto em que um jovem da academia sobe ao plantel
    // sénior pela primeira vez. Usado pelos eventos Traição/Regresso a Casa (e, mais tarde, O
    // Vilão) para saber onde um jogador se formou, algo que não existia antes no jogo.
    if (!player.clubeFormadorId) player.clubeFormadorId = club.id;
    // Correcção (2026-09-23): na Academia o salário é sempre 0 (atletas da formação não são
    // remunerados) — ao ser promovido a sénior/equipa B deixa de ser amador e passa a jogador
    // profissional do plantel real, por isso recebe aqui um salário normal, calculado pela mesma
    // fórmula de generateContract a partir do seu overall/potencial actuais (já desenvolvidos
    // pelo motor mensal da Academia).
    player.contrato.salarioMensal = generateContract(overall(player), player.age, { potential: player.potential }).salarioMensal;
    destino.players.push(player);
    club.academy.cohortHistory.push({ season: state.season, event: "promocao", playerId: player.id, destinationId: destino.id });
    academyExitLogOf(club).promovidos.push({ id: player.id, nome: player.name, age: player.age, pos: player.pos, ovr: overall(player), pot: visiblePotentialLabel(player, club), destinoId: destino.id });
  });
  const released = sub19.filter(p => !selectedIds.has(p.id));
  released.forEach(player => {
    academyExitLogOf(club).dispensados.push({ id: player.id, nome: player.name, age: player.age, pos: player.pos, ovr: overall(player), pot: visiblePotentialLabel(player, club), mulher: academyIsFemale(player) });
    archiveInactivePlayer(player, "sem-perspetiva-academia");
    club.academy.cohortHistory.push({ season: state.season, event: "saida-sem-promocao", playerId: player.id });
  });
  // Correção (pedido do utilizador, 2026-10-03: "não podem aparecer notícias de promoções de
  // jogadores dos outros clubes a sénior, só do meu") — esta notícia corria para TODOS os clubes
  // elegíveis para Academia (ver runAcademyAnnualIntake), não só o do utilizador, inundando a
  // caixa de entrada com promoções de academias de clubes de IA sem qualquer interesse direto.
  // Passa a publicar-se apenas quando o clube em causa é o do próprio utilizador (equipa A).
  if (selected.length && club.id === state.userTeamId) {
    pushNews(state.currentDate, `${teamLinkHtml(club.id)} promoveu ${selected.length} jogador(es) da academia ao plantel${snapshot.b ? ` (via a equipa B, ${teamLinkHtml(snapshot.b.id)})` : ""}: ${selected.map(p => playerLinkHtml(destino.id, p)).join(", ")}.`, "juventude");
  }
  const leftIds = new Set(sub19.map(p => p.id));
  club.academy.brackets[bracketKey].players = club.academy.brackets[bracketKey].players.filter(p => !leftIds.has(p.id));
}

// Admissão anual + cascata de escalões (Fase 2, 2026-09-22) — substitui por completo
// generateNewGeneration (01-nucleo.js). Chamada uma vez por época, no sítio exacto onde antes
// estava generateNewGeneration() (beginDefeso, 08-evolucao-jogadores.js), com a mesma guarda de
// idempotência por época. Só o Sub-13 recebe admissão nova todos os anos — os outros 3 escalões
// só recebem gente por cascata (sobreviventes do escalão anterior a subir, sem avaliação de
// corte nenhuma — decisão 7 do utilizador). A saída/promoção do Sub-19 (Fase 3, acima) corre
// sempre antes da cascata, para o escalão ficar livre antes de o Sub-17 subir.
function runAcademyAnnualIntake() {
  if (state.academyIntakeProcessedSeason === state.season) return;
  Object.values(state.teams).forEach(club => {
    if (!academyEligible(club) || !club.academy) return;
    initAcademyLevel(club);
    const b = club.academy.brackets;
    // Idade real de cada jovem (dataNascimento é a fonte de verdade, mas p.age é um campo em
    // cache que só refreshPlayerAge actualiza — e essa função só corre sobre team.players, nunca
    // sobre os escalões da academia, ver 09-fluxo-epoca.js:dailyConditionRecovery). Sem este
    // refresh anual aqui, a idade visível ficaria congelada no valor de quando o jogador foi
    // gerado, por mais épocas que passassem dentro da academia.
    ACADEMY_BRACKETS.forEach(bracket => {
      b[bracket].players.forEach(p => refreshPlayerAge(p, state.currentDate));
    });
    // Saída/promoção do Sub-19 (Fase 3) — antes da cascata, para o escalão ficar livre.
    // 2026-10-16: em cada escalão só o ano de nascimento mais velho sobe (o mais novo fica mais um
    // ano). Os grupos que sobem calculam-se todos à partida, antes de qualquer movimento.
    const leave17 = academyCohortLeaving(club, "sub17");
    const leave15 = academyCohortLeaving(club, "sub15");
    const leave13 = academyCohortLeaving(club, "sub13");
    runAcademySub19ExitPass(club);
    // Clubes com equipa B: não há Sub-19 (a B é o Sub-19) — o ano mais velho do Sub-17 faz a
    // passagem de saída (promoção à B, limitada, ou dispensa). Quem ainda é Sub-17 NÃO sobe.
    if (academyHasB(club)) {
      runAcademySub19ExitPass(club, "sub17");
    } else {
      const ids17 = new Set(leave17.map(p => p.id));
      b.sub17.players = b.sub17.players.filter(p => !ids17.has(p.id));
      b.sub19.players.push(...leave17);
    }
    const move = (from, to, group) => {
      const ids = new Set(group.map(p => p.id));
      b[from].players = b[from].players.filter(p => !ids.has(p.id));
      b[to].players.push(...group);
    };
    move("sub15", "sub17", leave15);
    move("sub13", "sub15", leave13);
    ["sub15", "sub17", "sub19"].forEach(bracket => {
      b[bracket].players.forEach(p => { p.academyBracket = bracket; });
    });
    // Admissão nova, só no Sub-13 — e só do ano de nascimento mais novo desse escalão na época
    // seguinte (o anterior já cá está). Metade do lote antigo por ano, porque o escalão passa a
    // ter dois anos em simultâneo (o tamanho total do escalão mantém-se). Motor de Eventos
    // Narrativos (2026-09-28): o evento "Bairro de Talento" (09b-eventos-narrativos.js) marca
    // club.academy.talentoRegionalAte quando dispara — enquanto essa data não expirar, esta
    // admissão ganha +1 jovem extra face ao normal.
    const talentoRegionalActivo = !!(club.academy.talentoRegionalAte && state.currentDate < new Date(club.academy.talentoRegionalAte));
    const count = Math.ceil(academyIntakeCount(club.academy.level, "sub13") / 2) + (talentoRegionalActivo ? 1 : 0);
    const intakeBirthYear = academyBracketBirthYearRange("sub13", state.season + 1)[1];
    for (let i = 0; i < count; i++) {
      b.sub13.players.push(generateAcademyPlayerForBracket(club, "sub13", i, undefined, undefined, intakeBirthYear));
    }
    club.academy.lastIntakeSeason = state.season;
    club.academy.cohortHistory.push({ season: state.season, event: "intake", bracket: "sub13", count });
  });
  state.academyIntakeProcessedSeason = state.season;
}

// Desenvolvimento mensal de um jogador da Academia (Fase 4, 2026-09-22). Não é a fórmula anual
// developPlayer/baseSeasonDevelopment (dependem de minutos/jogos que um juvenil na Academia
// nunca acumula) — reaproveita antes os dois blocos genéricos de 08-evolucao-jogadores.js que só
// operam sobre .attrs/.pos/.potential: playerDevelopmentCeiling (folga até ao potencial),
// applyDevelopmentDeltas (aplica o crescimento aos atributos certos consoante a posição) e
// enforcePotentialCeiling (nunca deixa overall ultrapassar potential). Só o cálculo dos
// growthPoints é novo: escalado por academy.level (academias melhores desenvolvem mais depressa)
// com uma pequena variação aleatória (rndFloat, não seeded — mesmo idioma dos restantes ganhos
// de desenvolvimento mensais/anuais do jogo, que também não são seeded).
// growthMult (Fase 2 do Staff — Treinadores, 2026-09-22): factor opcional (1 = neutro) vindo do
// "Desenvolvimento de Jovens" de quem comanda o clube — ver processAcademyMonthlyDevelopment.
//
// Correcção (bug reportado pelo utilizador, 2026-10-01: "os ovr dos atletas da formação está
// muito alto... o ovr tem de subir rapido durante os anos de formação para que quando chega a
// senior ter um ovr coerente"): o coeficiente original (0.15 + academyLevel*0.03) foi desenhado
// olhando só para o valor de growthPoints em si, sem ter em conta que applyDevelopmentDeltas
// (08-evolucao-jogadores.js, partilhada com o developPlayer() dos seniores) divide sempre esse
// valor por ~9.75 (outfield) antes de o aplicar a cada atributo — e como todos os atributos
// recebem o mesmo incremento, o OVR também só sobe por essa fracção, não por growthPoints
// inteiro. Resultado medido por simulação (academia do Sporting, nível 10, jovem "prodígio" com
// potencial 18): partindo de OVR 6 aos 12 anos, chegava aos 18/19 anos (saída do Sub-19, ~4
// épocas de desenvolvimento mensal) com OVR 9 — muito abaixo da média do plantel sénior do mesmo
// clube (14,1), tornando a formação praticamente inútil (um jovem "promovido" ficava pior do que
// qualquer jogador do banco). Ao mesmo tempo, os atributos "mentais" (agressividade/determinação/
// liderança, abaixo) são sorteados com os MESMOS intervalos largos usados para adultos
// (makeOutfieldPlayer/makeGoalkeeper), sem qualquer desconto por idade — um Sub-13 pode sair com
// "Liderança 17" tal como um veterano, o que também contribuía para a sensação de "parece um
// sénior".
//
// Correcção ao ajuste anterior (mesma conversa, 2026-10-01): um primeiro afinamento (coeficiente
// 4x maior) corrigia a lentidão mas foi longe demais na direcção oposta — um "wonderkid" absoluto
// (potencial 20, o teto do jogo) chegava à promoção (18/19 anos) já com OVR 17, quase ao nível de
// um veterano no pico. Pedido do utilizador: "um jogador só chega a esses níveis pelos 27/28 a não
// ser que seja um wonderkid" — ou seja, mesmo um wonderkid NÃO deve chegar a sénior já perto do
// potencial; o grosso da aproximação ao potencial continua a acontecer durante a carreira sénior
// (developPlayer/competitiveSeasonDevelopment, 08-evolucao-jogadores.js, que já modela isso com o
// factor de idade — pico de crescimento até aos 21, a esmorecer gradualmente até parar aos 30).
// A Academia deve só entregar os jovens com uma folga de desenvolvimento promissora mas claramente
// por cumprir, nunca já "feita". Coeficiente final: 2x o original (em vez de 4x) — fecha cerca de
// 1/3 a pouco mais de metade do hiato de potencial dentro das ~4 épocas de formação consoante o
// nível da academia, deixando a maior parte da aproximação ao potencial para a década seguinte, tal
// como o utilizador pediu.
function academyMentalAttrRange(bracket, lo, hi) {
  const offset = Math.round((ACADEMY_BRACKET_BASE_OFFSET[bracket] || 0) * 0.5);
  return [Math.max(1, lo + offset), Math.max(1, hi + offset)];
}
const ACADEMY_GROWTH_TIME_SCALE = 0.5;
function developAcademyPlayerMonthly(player, academyLevel, growthMult) {
  const beforeAttrs = { ...player.attrs };
  const beforeOverall = overall(player);
  const ceiling = playerDevelopmentCeiling(player);
  if (ceiling <= 0) return;
  // 2026-10-16: os jovens passaram a ficar 2 anos em cada escalão (só sobe o ano mais velho) — o
  // dobro do tempo de desenvolvimento antes da saída. ACADEMY_GROWTH_TIME_SCALE compensa para o
  // OVR à saída ficar onde estava calibrado (medido: Sporting ~10-11, Porto ~7,5, Barcelos ~6,5).
  const growthPoints = ceiling * (0.3 + academyLevel * 0.06) * ACADEMY_GROWTH_TIME_SCALE * rndFloat(0.6, 1.4) * (growthMult != null ? growthMult : 1);
  applyDevelopmentDeltas(player, growthPoints);
  enforcePotentialCeiling(player, beforeAttrs, beforeOverall);
}

// Motor mensal da Academia (Fase 4, 2026-09-22): chamado a par de cada processMonthlyFinances já
// existente (09-fluxo-epoca.js), mesmo idioma de auto-guarda por mês (academy.lastMonthKey,
// equivalente a financeiro.ultimoProcessamentoMensal). academyEligible cobre automaticamente o
// caso de a Academia estar congelada por descida à 3ª divisão (deixa de academyEligible, deixa
// de desenvolver, dados preservados). Nota sobre custo mensal (academy.monthlyCost): decisão 8
// do plano já classifica reputation/monthlyCost como cosméticos no v1 (sem mecânica de
// investimento); e processMonthlyFinances (04-financas.js:887) já lança uma despesa "Formação"
// recorrente para todos os clubes, incluindo os de 3ª divisão, que cobre conceptualmente o custo
// de desenvolvimento de juvenis — por isso não se lança aqui uma segunda dedução separada para
// academy.monthlyCost, para não cobrar a mesma coisa duas vezes; o campo fica só informativo/
// visível na interface (Fase 6), tal como reputation.
function processAcademyMonthlyDevelopment(date) {
  const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
  Object.values(state.teams).forEach(club => {
    if (!academyEligible(club) || !club.academy) return;
    if (club.academy.lastMonthKey === monthKey) return;
    // Staff — Treinadores (Fase 2, 2026-09-22): o "Desenvolvimento de Jovens" de quem comanda o
    // clube (activeCoachingStats, 08c-staff-treinadores.js — o gestor no clube do utilizador, o
    // treinador da IA nos restantes) acelera ou trava ligeiramente a Academia, ±20% no máximo.
    const coach = activeCoachingStats(club);
    const growthMult = coach && coach.desenvolvimentoJovens != null
      ? clamp(1 + (coach.desenvolvimentoJovens - 10) * 0.02, 0.8, 1.2)
      : 1;
    const growthMultTotal = growthMult * (typeof staffFormacaoMult === "function" ? staffFormacaoMult(club) : 1);   // 0.4.26: treinador de formação
    ACADEMY_BRACKETS.forEach(bracket => {
      club.academy.brackets[bracket].players.forEach(p => {
        developAcademyPlayerMonthly(p, club.academy.level, growthMultTotal);
      });
    });
    club.academy.lastMonthKey = monthKey;
  });
}

// Localiza um jogador juvenil em qualquer escalão da academia de um clube (usado pela Fase 6,
// interface, para abrir a ficha de um jogador a partir do separador Academia).
function findPlayerInAcademy(clubId, playerId) {
  const team = state.teams[clubId];
  if (!team || !team.academy) return null;
  for (const bracket of ACADEMY_BRACKETS) {
    const found = team.academy.brackets[bracket].players.find(p => p.id === playerId);
    if (found) return found;
  }
  return null;
}
