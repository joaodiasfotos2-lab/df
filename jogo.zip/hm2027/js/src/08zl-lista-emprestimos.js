// ============================= 08zl-lista-emprestimos.js =============================
// Lista de empréstimos (0.4.12) — pedido do utilizador: "uma lista de jogadores para empréstimos,
// idêntica à lista de transferíveis. O utilizador e a IA podem pôr um jogador listado para
// empréstimo, para ele rodar e evoluir ou para reduzir o peso salarial. O jogador tem de aceitar".
// Decisões de desenho confirmadas por ele:
//  - o anúncio é só uma etiqueta (sem valor nem termos): `player.emprestimoListado` + o motivo
//    (`player.emprestimoMotivo`: "evoluir" | "salario" | "ambos"), que o jogo deduz da situação;
//  - o jogador decide sozinho (personalidade, satisfação, minutos esperados, nível do destino,
//    idade, motivo), com 1–3 dias de demora quando o utilizador está envolvido, pode recusar com o
//    motivo escrito, e vê-se uma previsão ("provável aceitar / incerto / provável recusar") antes
//    de enviar;
//  - a IA também lista (submenu "Lista de empréstimos" no Mercado) e pede os teus listados.
//
// Dados: player.emprestimoListado (bool), player.emprestimoMotivo, player.emprestimoListadoDesde (ISO),
// player.loanRefusals { [destinoId]: ISO } (recusas recentes, a IA não insiste durante 30 dias).
// Estados novos: offer.status / session.estado = "jogador-a-decidir" (+ playerResponseDate) e
// "recusada-jogador" (+ motivo). Não há estado global novo (tudo vive nas ofertas/sessões).
//
// ESTIMATIVAS (não existem no RGHP): todos os pesos do consentimento do jogador e os critérios de
// listagem da IA.

const LOAN_MOTIVOS = { evoluir: "Rodar e evoluir", salario: "Aliviar massa salarial", ambos: "Rodar e aliviar massa salarial" };
const LOAN_LIST_AI_PER_CLUB = 2;           // máximo de listados em simultâneo por clube de IA
const LOAN_LIST_AI_MAX_DAYS = 60;          // a IA tira da lista quem ficou sem comprador durante este tempo
const LOAN_CONSENT_ACCEPT = 58;            // a partir daqui o jogador aceita
const LOAN_CONSENT_REFUSE = 48;            // abaixo daqui recusa; entre os dois é sorteado
const LOAN_REFUSAL_COOLDOWN_DAYS = 30;

function loanMotivoTexto(m){ return LOAN_MOTIVOS[m] || LOAN_MOTIVOS.evoluir; }

// Motivo deduzido da situação do jogador no clube dono.
function loanListMotive(player, team){
  const imp = playerSquadImportance(player, team).score;
  const age = player.age || 25;
  const dev = age <= 24 && imp < 65;
  const sal = (player.contrato && player.contrato.salarioMensal) || 0;
  const sals = (team.players || []).map(p => (p.contrato && p.contrato.salarioMensal) || 0).filter(x => x > 0);
  const avgSal = sals.length ? sals.reduce((a, b) => a + b, 0) / sals.length : 0;
  let risco = false;
  try { risco = wageHealthTier(wageToBudgetRatio(team)) === "risco"; } catch(e){}
  const pesado = sal > 0 && avgSal > 0 && ((risco && sal >= avgSal * 0.9) || (sal >= avgSal * 1.25 && imp < 55));
  if(dev && pesado) return "ambos";
  if(dev) return "evoluir";
  if(pesado) return "salario";
  return age <= 26 ? "evoluir" : "salario";
}

function setPlayerLoanListed(playerId, teamId){
  const team = state.teams[teamId], player = team && team.players.find(p => p.id === playerId);
  if(!team || !player) return { ok: false, reason: "Jogador não encontrado." };
  if(!isUserControlledTeam(team)) return { ok: false, reason: "Só podes pôr à disposição jogadores do teu clube." };
  if(player.emprestimo) return { ok: false, reason: "O jogador já está emprestado." };
  player.emprestimoListado = true;
  player.emprestimoMotivo = loanListMotive(player, team);
  player.emprestimoListadoDesde = isoDate(state.currentDate || new Date());
  persAoListar(player);
  // Contradição com o estatuto: ver um titular disponível para sair desagrada, mas bem menos do
  // que ser posto à venda (é um empréstimo, volta no fim da época).
  const estatuto = effectivePlayerEstatuto(player, team);
  if(estatuto === "Indispensável" || estatuto === "Titular importante"){
    const pen = estatuto === "Indispensável" ? 9 : 5;
    player.satisfacao = clamp((player.satisfacao != null ? player.satisfacao : 70) - pen, 0, 100);
    pushNews(state.currentDate, `${playerLinkHtml(team.id, player)} estranhou ver-se disponível para empréstimo no ${teamLinkHtml(team.id)}, sendo ${estatuto.toLowerCase()} no plantel.`, "sistema", `Descontentamento no ${team.name}`);
  }
  return { ok: true, motivo: player.emprestimoMotivo };
}
function clearPlayerLoanListed(playerId, teamId){
  const team = state.teams[teamId], player = team && team.players.find(p => p.id === playerId);
  if(!team || !player) return { ok: false, reason: "Jogador não encontrado." };
  player.emprestimoListado = false; player.emprestimoMotivo = null; player.emprestimoListadoDesde = null;
  return { ok: true };
}

// ---------------------------------------------------------------------------------------------
// Consentimento do jogador
// ---------------------------------------------------------------------------------------------
// Devolve a pontuação (0-100), o nível previsto e os fatores (para mostrar o motivo).
function loanPlayerConsent(player, owner, dest, share, role){
  const f = []; let s = 52;
  const add = (v, txt) => { v = Math.round(v); if(!v) return; s += v; f.push({ v, txt }); };
  const imp = playerSquadImportance(player, owner);
  const est = effectivePlayerEstatuto(player, owner);
  // Minutos: o papel que o destino promete vs. o lugar que tem agora.
  const cur = imp.score >= 65 ? 2 : imp.score >= 45 ? 1 : 0;
  const dst = role === "Titular" ? 2 : role === "Rotacao" ? 1 : 0;
  const dm = dst - cur;
  add(dm === 2 ? 20 : dm === 1 ? 11 : dm === -1 ? -12 : dm === -2 ? -22 : 0, dm > 0 ? "vai ter mais minutos do que aqui" : "perde protagonismo em relação ao que tem agora");
  if(est === "Indispensável") add(-14, "é indispensável no clube e não quer sair");
  else if(est === "Titular importante") add(-6, "é titular importante no clube");
  const gap = clubAppeal(dest) - clubAppeal(owner);
  add(clamp(gap * 0.35, -10, 8), gap < 0 ? "o destino é um clube de menor dimensão" : "o destino é um clube maior");
  const drop = teamDivisionRank(owner) - teamDivisionRank(dest);
  if(drop > 0) add(-6 * drop, "desceria de divisão");
  const age = player.age || 25, gapPot = (player.potential != null ? player.potential : overall(player)) - overall(player);
  if(age <= 23 && gapPot >= 2 && role !== "Desenvolvimento") add(6, "quer evoluir a jogar");
  if(age >= 29) add(-4, "prefere estabilidade a esta altura da carreira");
  const trait = persTraco(player);
  if(trait === "ambicioso"){ if(gap < 0) add(-8, "é ambicioso e não quer baixar de patamar"); }
  else if(trait === "leal"){
    add(-5, "é leal ao clube");
    if(clubsAreDirectRivals(owner, dest)) add(-15, "recusa ir para um rival");
  }
  const sat = player.satisfacao != null ? player.satisfacao : 70;
  if(sat < 45) add(10, "está descontente e quer mudar de ares"); else if(sat >= 75) add(-5, "está feliz no clube");
  if(player.pedidoSaida) add(14, "já tinha pedido para sair");
  if(player.emprestimoListado){
    if((player.emprestimoMotivo || "evoluir") === "salario") add(-4, "sente-se empurrado para fora por razões salariais");
    else add(6, "percebe que o empréstimo lhe dá minutos");
  }
  if(teamCountry(owner) !== teamCountry(dest)) add(-5, "implica mudar de país");
  s = clamp(Math.round(s), 0, 100);
  const neg = f.filter(x => x.v < 0).sort((a, b) => a.v - b.v)[0];
  const pos = f.filter(x => x.v > 0).sort((a, b) => b.v - a.v)[0];
  const nivel = s >= 62 ? "provavel" : s >= 50 ? "incerto" : "improvavel";
  return { score: s, nivel, factors: f, motivoNeg: neg ? neg.txt : null, motivoPos: pos ? pos.txt : null };
}
function loanConsentDecide(player, owner, dest, share, role, seedExtra){
  const c = loanPlayerConsent(player, owner, dest, share, role);
  let ok;
  if(c.score >= LOAN_CONSENT_ACCEPT) ok = true;
  else if(c.score < LOAN_CONSENT_REFUSE) ok = false;
  else {
    const r = seededRndFloat(makeSeededRng(`loan-consent:${player.id}:${dest.id}:${isoDate(state.currentDate || new Date())}:${seedExtra || 0}`), 0, 1);
    ok = r < (c.score - LOAN_CONSENT_REFUSE) / (LOAN_CONSENT_ACCEPT - LOAN_CONSENT_REFUSE);
  }
  c.ok = ok;
  return c;
}
function loanConsentLabel(c){
  return c.nivel === "provavel" ? "Provável aceitar" : c.nivel === "incerto" ? "Incerto" : "Provável recusar";
}
// Linha de previsão para a interface (cor + frase com o fator mais pesado).
function loanConsentHintHtml(player, owner, dest, share, role){
  let c; try { c = loanPlayerConsent(player, owner, dest, share, role); } catch(e){ return ""; }
  const cor = c.nivel === "provavel" ? "#2E8B57" : c.nivel === "incerto" ? "#B8860B" : "#D6402F";
  const razao = c.nivel === "provavel" ? c.motivoPos : (c.motivoNeg || c.motivoPos);
  return `<span class="loan-consent-hint" style="color:${cor};font-weight:700;">Jogador: ${loanConsentLabel(c)}</span>${razao ? ` <span class="helptext">(${escapeHtml(razao)})</span>` : ""}`;
}
function loanRefusalRecent(player, destId){
  const d = player && player.loanRefusals && player.loanRefusals[destId];
  if(!d || !state.currentDate) return false;
  return (new Date(isoDate(state.currentDate) + "T00:00:00Z") - new Date(d + "T00:00:00Z")) / 86400000 < LOAN_REFUSAL_COOLDOWN_DAYS;
}
function loanNoteRefusal(player, destId){
  if(!player.loanRefusals) player.loanRefusals = {};
  player.loanRefusals[destId] = isoDate(state.currentDate || new Date());
}

// O clube dono (ou o utilizador) já fechou o acordo de empréstimo: agora é o jogador a decidir.
// Quando o utilizador está envolvido há 1–3 dias de demora (offer.status/session.estado ficam em
// "jogador-a-decidir"); entre clubes de IA decide-se logo (ver resolvePendingLoanNegotiations).
function loanConsentWaitDate(key){
  const d = state.currentDate || new Date();
  return addDays(d, seededRnd(makeSeededRng(`loan-consent-wait:${key}:${isoDate(d)}`), 1, 3));
}
function loanOfferToPlayerConsult(offer, player, user, buyer){
  const due = loanConsentWaitDate(offer.id);
  offer.status = "jogador-a-decidir"; offer.playerResponseDate = isoDate(due);
  pushNews(state.currentDate || new Date(), `Falámos com ${playerLinkHtml(user.id, player)} sobre o empréstimo ao ${teamLinkHtml(buyer.id)}. O jogador responde até ${fmtDateShort(due)}.`, "proposta", "Jogador a decidir", { teamId: buyer.id });
}
function loanSessionToPlayerConsult(session, player, owner, dest, date){
  const due = loanConsentWaitDate(loanNegotiationKey(player, owner, dest));
  session.estado = "jogador-a-decidir"; session.playerResponseDate = isoDate(due);
  const involvesUser = isUserControlledTeam(owner) || isUserControlledTeam(dest);
  if(involvesUser) pushNews(date, `${teamLinkHtml(owner.id)} aceitou o empréstimo de ${playerLinkHtml(owner.id, player)} ao ${teamLinkHtml(dest.id)}. Falta a decisão do jogador, até ${fmtDateShort(due)}.`, "proposta", "Jogador a decidir", { teamId: owner.id });
}
function loanRefusalNews(date, player, owner, dest, dec){
  const motivo = dec.motivoNeg || "não se sente motivado";
  pushNews(date, `${playerLinkHtml(owner.id, player)} recusou o empréstimo ao ${teamLinkHtml(dest.id)}: ${motivo}.`, "proposta", "Jogador recusou o empréstimo", { autoAdvanceStop: true, teamId: dest.id });
}

// Resolve (todos os dias) as decisões de jogadores que já chegaram à data de resposta.
function resolveLoanConsents(date){
  const iso = isoDate(new Date(date));
  const user = myTeam();
  (state.aiOffers || []).forEach(o => {
    if(!o || o.status !== "jogador-a-decidir" || !o.playerResponseDate || o.playerResponseDate > iso) return;
    const buyer = state.teams[o.fromTeamId], player = user && user.players.find(p => p.id === o.playerId);
    if(!buyer || !user || !player){ o.status = "expirada"; return; }
    if(!state.inDefeso && !registrationWindowOpenFor(new Date(date))){
      o.status = "expirada";
      pushNews(date, `O empréstimo de ${playerLinkHtml(user.id, player)} ao ${teamLinkHtml(buyer.id)} caducou: a janela de inscrições fechou.`, "proposta", "Proposta caducada", { teamId: buyer.id });
      return;
    }
    const chk = canLoanPlayer(player, user, buyer);
    if(!chk.ok){ o.status = "desistiu"; return; }
    const dec = loanConsentDecide(player, user, buyer, o.salaryShare, o.papel, o.id);
    if(!dec.ok){
      o.status = "recusada-jogador"; o.rejectedDate = iso; o.motivoJogador = dec.motivoNeg || null;
      loanNoteRefusal(player, buyer.id);
      loanRefusalNews(date, player, user, buyer, dec);
      return;
    }
    // 0.4.25: o empréstimo não se concretiza sozinho — decisão final do utilizador (08zm-decisao-final.js).
    if(typeof dfQueueLoan === "function"){ o.status = "a-confirmar"; dfQueueLoan(player, user, buyer, o.salaryShare, o.papel, o.clausulas, "oferta", o.id, null); return; }
    const r = completeLoan(player, user, buyer, o.salaryShare, o.papel, o.clausulas, { silencioso: true });
    if(!r.ok){ o.status = "desistiu"; return; }
    o.status = "aceite";
    pushNews(date, `${playerLinkHtml(buyer.id, player)} aceitou o empréstimo ao ${teamLinkHtml(buyer.id)} (${o.salaryShare}% do salário, ${ROLE_LABELS[o.papel] || o.papel}, ${empClausulasTexto(o.clausulas)}).`, "proposta", "Empréstimo concluído", { autoAdvanceStop: true, teamId: buyer.id });
  });
  Object.keys(state.loanNegotiations || {}).forEach(key => {
    const s = state.loanNegotiations[key];
    if(!s || s.estado !== "jogador-a-decidir" || !s.playerResponseDate || s.playerResponseDate > iso) return;
    const owner = state.teams[s.ownerId], dest = state.teams[s.destinationId];
    const player = owner && owner.players.find(p => p.id === s.playerId);
    if(!owner || !dest || !player){ s.estado = "cancelada"; return; }
    const involvesUser = isUserControlledTeam(owner) || isUserControlledTeam(dest);
    if(!state.inDefeso && !registrationWindowOpenFor(new Date(date))){
      s.estado = "cancelada";
      if(involvesUser) pushNews(date, `O empréstimo de ${playerLinkHtml(owner.id, player)} ao ${teamLinkHtml(dest.id)} caducou: a janela de inscrições fechou.`, "proposta", "Proposta caducada", { teamId: owner.id });
      return;
    }
    const chk = canLoanPlayer(player, owner, dest);
    if(!chk.ok){ s.estado = "cancelada"; return; }
    const dec = loanConsentDecide(player, owner, dest, s.share, s.role, key);
    if(!dec.ok){
      s.estado = "recusada-jogador"; s.motivoJogador = dec.motivoNeg || null; s.recusadaEm = iso;
      loanNoteRefusal(player, dest.id);
      if(involvesUser) loanRefusalNews(date, player, owner, dest, dec);
      return;
    }
    if(involvesUser && typeof dfQueueLoan === "function"){ s.estado = "a-confirmar"; dfQueueLoan(player, owner, dest, s.share, s.role, s.clausulas, "sessao", key, s.aiMeta || null); return; }
    s.estado = "aceite";
    completeLoan(player, owner, dest, s.share, s.role, s.clausulas);
    if(s.aiMeta && !isUserControlledTeam(dest)){
      const total = aiTotalRecruitmentCost(player, dest, "emprestimos", 0, ((player.contrato && player.contrato.salarioMensal) || 0) * .5);
      aiRegisterRecruitment(dest, player, "emprestimos", total);
    }
  });
}

// ---------------------------------------------------------------------------------------------
// Ofertas da IA pelos teus listados: partilha de salário e papel propostos
// ---------------------------------------------------------------------------------------------
function aiLoanOfferTerms(player, user, ai){
  const ovs = ai.players.filter(p => p.pos === player.pos && !p.__provisional && !p.emprestimo).map(p => overall(p)).sort((a, b) => b - a);
  const ref = ovs.length ? ovs[Math.min(player.pos === "GR" ? 0 : 4, ovs.length - 1)] : 0;
  const papel = overall(player) >= ref ? "Titular" : "Rotacao";
  const motivo = player.emprestimoMotivo || "evoluir";
  let share = 50;
  if(motivo !== "evoluir"){
    const sal = (player.contrato && player.contrato.salarioMensal) || 0;
    const tot = aiTotalRecruitmentCost(player, ai, "emprestimos", 0, sal * .75);
    if(aiRecruitmentFinanciallySafe(ai, tot, 0, sal * .75)) share = 75;
  }
  return { share, papel };
}

// ---------------------------------------------------------------------------------------------
// A IA lista jogadores para empréstimo (jovens sem minutos / salários pesados em clubes sob pressão)
// ---------------------------------------------------------------------------------------------
function aiLoanListingStillValid(p, club){
  if(p.emprestimo || p.titular || p.transferListado) return false;
  if(!canReleasePlayerFromTeam(club, p).ok) return false;
  if(!aiShouldKeepListed(p, club)) return false;
  if(playerSquadImportance(p, club).score >= 65) return false;
  if(p.emprestimoListadoDesde){
    const dias = (new Date(isoDate(state.currentDate || new Date()) + "T00:00:00Z") - new Date(p.emprestimoListadoDesde + "T00:00:00Z")) / 86400000;
    if(dias > LOAN_LIST_AI_MAX_DAYS) return false;
  }
  return true;
}
function aiPickLoanListingCandidate(club){
  const pool = club.players.filter(p =>
    !p.emprestimoListado && !p.transferListado && !p.emprestimo && !p.__provisional && !p.titular &&
    playerAvailableForMatch(p) && isSquadSurplus(p, club) && canReleasePlayerFromTeam(club, p).ok &&
    (p.reputacaoJogador || 0) < LOAN_STAR_REPUTATION && !playerTransferLimitReached(p) &&
    !(p.loanRefusals && Object.keys(p.loanRefusals).length >= 3));
  if(!pool.length) return null;
  const scored = [];
  pool.forEach(p => {
    const samePos = club.players.filter(o => o.pos === p.pos);
    const neededCount = p.pos === "GR" ? CONVOCATORIA_MAX_GR : CONVOCATORIA_MAX_J;
    if(samePos.length < neededCount + AI_LISTING_SAFETY_MARGIN) return;
    const motivo = loanListMotive(p, club);
    const age = p.age || 25;
    const usage = (p.season && p.season.jogos) || 0;
    const dev = age <= 24 && playerSquadImportance(p, club).score < 65;
    const salaryNeed = motivo === "salario" || motivo === "ambos";
    if(!dev && !salaryNeed) return;
    const gapPot = (p.potential != null ? p.potential : overall(p)) - overall(p);
    const score = (dev ? 4 + clamp(8 - usage, 0, 8) * .5 + clamp(gapPot, 0, 4) : 0) + (salaryNeed ? 5 : 0);
    scored.push({ p, score, motivo });
  });
  if(!scored.length) return null;
  scored.sort((a, b) => b.score - a.score || String(a.p.id).localeCompare(String(b.p.id)));
  return scored[0];
}
function reviewAiLoanListing(club){
  const today = isoDate(state.currentDate || new Date());
  if(club.lastLoanListingReviewDate){
    const dias = (new Date(today + "T00:00:00Z") - new Date(club.lastLoanListingReviewDate + "T00:00:00Z")) / 86400000;
    if(dias < aiListingReviewCooldownDays(club)) return;
  }
  club.lastLoanListingReviewDate = today;
  club.players.filter(p => p.emprestimoListado).forEach(p => {
    if(!aiLoanListingStillValid(p, club)){ p.emprestimoListado = false; p.emprestimoMotivo = null; p.emprestimoListadoDesde = null; }
  });
  // No máximo 2 jogadores de cada clube de IA disponíveis para empréstimo em simultâneo (um clube
  // não anuncia o plantel inteiro) — 0.4.12, estimativa.
  if(club.players.filter(p => p.emprestimoListado).length >= LOAN_LIST_AI_PER_CLUB) return;
  const pick = aiPickLoanListingCandidate(club);
  if(pick){
    pick.p.emprestimoListado = true; pick.p.emprestimoMotivo = pick.motivo; pick.p.emprestimoListadoDesde = today;
  }
}
function reviewAllAiLoanListings(){
  Object.values(state.teams).filter(t => !isUserControlledTeam(t) && !t.nuvemEuropeia && !t.selecaoNacional && !isMarketPassiveTeam(t)).forEach(reviewAiLoanListing);
}

// ---------------------------------------------------------------------------------------------
// Mercado → "Lista de empréstimos"
// ---------------------------------------------------------------------------------------------
function renderLoanListSection(t){
  const box = document.getElementById("loanListSection");
  if(!box) return;
  const userCountry = teamCountry(t);
  const entries = [];
  Object.values(state.teams).forEach(club => {
    if(!club || club.id === t.id || club.id === t.equipaBId) return;
    if(club.nuvemEuropeia || club.selecaoNacional) return;
    if(teamCountry(club) !== userCountry) return;
    (club.players || []).filter(p => p.emprestimoListado && !p.emprestimo).forEach(p => {
      entries.push({ player: p, club });
    });
  });
  entries.sort((a, b) => overall(b.player) - overall(a.player));
  const mine = [t].concat(t.equipaBId && state.teams[t.equipaBId] ? [state.teams[t.equipaBId]] : [])
    .flatMap(club => (club.players || []).filter(p => p.emprestimoListado && !p.emprestimo).map(p => ({ player: p, club })));
  const mineHtml = `<div class="eyebrow" style="margin:6px 0 8px;">Os teus jogadores disponíveis para empréstimo (${mine.length})</div>` + (mine.length
    ? mine.map(e => `<div class="fixture-row"><div>${playerLinkHtml(e.club.id, e.player)}<div class="meta">${linhaAbbrev(e.player)} · ${e.player.age} anos</div></div>
        <div>Motivo: ${escapeHtml(loanMotivoTexto(e.player.emprestimoMotivo))}</div>
        <div><button class="btn btn-ghost loan-list-remove" data-team="${e.club.id}" data-player="${e.player.id}">Retirar</button></div></div>`).join("")
    : '<p class="helptext">Ainda não disponibilizaste ninguém. Na ficha do jogador, usa "Disponibilizar para empréstimo".</p>');
  const othersHtml = `<div class="eyebrow" style="margin:18px 0 8px;">Disponíveis noutros clubes (${entries.length})</div>` + (entries.length
    ? entries.map(e => {
        const p = e.player, sal = (p.contrato && p.contrato.salarioMensal) || 0;
        return `<div class="fixture-row">
          <div>${playerLinkHtml(e.club.id, p)}<div class="meta">${teamLinkHtml(e.club.id)} · ${linhaAbbrev(p)} · ${p.age} anos</div></div>
          <div>Motivo: ${escapeHtml(loanMotivoTexto(p.emprestimoMotivo))}</div>
          <div>Salário: ${fmtMoney(sal)}/mês</div>
        </div>`;
      }).join("")
    : '<p class="helptext">Nenhum clube colocou jogadores disponíveis para empréstimo neste momento.</p>');
  box.innerHTML = mineHtml + othersHtml;
  box.querySelectorAll(".loan-list-remove").forEach(b => b.onclick = () => {
    clearPlayerLoanListed(b.getAttribute("data-player"), b.getAttribute("data-team"));
    renderLoanListSection(t);
  });
}
