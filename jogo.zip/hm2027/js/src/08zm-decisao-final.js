// ============================= 08zm-decisao-final.js =============================
// Decisão final nos negócios do utilizador (0.4.25) — pedido: "uma decisão final sempre que se compra,
// vende ou empresta um jogador". Até aqui o negócio concretizava-se sozinho no dia em que o jogador
// aceitava os termos (ou consentia o empréstimo). Agora, quando o utilizador está envolvido, esse
// último passo fica em pausa: abre-se uma janela "Decisão final" (e chega um e-mail com botão) com o
// resumo do negócio — Confirmar ou Desistir; sem resposta, o prazo (7 dias, nunca depois do prazo
// de inscrições do acordo) fecha o negócio sem se concretizar.
//
// Pontos de intercepção (quem chama):
//   - resolvePendingContractNegotiations (04-financas.js): transferência definitiva, compra ou venda  → dfQueueTransfer
//   - resolveLoanConsents (08zl-lista-emprestimos.js): empréstimo que sai ou entra no clube           → dfQueueLoan
// Fora do âmbito (continuam automáticos): jogadores livres, pré-contratos, renovações, chamadas das
// equipas satélite e negócios entre clubes de IA.
//
// Dados: state.decisoesFinais = [{id, tipo:"transferencia"|"emprestimo", lado:"compra"|"venda"|"empresta"|"recebe",
//   playerId, playerName, fromId, toId, criada, expiraEm, estado:"pendente"|"confirmado"|"desistiu"|"expirado",
//   fee, offer, aiMeta, loan:{share, role, clausulas, origem:"oferta"|"sessao", ref}}]
// player.negocioPorConfirmar = id da decisão (bloqueia outros negócios com o mesmo jogador enquanto pendente).
// =================================================================================
var DF_PRAZO_DIAS = 7;

function dfList(){ if(!Array.isArray(state.decisoesFinais)) state.decisoesFinais = []; return state.decisoesFinais; }
function dfPending(){ return dfList().filter(e => e.estado === "pendente"); }
function dfById(id){ return dfList().find(e => e.id === id) || null; }
function dfTrim(){
  const l = dfList(), keep = l.filter(e => e.estado === "pendente"), done = l.filter(e => e.estado !== "pendente").slice(0, 15);
  state.decisoesFinais = keep.concat(done);
}
function dfPlayerOf(e){
  const from = state.teams[e.fromId];
  return from ? from.players.find(p => p.id === e.playerId) || null : null;
}

// Ao carregar um save: tira o bloqueio a jogadores cuja decisão já não existe/pendente.
function dfSweepLocks(){
  const ids = new Set(dfPending().map(e => e.id));
  Object.values(state.teams || {}).forEach(t => (t.players || []).forEach(p => { if(p.negocioPorConfirmar && !ids.has(p.negocioPorConfirmar)) p.negocioPorConfirmar = null; }));
}

// ---------- entrada: o negócio chegou ao último passo ----------
function dfExpiry(d, capIso){
  let x = isoDate(addDays(d, DF_PRAZO_DIAS));
  if(capIso && capIso < x) x = capIso;
  const today = isoDate(d);
  return x < today ? today : x;
}
function dfQueueTransfer(session, player, fromTeam, toTeam, offer){
  if(player.negocioPorConfirmar) return true;   // já está em decisão
  const d = new Date(state.currentDate || new Date());
  const feeSess = state.transferNegotiations && state.transferNegotiations[transferNegotiationKey(player, fromTeam, toTeam)];
  const cap = feeSess ? sessionRegistrationDeadline(feeSess, d) : null;
  const userBuys = isUserControlledTeam(toTeam);
  const e = {
    id: `df:${player.id}:${isoDate(d)}`, tipo: "transferencia", lado: userBuys ? "compra" : "venda",
    playerId: player.id, playerName: player.name, fromId: fromTeam.id, toId: toTeam.id,
    criada: isoDate(d), expiraEm: dfExpiry(d, cap), estado: "pendente",
    fee: agreedTransferFee(player, fromTeam, toTeam) || 0, offer: { ...offer }, aiMeta: (session && session.aiMeta) || null,
  };
  dfAnnounce(e, player);
  return true;
}
function dfQueueLoan(player, owner, dest, share, role, clausulas, origem, ref, aiMeta){
  if(player.negocioPorConfirmar) return true;
  const d = new Date(state.currentDate || new Date());
  const e = {
    id: `df:${player.id}:${isoDate(d)}:emp`, tipo: "emprestimo", lado: isUserControlledTeam(owner) ? "empresta" : "recebe",
    playerId: player.id, playerName: player.name, fromId: owner.id, toId: dest.id,
    criada: isoDate(d), expiraEm: dfExpiry(d, null), estado: "pendente", fee: 0, offer: null, aiMeta: aiMeta || null,
    loan: { share, role, clausulas, origem, ref },
  };
  dfAnnounce(e, player);
  return true;
}
function dfSummaryLine(e, player){
  const from = state.teams[e.fromId], to = state.teams[e.toId];
  const pl = playerLinkHtml(from.id, player);
  if(e.tipo === "transferencia") return e.lado === "compra"
    ? `Acordo fechado com ${teamLinkHtml(from.id)} e com ${pl}: ${fmtMoney(e.fee)} de transferência e ${fmtMoney(e.offer.salarioMensal)}/mês.`
    : `Acordo fechado com o ${teamLinkHtml(to.id)} pela venda de ${pl}: ${fmtMoney(e.fee)} para o teu clube.`;
  return e.lado === "empresta"
    ? `${pl} aceitou ser emprestado ao ${teamLinkHtml(to.id)} (${e.loan.share}% do salário pago por eles).`
    : `${pl} aceitou vir por empréstimo do ${teamLinkHtml(from.id)} (${e.loan.share}% do salário pago por ti).`;
}
function dfAnnounce(e, player){
  dfList().unshift(e);
  player.negocioPorConfirmar = e.id;
  dfTrim();
  const from = state.teams[e.fromId], to = state.teams[e.toId];
  const other = e.lado === "compra" || e.lado === "recebe" ? from : to;
  pushNews(state.currentDate, `${dfSummaryLine(e, player)} Falta a tua decisão final, até ${fmtDateShort(e.expiraEm)}: confirmar ou desistir. <button class="news-open-df" data-df-open="${e.id}">Decidir →</button>`,
    "proposta", "Decisão final: negócio por confirmar", { autoAdvanceStop: true, teamId: other.id });
  setTimeout(() => { try { openFinalDecisionModal(e.id); } catch(err){ console.warn("[HM2027] decisão final", err); } }, 0);
}

// ---------- confirmar / desistir / expirar ----------
function dfRelease(e){ const p = dfPlayerOf(e); if(p && p.negocioPorConfirmar === e.id) p.negocioPorConfirmar = null; return p; }
function dfClearTransferSessions(e, player){
  const from = state.teams[e.fromId], to = state.teams[e.toId];
  if(!from || !to || !player) return;
  if(state.transferNegotiations) delete state.transferNegotiations[transferNegotiationKey(player, from, to)];
  if(state.contractNegotiations) delete state.contractNegotiations[negotiationSessionKey("transferencia", player, from, to)];
  (state.aiOffers || []).forEach(o => { if(o.playerId === player.id && o.fromTeamId === to.id && o.status === "fee-acordado") o.status = "desistiu"; });
}
function dfConfirm(id){
  const e = dfById(id);
  if(!e || e.estado !== "pendente") return { ok: false, reason: "Esta decisão já não está pendente." };
  const d = new Date(state.currentDate || new Date());
  if(isoDate(d) > e.expiraEm){ dfClose(e, "expirado", "O prazo terminou."); return { ok: false, reason: "O prazo para decidir já terminou." }; }
  const from = state.teams[e.fromId], to = state.teams[e.toId], player = dfPlayerOf(e);
  if(!from || !to || !player){ dfClose(e, "expirado", "O jogador já não está disponível."); return { ok: false, reason: "O jogador já não está disponível." }; }
  if(e.tipo === "transferencia"){
    if(agreedTransferFee(player, from, to) == null){ dfClose(e, "expirado", "O acordo entre clubes caducou."); return { ok: false, reason: "O acordo entre clubes caducou." }; }
    initClubFinance(to);
    if(e.fee > to.financeiro.saldo || e.fee > to.financeiro.orcamentoTransferencias) return { ok: false, reason: isUserControlledTeam(to) ? "O teu clube já não dispõe do valor desta transferência (orçamento de transferências ou saldo)." : "O clube comprador já não dispõe do valor." };
    if(playerTransferLimitReached(player)){ dfClose(e, "expirado", "O jogador já foi transferido esta época."); return { ok: false, reason: "O jogador já foi transferido esta época." }; }
    player.negocioPorConfirmar = null;
    applyAcceptedOffer("transferencia", player, from, to, e.offer);
    if(e.aiMeta && !isUserControlledTeam(to)){
      const total = aiTotalRecruitmentCost(player, to, e.aiMeta.type, e.fee, e.offer.salarioMensal);
      aiRegisterRecruitment(to, player, e.aiMeta.type, total);
    }
  } else {
    player.negocioPorConfirmar = null;   // canLoanPlayer recusa jogadores com negócio por confirmar
    const chk = canLoanPlayer(player, from, to);
    if(!chk.ok){ dfClose(e, "expirado", chk.reason); return { ok: false, reason: chk.reason }; }
    const L = e.loan;
    if(L.origem === "oferta"){
      const o = (state.aiOffers || []).find(x => x.id === L.ref);
      const r = completeLoan(player, from, to, L.share, L.role, L.clausulas, { silencioso: true });
      if(!r.ok){ dfClose(e, "expirado", r.reason || "Já não é possível."); return { ok: false, reason: r.reason || "Já não é possível." }; }
      if(o) o.status = "aceite";
      pushNews(d, `${playerLinkHtml(to.id, player)} segue por empréstimo para o ${teamLinkHtml(to.id)} (${L.share}% do salário, ${ROLE_LABELS[L.role] || L.role}, ${empClausulasTexto(L.clausulas)}).`, "proposta", "Empréstimo concluído", { autoAdvanceStop: true, teamId: to.id });
    } else {
      const s = (state.loanNegotiations || {})[L.ref];
      const r = completeLoan(player, from, to, L.share, L.role, L.clausulas);
      if(!r.ok){ dfClose(e, "expirado", r.reason || "Já não é possível."); return { ok: false, reason: r.reason || "Já não é possível." }; }
      if(s){
        s.estado = "aceite";
        if(s.aiMeta && !isUserControlledTeam(to)){
          const total = aiTotalRecruitmentCost(player, to, "emprestimos", 0, ((player.contrato && player.contrato.salarioMensal) || 0) * .5);
          aiRegisterRecruitment(to, player, "emprestimos", total);
        }
      }
    }
  }
  e.estado = "confirmado"; e.fechada = isoDate(d);
  dfTrim();
  return { ok: true };
}
// Fecha sem concretizar (desistência, caducidade): limpa as sessões para o negócio poder recomeçar do zero.
function dfClose(e, estado, motivo){
  const player = dfRelease(e);
  if(e.tipo === "transferencia") dfClearTransferSessions(e, player);
  else if(e.loan){
    if(e.loan.origem === "oferta"){ const o = (state.aiOffers || []).find(x => x.id === e.loan.ref); if(o) o.status = "desistiu"; }
    else { const s = (state.loanNegotiations || {})[e.loan.ref]; if(s) s.estado = "cancelada"; }
  }
  e.estado = estado; e.fechada = isoDate(new Date(state.currentDate || new Date())); e.motivo = motivo || "";
  dfTrim();
}
function dfDesist(id){
  const e = dfById(id);
  if(!e || e.estado !== "pendente") return { ok: false };
  const player = dfPlayerOf(e), from = state.teams[e.fromId], to = state.teams[e.toId];
  dfClose(e, "desistiu", "Desististe do negócio.");
  if(player && from && to) pushNews(state.currentDate, `Desististe ${e.tipo === "transferencia" ? (e.lado === "compra" ? "da contratação de" : "da venda de") : "do empréstimo de"} ${playerLinkHtml(from.id, player)}. O negócio com o ${teamLinkHtml((e.lado === "compra" || e.lado === "recebe") ? from.id : to.id)} não se concretizou.`, "proposta", "Negócio cancelado por ti", { teamId: (e.lado === "compra" || e.lado === "recebe") ? from.id : to.id });
  return { ok: true };
}
// Diário (dailyConditionRecovery): fecha o que passou do prazo ou perdeu as condições.
function dfResolveExpired(date){
  const today = isoDate(new Date(date));
  dfPending().slice().forEach(e => {
    const from = state.teams[e.fromId], to = state.teams[e.toId], player = dfPlayerOf(e);
    let motivo = null;
    if(!from || !to || !player) motivo = "O jogador já não está disponível.";
    else if(e.tipo === "transferencia" && agreedTransferFee(player, from, to) == null) motivo = "O acordo entre clubes caducou.";
    else if(today > e.expiraEm) motivo = "O prazo para decidires terminou.";
    if(!motivo) return;
    dfClose(e, "expirado", motivo);
    pushNews(date, `O negócio por ${escapeHtml(e.playerName)} não se concretizou: ${motivo.charAt(0).toLowerCase() + motivo.slice(1)}`, "proposta", "Negócio caducado", { autoAdvanceStop: true, teamId: ((e.lado === "compra" || e.lado === "recebe") ? e.fromId : e.toId) });
  });
  const dom = document.getElementById("dfOverlay");
  if(dom && !dfPending().length) dom.remove();
}

// ---------- janela ----------
function dfModalHtml(e){
  const from = state.teams[e.fromId], to = state.teams[e.toId], p = dfPlayerOf(e);
  if(!from || !to || !p) return `<div class="nm-box"><p>Este negócio já não está disponível.</p></div><div class="nm-foot"><button class="nm-btn p" data-df="later">Fechar</button></div>`;
  const mine = isUserControlledTeam(to) ? to : from;
  const ovr = (e.lado === "compra" || e.lado === "recebe") ? Math.round(visibleOverall(p, from)) : overall(p);
  const linha = typeof linhaAbbrev === "function" ? linhaAbbrev(p) : "";
  const titulo = e.tipo === "transferencia"
    ? (e.lado === "compra" ? "Confirmas a contratação?" : "Confirmas a venda?")
    : (e.lado === "empresta" ? "Confirmas o empréstimo do teu jogador?" : "Confirmas o empréstimo?");
  const kv = (k, v, cls) => `<div class="nm-kv"><span>${k}</span><b${cls ? ` class="${cls}"` : ""}>${v}</b></div>`;
  const rows = [];
  rows.push(kv("Jogador", `${escapeHtml(p.name)} · ${linha ? linha + " · " : ""}${p.age} anos · OVR ${ovr}`));
  rows.push(kv("De → Para", `${escapeHtml(from.name)} → ${escapeHtml(to.name)}`));
  if(e.tipo === "transferencia"){
    rows.push(kv(e.lado === "compra" ? "Transferência a pagar" : "Transferência a receber", fmtMoney(e.fee), e.lado === "compra" ? "r" : "g"));
    rows.push(kv("Contrato do jogador", `${fmtMoney(e.offer.salarioMensal)}/mês · ${e.offer.anos} ${e.offer.anos === 1 ? "ano" : "anos"} · ${escapeHtml(ROLE_LABELS[e.offer.papel] || e.offer.papel)}`));
    if(e.lado === "compra"){
      initClubFinance(to);
      const orc = to.financeiro.orcamentoTransferencias;
      rows.push(kv("Orçamento de transferências", `${fmtMoney(orc)} → ${fmtMoney(Math.max(0, orc - e.fee))}`));
      const wb = monthlyWageBill(to);
      rows.push(kv("Massa salarial mensal", `${fmtMoney(wb)} → ${fmtMoney(wb + e.offer.salarioMensal)}`, (wb + e.offer.salarioMensal) > to.financeiro.limiteSalarial ? "r" : ""));
    } else {
      const sal = (p.contrato && p.contrato.salarioMensal) || 0;
      rows.push(kv("Salário poupado por mês", fmtMoney(sal), "g"));
      rows.push(kv("Plantel após a venda", `${from.players.filter(x => x.id !== p.id).length} jogadores`));
    }
    if(!registrationWindowOpenFor(new Date(state.currentDate || new Date()))){
      rows.push(kv("Inscrição", `Janela fechada — só muda de clube a partir de ${fmtDateShort(nextRegistrationWindowOpenDate(state.currentDate || new Date()))} (etiqueta TRF)`, "y"));
    }
  } else {
    const L = e.loan, sal = (p.contrato && p.contrato.salarioMensal) || 0;
    rows.push(kv("Duração", "Até ao fim da época"));
    rows.push(kv("Papel no destino", escapeHtml(ROLE_LABELS[L.role] || L.role)));
    rows.push(kv("Salário pago pelo destino", `${L.share}% (${fmtMoney(Math.round(sal * L.share / 100))}/mês)`));
    rows.push(kv(e.lado === "recebe" ? "O teu encargo" : "O teu encargo (clube de origem)", `${e.lado === "recebe" ? L.share : 100 - L.share}% (${fmtMoney(Math.round(sal * (e.lado === "recebe" ? L.share : 100 - L.share) / 100))}/mês)`));
    rows.push(kv("Cláusulas", escapeHtml(empClausulasTexto(L.clausulas))));
  }
  rows.push(kv("Decides até", fmtDateShort(e.expiraEm), "y"));
  const n = dfPending().length;
  return `<div class="nm-head"><div class="nm-head-t"><h1>🤝 Decisão final${n > 1 ? ` <small>(1 de ${n})</small>` : ""}</h1><p>${titulo} Só depois de confirmares é que o negócio se concretiza.</p></div><button class="nm-x" data-df="later" aria-label="Fechar">✕</button></div>
    <div class="nm-box" style="margin-top:14px;">${rows.join("")}<div class="nm-err" id="dfErr"></div></div>
    <div class="nm-foot"><button class="nm-btn" data-df="later">Decidir mais tarde</button><button class="nm-btn" data-df="desist" data-id="${e.id}">Desistir</button><button class="nm-btn p" data-df="confirm" data-id="${e.id}">Confirmar negócio</button></div>`;
}
function openFinalDecisionModal(id){
  const e = dfById(id) || dfPending()[0];
  if(!e || e.estado !== "pendente") return;
  let root = document.getElementById("dfOverlay");
  if(root) root.remove();
  root = document.createElement("div");
  root.id = "dfOverlay"; root.className = "nm-overlay";
  root.style.zIndex = 9500;
  root.innerHTML = `<div class="nm-modal" role="dialog" aria-modal="true" style="max-width:640px;"><div id="dfBox">${dfModalHtml(e)}</div></div>`;
  document.body.appendChild(root);
  root.addEventListener("click", (ev) => {
    const b = ev.target.closest("[data-df]");
    if(!b){ return; }
    const act = b.getAttribute("data-df"), eid = b.getAttribute("data-id");
    if(act === "later"){ root.remove(); return; }
    if(act === "desist"){ dfDesist(eid); }
    else if(act === "confirm"){
      const r = dfConfirm(eid);
      if(!r.ok){ const er = document.getElementById("dfErr"); if(er) er.textContent = r.reason || "Não foi possível concluir o negócio."; if(dfById(eid) && dfById(eid).estado === "pendente") return; }
    }
    root.remove();
    try { if(typeof renderAll === "function") renderAll(); } catch(err){}
    const next = dfPending()[0];
    if(next) openFinalDecisionModal(next.id);
  });
}
// Mercado: lista dos negócios por confirmar (com botão para reabrir a janela).
function dfPendingSectionHtml(team){
  const l = dfPending().filter(e => e.fromId === team.id || e.toId === team.id || isUserControlledTeam(e.fromId) || isUserControlledTeam(e.toId));
  if(!l.length) return "";
  const lado = { compra: "Contratação", venda: "Venda", empresta: "Empréstimo (sai)", recebe: "Empréstimo (entra)" };
  return `<div class="eyebrow" style="margin:16px 0 8px;">Negócios por confirmar (${l.length})</div>` + l.map(e => {
    const from = state.teams[e.fromId], to = state.teams[e.toId];
    return `<div class="fixture-row"><div>${escapeHtml(e.playerName)}</div><div class="vs">${lado[e.lado]}</div><div>${from ? escapeHtml(from.name) : "—"} → ${to ? escapeHtml(to.name) : "—"} · até ${fmtDateShort(e.expiraEm)} <button class="btn btn-ghost" data-df-open="${e.id}">Decidir</button></div></div>`;
  }).join("");
}
document.addEventListener("click", (ev) => {
  const b = ev.target.closest && ev.target.closest("[data-df-open]");
  if(!b) return;
  ev.preventDefault();
  openFinalDecisionModal(b.getAttribute("data-df-open"));
});
